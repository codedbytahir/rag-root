-- 0029_streaks_referrals_engine.sql
-- Server-authoritative streak + referral engine (backend gaps 2 & 4 in shared/04 §6).
--
-- Streak: qualifying server events (registration confirmed, spin attempt,
-- result published, room released/live) call app.record_streak_day(), which:
--   • marks the PKT day active in app.streak_days (intensity 1..4, source events)
--   • settles missed days with streak freezes (frozen days materialized with a
--     'freeze_consumed' source marker so the streak continues)
--   • computes the current streak server-side (client clock never trusted)
--   • grants milestone coins atomically and idempotently (ledger type
--     'streak_reward') with a linked app.streak_milestones row + notification
--
-- Referral: the first qualifying action (per referral_config.qualifying_trigger)
-- by a referred player flips their app.referrals row to 'rewarded' and credits
-- both sides (ledger type 'referral_reward') idempotently, with notifications.
--
-- Rewards are stored exactly like every other coin movement: immutable
-- app.wallet_ledger rows via the atomic app.wallet_credit helper, with
-- deterministic idempotency keys so retries can never double-grant.
--
-- Also closes the documented RLS gap: app.streak_freezes gets a self-read policy
-- (the Streak screen reads the freeze balance).

-- ---------------------------------------------------------------------------
-- 1. In-app notification helper (used by the engine functions below)
-- ---------------------------------------------------------------------------
create or replace function app.notify(
  p_profile_id uuid,
  p_type text,
  p_title text,
  p_body text,
  p_deep_link text default null
) returns void
language plpgsql
security definer
set search_path = app, public
as $$
begin
  insert into app.notifications (profile_id, type, title, body, deep_link)
  values (p_profile_id, p_type::app.notif_type, p_title, p_body, p_deep_link);
end;
$$;

-- ---------------------------------------------------------------------------
-- 2. Streak engine — record one qualifying action for a player (PKT day)
-- ---------------------------------------------------------------------------
create or replace function app.record_streak_day(
  p_profile_id uuid,
  p_source text
) returns void
language plpgsql
security definer
set search_path = app, public
as $$
declare
  v_cfg jsonb;
  v_actions jsonb;
  v_today date;
  v_last date;
  v_day date;
  v_freezes int;
  v_cursor date;
  v_cur int := 0;
  v_tiers jsonb;
  v_tier jsonb;
  v_days int;
  v_coins bigint;
  v_ledger_id uuid;
  v_milestone_id uuid;
begin
  if p_profile_id is null then return; end if;

  -- PKT day boundary computed server-side (Asia/Karachi, 00:00–23:59).
  v_today := (now() at time zone 'Asia/Karachi')::date;

  -- Honor the admin-configured qualifying action list (default: allow all).
  select value into v_cfg from app.settings where key = 'streak_config';
  if v_cfg is not null then
    v_actions := v_cfg->'qualifying_actions';
    if jsonb_typeof(v_actions) = 'array' and not exists (
      select 1 from jsonb_array_elements_text(v_actions) a where a = p_source
    ) then
      return;
    end if;
  end if;

  -- Settle missed days since the last active day, consuming freezes oldest-first.
  select max(day) into v_last from app.streak_days
  where profile_id = p_profile_id and day < v_today;
  if v_last is not null and v_last < v_today - 1 then
    select coalesce(sum(balance), 0) into v_freezes
    from app.streak_freezes where profile_id = p_profile_id;
    for v_day in select generate_series(v_last + 1, v_today - 1, interval '1 day') loop
      if v_freezes > 0 then
        insert into app.streak_days (profile_id, day, intensity, source_events)
        values (p_profile_id, v_day, 1, jsonb_build_array('freeze_consumed'))
        on conflict (profile_id, day) do nothing;
        -- consume one freeze (oldest row first), record the covered day
        update app.streak_freezes set balance = balance - 1, consumed_on = v_day
        where id = (
          select id from app.streak_freezes
          where profile_id = p_profile_id and balance > 0
          order by created_at limit 1
        );
        v_freezes := v_freezes - 1;
      end if;
    end loop;
  end if;

  -- Mark today active (multiple qualifying actions stack intensity, capped at 4).
  insert into app.streak_days (profile_id, day, intensity, source_events)
  values (p_profile_id, v_today, 1, jsonb_build_array(p_source))
  on conflict (profile_id, day) do update
  set intensity = least(4, app.streak_days.intensity + 1),
      source_events = app.streak_days.source_events || jsonb_build_array(p_source);

  -- Current streak: consecutive active days ending today. Frozen days are
  -- already materialized above, so a preserved streak walks back through them.
  v_cursor := v_today;
  while exists (select 1 from app.streak_days where profile_id = p_profile_id and day = v_cursor) loop
    v_cur := v_cur + 1;
    v_cursor := v_cursor - 1;
  end loop;

  -- Milestone tiers: grant coins atomically + idempotently when crossed.
  v_tiers := coalesce(v_cfg->'tiers', '[
    {"days": 3, "coins": 10}, {"days": 7, "coins": 25}, {"days": 14, "coins": 60},
    {"days": 30, "coins": 150}, {"days": 60, "coins": 300}, {"days": 100, "coins": 500}
  ]'::jsonb);
  for v_tier in select * from jsonb_array_elements(v_tiers) loop
    v_days := coalesce((v_tier->>'days')::int, 0);
    v_coins := coalesce((v_tier->>'coins')::bigint, 0);
    if v_days <= 0 or v_coins <= 0 then continue; end if;
    if v_cur >= v_days and not exists (
      select 1 from app.streak_milestones
      where profile_id = p_profile_id and day_count = v_days
    ) then
      perform app.wallet_credit(
        p_profile_id, v_coins, 'streak_reward', 'streak', p_profile_id,
        'streak_milestone:' || p_profile_id::text || ':' || v_days,
        null, 'Streak milestone day ' || v_days);
      select id into v_ledger_id from app.wallet_ledger
      where idempotency_key = 'streak_milestone:' || p_profile_id::text || ':' || v_days;
      insert into app.streak_milestones (profile_id, day_count, reward_coins, ledger_id)
      values (p_profile_id, v_days, v_coins, v_ledger_id)
      on conflict (profile_id, day_count) do nothing
      returning id into v_milestone_id;
      if v_milestone_id is not null then
        perform app.notify(
          p_profile_id, 'streak_milestone',
          'Streak milestone reached!',
          v_days || '-day streak — ' || v_coins || ' Rush Coins added to your wallet.',
          'rushzone://streak');
      end if;
    end if;
  end loop;
end;
$$;

-- ---------------------------------------------------------------------------
-- 3. Referral auto-qualification — first qualifying action rewards both sides
-- ---------------------------------------------------------------------------
create or replace function app.qualify_referral(
  p_profile_id uuid,
  p_source text
) returns void
language plpgsql
security definer
set search_path = app, public
as $$
declare
  v_cfg jsonb;
  v_trigger text;
  v_ref app.referrals%rowtype;
  v_max int;
  v_count int;
  v_referrer_coins bigint;
  v_referred_coins bigint;
  v_ledger_id uuid;
begin
  if p_profile_id is null then return; end if;

  select value into v_cfg from app.settings where key = 'referral_config';
  if v_cfg is null then return; end if;

  v_trigger := coalesce(v_cfg->>'qualifying_trigger', 'first_tournament');
  -- The engine only fires on server events; map the event to the configured trigger.
  if (v_trigger = 'first_tournament' and p_source <> 'tournament_join')
     or (v_trigger = 'first_spin' and p_source <> 'reward_spin')
     or (v_trigger = 'first_result' and p_source <> 'result_published') then
    return;
  end if;

  select * into v_ref from app.referrals
  where referred_id = p_profile_id and reward_status = 'pending'
  limit 1 for update;
  if not found then return; end if;

  v_referrer_coins := coalesce((v_cfg->>'reward_referrer')::bigint, 0);
  v_referred_coins := coalesce((v_cfg->>'reward_referred')::bigint, 0);

  -- Per-referrer cap (max_per_user); over the cap → hold for manual review.
  v_max := coalesce((v_cfg->>'max_per_user')::int, 0);
  if v_max > 0 then
    select count(*) into v_count from app.referrals
    where referrer_id = v_ref.referrer_id and reward_status = 'rewarded';
    if v_count >= v_max then
      update app.referrals set reward_status = 'held', qualified_at = now()
      where id = v_ref.id;
      return;
    end if;
  end if;

  update app.referrals set reward_status = 'rewarded', qualified_at = now()
  where id = v_ref.id;

  if v_referrer_coins > 0 then
    perform app.wallet_credit(
      v_ref.referrer_id, v_referrer_coins, 'referral_reward', 'referral', v_ref.id,
      'referral_referrer:' || v_ref.id::text, null,
      'Referral reward — ' || v_ref.referred_id::text);
    select id into v_ledger_id from app.wallet_ledger
    where idempotency_key = 'referral_referrer:' || v_ref.id::text;
    update app.referrals set referrer_ledger_id = v_ledger_id where id = v_ref.id;
    perform app.notify(
      v_ref.referrer_id, 'referral_update',
      'Referral reward!',
      'A friend you referred joined the action — ' || v_referrer_coins || ' Rush Coins added.',
      'rushzone://refer');
  end if;

  if v_referred_coins > 0 then
    perform app.wallet_credit(
      v_ref.referred_id, v_referred_coins, 'referral_reward', 'referral', v_ref.id,
      'referral_referred:' || v_ref.id::text, null, 'Welcome reward');
    select id into v_ledger_id from app.wallet_ledger
    where idempotency_key = 'referral_referred:' || v_ref.id::text;
    update app.referrals set referred_ledger_id = v_ledger_id where id = v_ref.id;
    perform app.notify(
      v_ref.referred_id, 'referral_update',
      'Welcome reward!',
      v_referred_coins || ' Rush Coins added for completing your profile.',
      'rushzone://wallet');
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 4. Event triggers — the engine is driven by real server events only.
-- ---------------------------------------------------------------------------

-- 4a. Registration confirmed (individual entry) → streak + referral.
create or replace function app.on_registration_event() returns trigger
language plpgsql security definer set search_path = app, public
as $$
begin
  if NEW.status = 'confirmed' then
    perform app.record_streak_day(NEW.profile_id, 'tournament_join');
    perform app.qualify_referral(NEW.profile_id, 'tournament_join');
  end if;
  return NEW;
end;
$$;

drop trigger if exists trg_streak_registration on app.registrations;
create trigger trg_streak_registration
after insert on app.registrations
for each row execute function app.on_registration_event();

-- 4b. Spin attempt completed (paid or SSV-verified ad) → streak.
create or replace function app.on_reward_attempt_event() returns trigger
language plpgsql security definer set search_path = app, public
as $$
begin
  perform app.record_streak_day(NEW.profile_id, 'reward_spin');
  return NEW;
end;
$$;

drop trigger if exists trg_streak_reward_attempt on app.reward_attempts;
create trigger trg_streak_reward_attempt
after insert on app.reward_attempts
for each row execute function app.on_reward_attempt_event();

-- 4c. Official result published → streak + referral (result_published trigger).
create or replace function app.on_result_event() returns trigger
language plpgsql security definer set search_path = app, public
as $$
begin
  if NEW.status = 'published' then
    perform app.record_streak_day(NEW.profile_id, 'result_published');
    perform app.qualify_referral(NEW.profile_id, 'result_published');
  end if;
  return NEW;
end;
$$;

drop trigger if exists trg_streak_result on app.match_results;
create trigger trg_streak_result
after insert or update of status on app.match_results
for each row execute function app.on_result_event();

-- 4d. Tournament goes room-released / live → every confirmed entrant played.
create or replace function app.on_tournament_live_event() returns trigger
language plpgsql security definer set search_path = app, public
as $$
declare
  v_p uuid;
begin
  if NEW.status in ('room_released', 'live') then
    for v_p in
      select profile_id from app.registrations
      where tournament_id = NEW.id and status = 'confirmed'
    loop
      perform app.record_streak_day(v_p, 'room_released');
    end loop;
  end if;
  return NEW;
end;
$$;

drop trigger if exists trg_streak_tournament_live on app.tournaments;
create trigger trg_streak_tournament_live
after update of status on app.tournaments
for each row execute function app.on_tournament_live_event();

-- ---------------------------------------------------------------------------
-- 5. Close the RLS gap: players must read their own streak freeze balance.
-- ---------------------------------------------------------------------------
alter table app.streak_freezes enable row level security;
drop policy if exists "streak_freezes_self_read" on app.streak_freezes;
create policy "streak_freezes_self_read" on app.streak_freezes
for select using (profile_id = auth.uid());

comment on function app.record_streak_day is
  'Streak engine: PKT-day active marker + freeze settlement + idempotent milestone rewards (ledger type streak_reward).';
comment on function app.qualify_referral is
  'Referral engine: first qualifying action rewards referrer + referred (ledger type referral_reward), idempotent.';
