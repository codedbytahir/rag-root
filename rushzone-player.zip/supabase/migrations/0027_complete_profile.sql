-- 0027_complete_profile.sql
-- One-time player profile setup RPC (backend gap-fill).
--
-- Creates app.profiles (+ wallet_accounts + profile_stats, and an optional
-- referrals row when a referral code is supplied). Idempotent: returns the
-- existing profile id if one already exists.
--
-- SECURITY DEFINER, so it can write as the table owner; it enforces
-- p_user_id = auth.uid() so a caller may only ever create their own profile.
-- Execute is granted to `authenticated` only (the Player App calls this via
-- PostgREST RPC with the publishable key + the user's JWT).

create or replace function app.complete_profile(
  p_user_id uuid,
  p_display_name text,
  p_ff_uid text,
  p_in_game_name text,
  p_whatsapp_phone text,
  p_avatar_path text default null,
  p_referral_code_input text default null
) returns uuid
language plpgsql
security definer
set search_path = app, public
as $$
declare
  v_email text;
  v_app_uid text;
  v_referral_code text;
  v_profile_id uuid;
  v_referrer_id uuid;
  v_attempts int := 0;
begin
  -- Only the authenticated caller may create their own profile.
  if p_user_id is null or p_user_id <> auth.uid() then
    raise exception 'UNAUTHORIZED' using errcode = '42501';
  end if;

  -- Idempotent: return the existing profile.
  select id into v_profile_id from app.profiles where id = p_user_id;
  if v_profile_id is not null then
    return v_profile_id;
  end if;

  -- Validate inputs (mirrors client-side rules).
  if coalesce(char_length(p_display_name), 0) < 2 or char_length(p_display_name) > 30 then
    raise exception 'DISPLAY_NAME_INVALID' using errcode = 'P0001';
  end if;
  if p_ff_uid is null or p_ff_uid !~ '^[0-9]{6,12}$' then
    raise exception 'FF_UID_INVALID' using errcode = 'P0001';
  end if;
  if p_in_game_name is null or char_length(trim(p_in_game_name)) = 0 then
    raise exception 'IN_GAME_NAME_REQUIRED' using errcode = 'P0001';
  end if;
  if p_whatsapp_phone is null or p_whatsapp_phone !~ '^\+92[0-9]{10}$' then
    raise exception 'PHONE_INVALID' using errcode = 'P0001';
  end if;

  -- FF UID is unique across active accounts.
  if exists (select 1 from app.profiles where ff_uid = trim(p_ff_uid)) then
    raise exception 'FF_UID_TAKEN' using errcode = 'P0001';
  end if;

  select email into v_email from auth.users where id = p_user_id;
  if v_email is null then
    raise exception 'USER_NOT_FOUND' using errcode = 'P0001';
  end if;

  -- Generate a unique 4-digit in-app UID (retry on collision, then expand).
  loop
    v_app_uid := lpad((floor(random() * 10000))::int::text, 4, '0');
    if not exists (select 1 from app.profiles where app_uid = v_app_uid) then
      exit;
    end if;
    v_attempts := v_attempts + 1;
    if v_attempts > 200 then
      v_app_uid := lpad((floor(random() * 1000000))::int::text, 6, '0');
      if not exists (select 1 from app.profiles where app_uid = v_app_uid) then
        exit;
      end if;
    end if;
  end loop;

  -- Generate a unique referral code (no pgcrypto dependency).
  loop
    v_referral_code := upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
    if not exists (select 1 from app.profiles where referral_code = v_referral_code) then
      exit;
    end if;
  end loop;

  -- Resolve an optional referrer.
  if p_referral_code_input is not null and length(trim(p_referral_code_input)) > 0 then
    select id into v_referrer_id
    from app.profiles
    where upper(referral_code) = upper(trim(p_referral_code_input));
  end if;

  -- Create profile + wallet + stats (+ referral) in one transaction.
  insert into app.profiles (
    id, email, display_name, app_uid, ff_uid, in_game_name, whatsapp_phone,
    avatar_path, referral_code, referred_by
  ) values (
    p_user_id, v_email, trim(p_display_name), v_app_uid, trim(p_ff_uid),
    trim(p_in_game_name), p_whatsapp_phone, p_avatar_path, v_referral_code,
    v_referrer_id
  );

  insert into app.wallet_accounts (profile_id, available_balance, held_balance)
  values (p_user_id, 0, 0);

  insert into app.profile_stats (profile_id)
  values (p_user_id);

  if v_referrer_id is not null then
    insert into app.referrals (referrer_id, referred_id, reward_status)
    values (v_referrer_id, p_user_id, 'pending')
    on conflict (referred_id) do nothing;
  end if;

  return p_user_id;
end;
$$;

comment on function app.complete_profile(uuid, text, text, text, text, text, text) is
  'One-time player profile setup. SECURITY DEFINER; enforces p_user_id = auth.uid().';

-- Player App calls this via PostgREST (publishable key + user JWT).
revoke execute on function app.complete_profile(uuid, text, text, text, text, text, text) from public;
grant execute on function app.complete_profile(uuid, text, text, text, text, text, text) to authenticated;
