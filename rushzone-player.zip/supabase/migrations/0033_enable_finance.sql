-- 0033_enable_finance.sql
-- Enable real-money operations (production).
--
-- cash_operations_enabled gates all real-money behavior (top-ups, withdrawals,
-- payouts). It ships false for staging; flipping it here makes finance live.
-- withdrawal_config.enabled is the payout-rail switch within that same flag.

update app.settings
set value = 'true'::jsonb
where key = 'cash_operations_enabled';

update app.settings
set value = jsonb_set(coalesce(value, '{}'::jsonb), '{enabled}', 'true')
where key = 'withdrawal_config';
