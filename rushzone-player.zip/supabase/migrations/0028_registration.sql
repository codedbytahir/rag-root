-- 0028_registration.sql
-- Atomic tournament registration (backend gap-fill) + wallet movement helper.
--
-- The Player App calls the `tournaments-register` Edge Function, which verifies
-- the caller's JWT (profile_id must equal auth.uid()) and then invokes
-- `app.register_for_tournament` with the secret key. Both functions are
-- security definer and execute is revoked from clients.

-- ---------------------------------------------------------------------------
-- Wallet movement helper: locks the wallet row, appends an immutable ledger
-- entry, updates the balance, returns the new available balance. Idempotent
-- on p_idempotency_key.
-- ---------------------------------------------------------------------------
create or replace function app._wallet_apply(
  p_profile_id uuid,
  p_direction text,              -- 'credit' | 'debit' | 'hold' | 'release'
  p_type text,                   -- ledger_type
  p_amount bigint,
  p_ref_type text default null,
  p_ref_id uuid default null,
  p_idempotency_key text default null,
  p_note text default null
) returns bigint
language plpgsql
security definer
set search_path = app, public
as $$
declare
  v_account app.wallet_accounts%rowtype;
  v_new_available bigint;
  v_new_held bigint;
  v_balance_after bigint;
begin
  if p_amount <= 0 then
    raise exception 'INVALID_AMOUNT';
  end if;

  if p_idempotency_key is not null then
    select balance_after into v_balance_after
      from app.wallet_ledger
     where idempotency_key = p_idempotency_key;
    if found then
      return v_balance_after;
    end if;
  end if;

  select * into v_account
    from app.wallet_accounts
   where profile_id = p_profile_id
   for update;

  if not found then
    raise exception 'NO_WALLET';
  end if;

  v_new_available := v_account.available_balance;
  v_new_held := v_account.held_balance;

  if p_direction = 'credit' then
    v_new_available := v_new_available + p_amount;
  elsif p_direction = 'debit' then
    if v_new_available < p_amount then
      raise exception 'INSUFFICIENT_BALANCE';
    end if;
    v_new_available := v_new_available - p_amount;
  elsif p_direction = 'hold' then
    if v_new_available < p_amount then
      raise exception 'INSUFFICIENT_BALANCE';
    end if;
    v_new_available := v_new_available - p_amount;
    v_new_held := v_new_held + p_amount;
  elsif p_direction = 'release' then
    if v_new_held < p_amount then
      raise exception 'INSUFFICIENT_HELD';
    end if;
    v_new_held := v_new_held - p_amount;
    v_new_available := v_new_available + p_amount;
  else
    raise exception 'INVALID_DIRECTION';
  end if;

  v_balance_after := v_new_available;

  insert into app.wallet_ledger
    (profile_id, direction, type, amount, balance_after, idempotency_key,
     reference_type, reference_id, note)
  values
    (p_profile_id, p_direction::app.ledger_direction, p_type::app.ledger_type,
     p_amount, v_balance_after, p_idempotency_key, p_ref_type, p_ref_id, p_note);

  update app.wallet_accounts
     set available_balance = v_new_available,
         held_balance = v_new_held,
         version = version + 1,
         updated_at = now()
   where profile_id = p_profile_id;

  return v_balance_after;
end;
$$;

-- ---------------------------------------------------------------------------
-- Atomic registration: eligibility + capacity + slot + entry-fee debit.
-- ---------------------------------------------------------------------------
-- Drop the migration-0005 variant first: it returned uuid and `create or
-- replace` cannot change a function's return type (this one returns jsonb).
drop function if exists app.register_for_tournament(uuid, uuid, text);

create or replace function app.register_for_tournament(
  p_tournament_id uuid,
  p_profile_id uuid,
  p_idempotency_key text
) returns jsonb
language plpgsql
security definer
set search_path = app, public
as $$
declare
  v_tournament app.tournaments%rowtype;
  v_existing app.registrations%rowtype;
  v_slot int;
  v_balance bigint;
  v_registration jsonb;
begin
  select * into v_existing
    from app.registrations
   where idempotency_key = p_idempotency_key
      or (tournament_id = p_tournament_id and profile_id = p_profile_id);
  if found then
    return to_jsonb(v_existing);
  end if;

  select * into v_tournament from app.tournaments where id = p_tournament_id for update;
  if not found then
    raise exception 'TOURNAMENT_NOT_FOUND';
  end if;
  if v_tournament.status <> 'registration_open' then
    raise exception 'REGISTRATION_CLOSED';
  end if;

  if not exists (select 1 from app.profiles where id = p_profile_id) then
    raise exception 'PROFILE_INCOMPLETE';
  end if;

  if exists (
    select 1 from app.restrictions r
    where r.profile_id = p_profile_id
      and r.type in ('entry', 'suspend', 'ban')
      and (r.expires_at is null or r.expires_at > now())
      and r.lifted_at is null
  ) then
    raise exception 'RESTRICTED';
  end if;

  select coalesce(max(slot_number), 0) + 1 into v_slot
    from app.registrations where tournament_id = p_tournament_id;

  if v_slot > v_tournament.capacity then
    raise exception 'TOURNAMENT_FULL';
  end if;

  v_balance := app._wallet_apply(
    p_profile_id, 'debit', 'tournament_entry', v_tournament.entry_fee,
    'tournament', p_tournament_id, p_idempotency_key);

  insert into app.registrations
    (tournament_id, profile_id, status, slot_number, fee_snapshot, idempotency_key)
  values
    (p_tournament_id, p_profile_id, 'confirmed', v_slot, v_tournament.entry_fee, p_idempotency_key);

  -- Free-slot promotion: when the event fills, one slot becomes "gold" and
  -- that player receives a full slot_refund credit.
  if v_tournament.free_slot_enabled
     and v_tournament.free_slot_trigger = 'slots_full'
     and v_slot = v_tournament.capacity
     and v_tournament.free_slot_number is null then
    update app.tournaments
       set free_slot_number = v_slot,
           free_slot_awarded_at = now()
     where id = p_tournament_id;
    perform app._wallet_apply(
      p_profile_id, 'credit', 'slot_refund', v_tournament.entry_fee,
      'tournament', p_tournament_id, p_idempotency_key || '-refund');
  end if;

  select jsonb_build_object(
    'id', r.id,
    'tournament_id', r.tournament_id,
    'status', r.status,
    'slot_number', r.slot_number,
    'fee_snapshot', r.fee_snapshot,
    'balance_after', v_balance
  ) into v_registration
  from app.registrations r where r.idempotency_key = p_idempotency_key;

  return v_registration;
end;
$$;

-- Clients must go through the Edge Function (JWT check) — never direct RPC.
revoke execute on function app.register_for_tournament(uuid, uuid, text) from public, anon, authenticated;
revoke execute on function app._wallet_apply(uuid, text, text, bigint, text, uuid, text, text) from public, anon, authenticated;
