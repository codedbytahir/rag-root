-- 0032_coin_transfer.sql
-- Peer-to-peer coin transfer between players via WhatsApp number.
--
-- A transfer is a single atomic transaction: it debits the sender and credits
-- the recipient through the existing wallet_debit / wallet_credit primitives,
-- so idempotency, row-locking and the append-only ledger are all inherited.
-- Both sides share one caller-supplied idempotency key (suffixed ':out' / ':in')
-- so a retry can never move coins twice.

-- Players need to be notified when they receive coins.
do $$ begin
  alter type notif_type add value if not exists 'coin_transfer';
exception when duplicate_object then null;
end $$;

create or replace function app.transfer_coins(
  p_sender_id uuid,
  p_recipient_phone text,
  p_amount bigint,
  p_idempotency_key text
)
returns uuid
language plpgsql
security definer
set search_path = app, public
as $$
declare
  v_recipient app.profiles%rowtype;
  v_done uuid;
begin
  if p_amount is null or p_amount <= 0 then
    raise exception 'INVALID_AMOUNT: amount must be > 0';
  end if;

  -- Idempotency: a completed transfer already wrote the sender's debit entry.
  if p_idempotency_key is not null then
    select reference_id into v_done
    from app.wallet_ledger
    where profile_id = p_sender_id and idempotency_key = p_idempotency_key || ':out';
    if found then
      return v_done;
    end if;
  end if;

  select * into v_recipient
  from app.profiles
  where whatsapp_phone = btrim(p_recipient_phone)
  limit 1;
  if not found then
    raise exception 'RECIPIENT_NOT_FOUND: no player uses this number';
  end if;

  if v_recipient.id = p_sender_id then
    raise exception 'SELF_TRANSFER: you cannot send coins to yourself';
  end if;

  -- Debit sender, credit recipient. Both run inside this function's
  -- transaction: if the credit fails, the debit rolls back with it.
  perform app.wallet_debit(
    p_sender_id, p_amount, 'coin_transfer', 'profile_transfer', v_recipient.id,
    p_idempotency_key || ':out', p_sender_id,
    'Sent to ' || v_recipient.display_name
  );
  perform app.wallet_credit(
    v_recipient.id, p_amount, 'coin_transfer', 'profile_transfer', p_sender_id,
    p_idempotency_key || ':in', p_sender_id,
    'Received from ' || (select display_name from app.profiles where id = p_sender_id)
  );

  return v_recipient.id;
end;
$$;

grant execute on function app.transfer_coins(uuid, text, bigint, text) to service_role;

comment on function app.transfer_coins is
  'Atomic peer-to-peer coin transfer keyed by recipient WhatsApp number. Idempotent via caller key; sender debited and recipient credited in one transaction.';
