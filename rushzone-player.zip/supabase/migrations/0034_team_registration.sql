-- 0034_team_registration.sql
-- Player-created team registration (backend gap-fill).
--
-- The Player App calls the `tournaments-team-register` Edge Function, which
-- verifies the caller's JWT (leader = auth.uid()) and then invokes
-- `app.register_team_for_tournament` with the secret key. The leader pays the
-- entry fee for every member (one immutable ledger entry each) and receives
-- the prize. All effects are atomic and idempotent on the Idempotency-Key.
--
-- Requires 0028 (app._wallet_apply) and the base rosters table from 0005.

-- ---------------------------------------------------------------------------
-- Extend app.rosters for player-created teams (safe if columns already exist).
-- ---------------------------------------------------------------------------
alter table app.rosters
  add column if not exists leader_profile_id uuid references app.profiles(id),
  add column if not exists created_at timestamptz not null default now();

-- RLS: rosters currently have no select policy (default-deny). Team members
-- (including the leader) may read their own rosters; the Control app keeps
-- full access through the secret key (bypasses RLS).
alter table app.rosters enable row level security;

drop policy if exists rosters_team_member_select on app.rosters;
create policy rosters_team_member_select on app.rosters
  for select
  using (
    leader_profile_id = auth.uid()
    or exists (
      select 1
      from app.registrations r
      where r.roster_id = app.rosters.id
        and r.profile_id = auth.uid()
    )
  );

-- ---------------------------------------------------------------------------
-- Atomic team registration: eligibility + capacity + roster + slot + fees.
-- ---------------------------------------------------------------------------
create or replace function app.register_team_for_tournament(
  p_tournament_id uuid,
  p_leader_profile_id uuid,
  p_team_name text,
  p_members uuid[],
  p_idempotency_key text
) returns jsonb
language plpgsql
security definer
set search_path = app, public
as $$
declare
  v_tournament app.tournaments%rowtype;
  v_leader app.profiles%rowtype;
  v_member_profile app.profiles%rowtype;
  v_member uuid;
  v_slot int;
  v_balance bigint;
  v_roster_id uuid;
  v_team_size int;
  v_occupied int;
  v_idx int := 0;
  v_result jsonb;
begin
  if p_team_name is null or length(trim(p_team_name)) = 0 or length(trim(p_team_name)) > 40 then
    raise exception 'INVALID_TEAM_NAME';
  end if;
  if p_members is null or cardinality(p_members) < 1 or cardinality(p_members) > 10 then
    raise exception 'INVALID_TEAM_SIZE';
  end if;
  -- Dedupe member list.
  select count(distinct m) into v_team_size from unnest(p_members) as m;
  if v_team_size <> cardinality(p_members) then
    raise exception 'DUPLICATE_MEMBER';
  end if;

  -- Idempotency: leader is always p_members[1] (see Edge Function). A prior
  -- run left a registration with the '-r1' key — return that roster as-is.
  if exists (
    select 1 from app.registrations
    where idempotency_key = p_idempotency_key || '-r1'
  ) then
    select to_jsonb(r)
      into v_result
      from app.rosters r
     where r.id = (
       select roster_id
       from app.registrations
       where idempotency_key = p_idempotency_key || '-r1'
     );
    return v_result;
  end if;

  select * into v_tournament from app.tournaments where id = p_tournament_id for update;
  if not found then
    raise exception 'TOURNAMENT_NOT_FOUND';
  end if;
  if v_tournament.status <> 'registration_open' then
    raise exception 'REGISTRATION_CLOSED';
  end if;

  select * into v_leader from app.profiles where id = p_leader_profile_id;
  if not found then
    raise exception 'PROFILE_INCOMPLETE';
  end if;
  if v_leader.status <> 'active' then
    raise exception 'RESTRICTED';
  end if;
  if exists (
    select 1 from app.restrictions r
    where r.profile_id = p_leader_profile_id
      and r.type in ('entry', 'suspend', 'ban')
      and (r.expires_at is null or r.expires_at > now())
      and r.lifted_at is null
  ) then
    raise exception 'RESTRICTED';
  end if;

  -- Every member must exist, be active, and not already entered.
  foreach v_member in array p_members loop
    select * into v_member_profile from app.profiles where id = v_member;
    if not found then
      raise exception 'MEMBER_NOT_FOUND';
    end if;
    if v_member_profile.status <> 'active' then
      raise exception 'MEMBER_RESTRICTED';
    end if;
    if exists (
      select 1 from app.registrations
      where tournament_id = p_tournament_id and profile_id = v_member
    ) then
      raise exception 'ALREADY_REGISTERED';
    end if;
  end loop;

  -- Capacity: occupied seats + this team must fit. (Team members occupy
  -- one seat each, so teams never exceed the tournament capacity.)
  select count(*) into v_occupied
    from app.registrations
   where tournament_id = p_tournament_id;
  if v_occupied + v_team_size > v_tournament.capacity then
    raise exception 'TOURNAMENT_FULL';
  end if;

  insert into app.rosters (tournament_id, label, capacity, leader_profile_id)
  values (p_tournament_id, trim(p_team_name), v_team_size, p_leader_profile_id)
  returning id into v_roster_id;

  -- Leader pays the entry fee for every member (one ledger entry each).
  -- Any failure rolls the whole transaction back, roster included.
  foreach v_member in array p_members loop
    v_idx := v_idx + 1;

    v_balance := app._wallet_apply(
      p_leader_profile_id, 'debit', 'tournament_entry', v_tournament.entry_fee,
      'tournament', p_tournament_id, p_idempotency_key || '-m' || v_idx,
      'Team "' || trim(p_team_name) || '" — member ' || v_idx || ' entry fee');

    select coalesce(max(slot_number), 0) + 1 into v_slot
      from app.registrations
     where tournament_id = p_tournament_id;

    insert into app.registrations
      (tournament_id, profile_id, status, slot_number, fee_snapshot, roster_id, idempotency_key)
    values
      (p_tournament_id, v_member, 'confirmed', v_slot, v_tournament.entry_fee,
       v_roster_id, p_idempotency_key || '-r' || v_idx);
  end loop;

  -- Free-slot promotion when the event fills (mirrors individual registration).
  if v_tournament.free_slot_enabled
     and v_tournament.free_slot_trigger = 'slots_full'
     and v_occupied + v_team_size = v_tournament.capacity
     and v_tournament.free_slot_number is null then
    update app.tournaments
       set free_slot_number = v_occupied + v_team_size,
           free_slot_awarded_at = now()
     where id = p_tournament_id;
    perform app._wallet_apply(
      p_leader_profile_id, 'credit', 'slot_refund', v_tournament.entry_fee,
      'tournament', p_tournament_id, p_idempotency_key || '-refund');
  end if;

  select jsonb_build_object(
    'roster_id', v_roster_id,
    'team_name', trim(p_team_name),
    'tournament_id', p_tournament_id,
    'members', (
      select coalesce(jsonb_agg(jsonb_build_object('profile_id', r.profile_id, 'slot_number', r.slot_number)
        order by r.slot_number), '[]'::jsonb)
      from app.registrations r
      where r.roster_id = v_roster_id
    ),
    'total_fee', v_tournament.entry_fee * v_team_size,
    'balance_after', v_balance
  ) into v_result;

  return v_result;
end;
$$;

-- Clients must go through the Edge Function (JWT check) — never direct RPC.
revoke execute on function app.register_team_for_tournament(uuid, uuid, text, uuid[], text)
  from public, anon, authenticated;
