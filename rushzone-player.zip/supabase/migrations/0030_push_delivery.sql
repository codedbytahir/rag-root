-- 0030_push_delivery.sql
-- Push delivery (backend gap 3 in shared/04 §6).
--
-- Every app.notifications insert dispatches a best-effort push through the
-- Expo Push API using the device tokens stored in app.push_tokens
-- (push-token-register). The in-app inbox stays the source of truth; push is
-- best-effort and never blocks the transaction (net.http_post is async).
--
-- If pg_net is not enabled in the project, the trigger is a no-op: rows keep
-- push_status = 'pending' and the push-send Edge Function flushes them
-- (also used for retries of 'failed' rows).

-- Delivery state on the inbox rows.
alter table app.notifications
  add column if not exists push_status text not null default 'pending'
    check (push_status in ('pending', 'sent', 'failed')),
  add column if not exists pushed_at timestamptz;

create or replace function app.on_notification_insert() returns trigger
language plpgsql security definer set search_path = app, public
as $$
declare
  v_tokens text[];
  v_msg jsonb;
begin
  -- pg_net not enabled → leave row 'pending' for push-send to flush.
  if to_regnamespace('net') is null then
    return new;
  end if;

  select coalesce(array_agg(token), '{}') into v_tokens
  from app.push_tokens where profile_id = new.profile_id;
  if array_length(v_tokens, 1) is null then
    return new;
  end if;

  select jsonb_agg(
    jsonb_build_object(
      'to', t,
      'title', new.title,
      'body', new.body,
      'data', coalesce(new.data, '{}'::jsonb) || jsonb_build_object('url', new.deep_link),
      'sound', 'default',
      'channelId', 'default',
      'priority', 'high'
    )
  ) into v_msg from unnest(v_tokens) t;

  -- Async dispatch; the pg_net worker performs the HTTP request after commit.
  perform net.http_post(
    url := 'https://exp.host/--/api/v2/push/send',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Accept', 'application/json',
      'Host', 'exp.host'
    ),
    body := v_msg,
    timeout_milliseconds := 5000
  );

  update app.notifications set push_status = 'sent', pushed_at = now()
  where id = new.id;

  return new;
end;
$$;

drop trigger if exists trg_notifications_push on app.notifications;
create trigger trg_notifications_push
after insert on app.notifications
for each row execute function app.on_notification_insert();

comment on function app.on_notification_insert is
  'Best-effort Expo Push dispatch on notification insert. No-op without pg_net; push-send edge function flushes pending/failed rows.';
