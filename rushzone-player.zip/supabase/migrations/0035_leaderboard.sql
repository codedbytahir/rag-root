-- 0035_leaderboard.sql
-- Player-facing leaderboard: top 10 active players by wins.
--
-- The view runs with the owner's privileges (no security_invoker), so RLS on
-- the base tables does not apply — exactly what a public leaderboard needs.
-- Only aggregate stats + identity fields are exposed (no email, phone,
-- balance, or notes).

create or replace view app.leaderboard as
select
  p.id                                      as profile_id,
  p.display_name                            as display_name,
  p.ff_uid                                  as ff_uid,
  p.in_game_name                            as in_game_name,
  s.wins                                    as wins,
  s.top_placements                          as top_placements,
  s.total_kills                             as total_kills,
  s.total_prize_coins                       as total_prize_coins,
  s.tournaments_joined                      as tournaments_joined
from app.profiles p
join app.profile_stats s on s.profile_id = p.id
where p.status = 'active'
order by s.wins desc, s.total_prize_coins desc, s.top_placements desc
limit 10;

grant select on app.leaderboard to anon, authenticated;
