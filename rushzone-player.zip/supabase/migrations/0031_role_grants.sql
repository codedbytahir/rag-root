-- 0031_role_grants.sql
-- Base privileges for the PostgREST read/write layer (publishable key).
--
-- RLS policies were created in 0014, but base table privileges were never
-- granted to `anon` / `authenticated` (earlier migrations only granted to
-- service_role), so every publishable-key query failed with
-- "permission denied for table ...". These grants let PostgREST run as the
-- requesting role; the RLS policies remain the actual gate (tables without a
-- policy stay default-deny even with a grant).

-- Schema usage
grant usage on schema app to anon;
grant usage on schema app to authenticated;

-- Public reads (no JWT) per 0014 public-read policies
grant select on app.tournaments, app.banners, app.reward_campaigns, app.reward_items to anon;

-- Authenticated: read every app table. RLS filters to public/self rows; tables
-- with no select policy (rooms, rosters, settings, internal_notes,
-- restrictions, risk_flags) remain denied by default-deny RLS.
grant select on all tables in schema app to authenticated;

-- Authenticated writes allowed by 0014 policies:
grant update on app.notifications to authenticated;    -- notifications_self_update (mark read)
grant update on app.profiles to authenticated;         -- profiles_self_update
grant insert on app.topup_requests to authenticated;   -- topups_self_insert
grant insert on app.card_share_events to authenticated; -- share_self_insert
grant all on app.withdrawal_methods to authenticated;  -- methods_self_all
grant all on app.push_tokens to authenticated;         -- push_self_all

-- Player RPCs called directly by the app (complete_profile re-granted here for
-- idempotence with 0027)
grant execute on function app.complete_profile(uuid, text, text, text, text, text, text) to authenticated;
grant execute on function app.mark_notification_read(uuid, uuid) to authenticated;
grant execute on function app.get_wallet_me(uuid) to authenticated;
