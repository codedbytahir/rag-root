// Supabase Auth `send_email` hook.
//
// Supabase Auth generates the OTP and this hook delivers the email via
// OneSignal (ONESIGNAL_APP_ID / ONESIGNAL_REST_API_KEY).
//
// OneSignal only delivers email to addresses that exist as *subscriptions* in
// the app, so before sending we upsert the recipient as a subscriber
// (POST /apps/{app_id}/users with an Email subscription), then send the OTP
// notification to that address.
//
// Supabase Auth signs every hook request with the hook secret (Svix
// standardwebhooks format, see SEND_EMAIL_HOOK_SECRET); we verify it here, so
// this function is deployed with `--no-verify-jwt` and the signature check
// happens in-code. Without a valid signature the function rejects the request.
//
// The app itself uses supabase.auth.signInWithOtp / verifyOtp — Supabase owns
// code generation, expiry, single-use, rate limiting, and session minting.
// This hook only changes *where* the email goes.
//
// NOTE: The send_email hook is currently DISABLED on the project (Supabase's
// built-in email service is sending OTPs while we test). Re-enable it once
// OneSignal email sending is enabled on the account — see config.toml.

import { Webhook } from 'https://esm.sh/standardwebhooks@1.0.0';

const ONESIGNAL_API = 'https://api.onesignal.com/notifications';
const HOOK_SECRET = (Deno.env.get('SEND_EMAIL_HOOK_SECRET') ?? '').replace('v1,whsec_', '');

type HookPayload = {
  user: { id?: string; email: string };
  email_data: { token: string; token_hash: string; redirect_to?: string; email_action_type?: string };
};

function otpEmail(userEmail: string, code: string) {
  return {
    subject: `Your Rush Zone verification code: ${code}`,
    html: `<p>Your Rush Zone verification code is:</p><h2>${code}</h2><p>It expires in 10 minutes.</p>`,
    text: `Your Rush Zone verification code is ${code}. It expires in 10 minutes.`,
  };
}

// OneSignal requires the recipient to exist as a subscription before it will
// deliver email. Upsert is idempotent: creates the user (keyed by the Supabase
// user id when available) or updates their subscriptions.
async function ensureOneSignalSubscribed(
  appId: string,
  apiKey: string,
  userId: string | undefined,
  userEmail: string,
): Promise<void> {
  const res = await fetch(`https://api.onesignal.com/apps/${appId}/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Basic ${apiKey}` },
    body: JSON.stringify({
      ...(userId ? { identity: { external_id: userId } } : {}),
      subscriptions: [{ token: userEmail, type: 'Email' }],
    }),
  });
  if (!res.ok) throw new Error(`onesignal subscribe failed: ${res.status} ${await res.text()}`);
}

async function sendViaOneSignal(
  userId: string | undefined,
  userEmail: string,
  code: string,
): Promise<Response> {
  const appId = Deno.env.get('ONESIGNAL_APP_ID') ?? '';
  const apiKey = Deno.env.get('ONESIGNAL_REST_API_KEY') ?? '';
  if (!appId || !apiKey) throw new Error('ONESIGNAL_APP_ID/ONESIGNAL_REST_API_KEY not set');

  await ensureOneSignalSubscribed(appId, apiKey, userId, userEmail);

  const msg = otpEmail(userEmail, code);
  const res = await fetch(ONESIGNAL_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Basic ${apiKey}` },
    body: JSON.stringify({
      app_id: appId,
      include_email_tokens: [userEmail],
      email_subject: msg.subject,
      email_body: msg.html,
      email_from_name: 'Rush Zone',
    }),
  });
  return res;
}

Deno.serve(async (req) => {
  try {
    if (req.method !== 'POST') {
      return new Response('not allowed', { status: 405 });
    }

    const payload = await req.text();

    // Verify the request came from Supabase Auth (signed with the hook secret).
    const wh = new Webhook(HOOK_SECRET);
    let data: HookPayload;
    try {
      data = wh.verify(payload, Object.fromEntries(req.headers)) as HookPayload;
    } catch {
      return new Response(JSON.stringify({ error: 'invalid_signature' }), { status: 401 });
    }

    const userEmail = data?.user?.email;
    const userId = data?.user?.id;
    const code = data?.email_data?.token ?? '';
    if (!userEmail || !code) {
      return new Response(JSON.stringify({ error: 'Missing email/token' }), { status: 400 });
    }

    const res = await sendViaOneSignal(userId, userEmail, code);

    // The hook must return success with a 2xx for Supabase Auth to accept it.
    if (res.status >= 400) {
      console.error('send-email-hook failed:', res.status, await res.text());
      return new Response(JSON.stringify({ error: 'email_send_failed' }), { status: 500 });
    }
    return new Response(JSON.stringify({ success: true }));
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: 'internal' }), { status: 500 });
  }
});
