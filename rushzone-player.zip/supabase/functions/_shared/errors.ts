import { corsHeaders } from './cors.ts';

export function jsonError(
  code: string,
  message: string,
  retryable = false,
  status = 400,
): Response {
  return new Response(JSON.stringify({ error: { code, message, retryable } }), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders },
  });
}

export function jsonOk(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders },
  });
}
