import { corsHeaders } from '../_shared/cors.ts';
import { jsonError, jsonOk } from '../_shared/errors.ts';
import { createAdminClient } from '../_shared/supabase.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const authHeader = req.headers.get('authorization') ?? '';
    const idempotencyKey = req.headers.get('idempotency-key') ?? '';
    const token = authHeader.replace(/^Bearer\s+/i, '');

    if (!token) return jsonError('UNAUTHORIZED', 'Missing token', false, 401);
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(idempotencyKey)) {
      return jsonError('VALIDATION_ERROR', 'A valid Idempotency-Key header is required');
    }

    const body = await req.json().catch(() => null);
    const tournamentId = body?.tournament_id;
    const profileId = body?.profile_id;
    if (!tournamentId || !profileId) {
      return jsonError('VALIDATION_ERROR', 'tournament_id and profile_id are required');
    }

    const admin = createAdminClient();
    const { data: auth, error: authErr } = await admin.auth.getUser(token);
    if (authErr || !auth.user) {
      return jsonError('UNAUTHORIZED', 'Invalid token', false, 401);
    }
    if (auth.user.id !== profileId) {
      return jsonError('FORBIDDEN', 'profile_id must match the authenticated user', false, 403);
    }

    const { data, error } = await admin.rpc('register_for_tournament', {
      p_tournament_id: tournamentId,
      p_profile_id: profileId,
      p_idempotency_key: idempotencyKey,
    });

    if (error) {
      return jsonError(error.message ?? 'REGISTRATION_FAILED', error.message ?? 'Registration failed.');
    }
    return jsonOk(data);
  } catch {
    return jsonError('INTERNAL', 'Internal server error', true, 500);
  }
});
