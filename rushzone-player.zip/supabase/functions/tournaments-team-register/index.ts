import { corsHeaders } from '../_shared/cors.ts';
import { jsonError, jsonOk } from '../_shared/errors.ts';
import { createAdminClient } from '../_shared/supabase.ts';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const authHeader = req.headers.get('authorization') ?? '';
    const idempotencyKey = req.headers.get('idempotency-key') ?? '';
    const token = authHeader.replace(/^Bearer\s+/i, '');

    if (!token) return jsonError('UNAUTHORIZED', 'Missing token', false, 401);
    if (!UUID_RE.test(idempotencyKey)) {
      return jsonError('VALIDATION_ERROR', 'A valid Idempotency-Key header is required');
    }

    const body = await req.json().catch(() => null);
    const tournamentId = body?.tournament_id;
    const leaderProfileId = body?.profile_id; // the authenticated user
    const teamName = body?.team_name;
    const members = body?.members;

    if (!tournamentId || !leaderProfileId || !teamName || !Array.isArray(members) || members.length === 0) {
      return jsonError(
        'VALIDATION_ERROR',
        'tournament_id, profile_id, team_name and members are required',
      );
    }
    if (!UUID_RE.test(String(tournamentId)) || !UUID_RE.test(String(leaderProfileId))) {
      return jsonError('VALIDATION_ERROR', 'tournament_id and profile_id must be UUIDs');
    }
    if (members.some((m) => typeof m !== 'string' || !UUID_RE.test(m))) {
      return jsonError('VALIDATION_ERROR', 'members must be profile UUIDs');
    }
    const cleanMembers = [...new Set(members)] as string[];
    // The leader must always be the first member (used for idempotency lookup).
    if (cleanMembers[0] !== leaderProfileId) {
      return jsonError('VALIDATION_ERROR', 'profile_id (leader) must be the first member');
    }

    const admin = createAdminClient();
    const { data: auth, error: authErr } = await admin.auth.getUser(token);
    if (authErr || !auth.user) {
      return jsonError('UNAUTHORIZED', 'Invalid token', false, 401);
    }
    if (auth.user.id !== leaderProfileId) {
      return jsonError('FORBIDDEN', 'profile_id must match the authenticated user', false, 403);
    }

    const { data, error } = await admin.rpc('register_team_for_tournament', {
      p_tournament_id: tournamentId,
      p_leader_profile_id: leaderProfileId,
      p_team_name: String(teamName).trim().slice(0, 40),
      p_members: cleanMembers,
      p_idempotency_key: idempotencyKey,
    });

    if (error) {
      return jsonError(
        error.message ?? 'REGISTRATION_FAILED',
        error.message ?? 'Team registration failed.',
      );
    }
    return jsonOk(data);
  } catch {
    return jsonError('INTERNAL', 'Internal server error', true, 500);
  }
});
