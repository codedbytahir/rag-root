// push-send — flush/retry Expo Push delivery for pending/failed notifications.
//
// The notifications insert trigger (migration 0030) dispatches immediately via
// pg_net when the extension is enabled. This function is the reliable fallback
// and retry path: it batches app.notifications rows in push_status
// ('pending' | 'failed'), dispatches through the Expo Push API using the
// device tokens in app.push_tokens, and records the delivery outcome.
//
// In-app inbox remains the source of truth; push is best-effort.
//
// Auth: admin (assignment active + live session + notifications.send permission).

import { corsHeaders } from "../_shared/cors.ts";
import { jsonError, jsonOk } from "../_shared/errors.ts";
import { createAdminClient } from "../_shared/supabase.ts";

const EXPO_PUSH_URL = "https://exp.host/--/api/v2/push/send";
const BATCH = 500;

async function requirePushAdmin(req: Request): Promise<string> {
  const token = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!token) throw new Error("UNAUTHORIZED");

  const admin = createAdminClient();
  const { data: u, error } = await admin.auth.getUser(token);
  if (error || !u?.user) throw new Error("UNAUTHORIZED");

  const { data: a } = await admin
    .schema("admin")
    .from("assignments")
    .select("id, status, is_owner")
    .eq("user_id", u.user.id)
    .maybeSingle();
  if (!a || a.status !== "active") throw new Error("FORBIDDEN");

  const now = new Date().toISOString();
  const { data: session } = await admin
    .schema("admin")
    .from("sessions")
    .select("id")
    .eq("assignment_id", a.id)
    .is("revoked_at", null)
    .gt("expires_at", now)
    .limit(1)
    .maybeSingle();
  if (!session) throw new Error("FORBIDDEN");

  if (!a.is_owner) {
    const { data: v } = await admin
      .schema("admin")
      .from("assignment_permissions")
      .select("permission_keys")
      .eq("assignment_id", a.id)
      .maybeSingle();
    const perms = ((v as { permission_keys?: string } | null)?.permission_keys ?? "")
      .split(",")
      .filter(Boolean);
    if (!perms.includes("notifications.send")) throw new Error("FORBIDDEN");
  }

  return u.user.id;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return jsonError("VALIDATION_ERROR", "POST required", false, 405);

  try {
    await requirePushAdmin(req);
    const admin = createAdminClient();

    const { data: rows } = await admin
      .schema("app")
      .from("notifications")
      .select("id, profile_id, title, body, data, deep_link")
      .in("push_status", ["pending", "failed"])
      .order("created_at")
      .limit(BATCH);

    if (!rows || rows.length === 0) {
      return jsonOk({ ok: true, flushed: 0, pushed: 0, pending: 0 });
    }

    const { data: tokens } = await admin
      .schema("app")
      .from("push_tokens")
      .select("profile_id, token");

    const byProfile = new Map<string, string[]>();
    for (const t of tokens ?? []) {
      const list = byProfile.get(t.profile_id as string) ?? [];
      list.push(t.token as string);
      byProfile.set(t.profile_id as string, list);
    }

    const messages: Array<Record<string, unknown>> = [];
    const noDevice: string[] = [];
    for (const n of rows as Array<Record<string, unknown>>) {
      const toks = byProfile.get(n.profile_id as string) ?? [];
      if (toks.length === 0) {
        noDevice.push(n.id as string);
        continue;
      }
      for (const to of toks) {
        messages.push({
          to,
          title: n.title,
          body: n.body,
          data: { ...((n.data as Record<string, unknown> | null) ?? {}), url: n.deep_link ?? null, _nid: n.id },
          sound: "default",
          channelId: "default",
          priority: "high",
        });
      }
    }

    // No registered device → nothing to deliver; mark sent so the row never re-queues.
    if (noDevice.length > 0) {
      await admin
        .schema("app")
        .from("notifications")
        .update({ push_status: "sent", pushed_at: new Date().toISOString() })
        .in("id", noDevice);
    }

    let pushed = 0;
    if (messages.length > 0) {
      const res = await fetch(EXPO_PUSH_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json", Host: "exp.host" },
        body: JSON.stringify(messages),
      });
      const tickets = res.ok ? await res.json().catch(() => null) : null;

      // Tickets align 1:1 with messages; a notification is 'sent' only when every
      // device token for it was accepted by Expo.
      const perNid = new Map<string, { total: number; ok: number }>();
      messages.forEach((m, i) => {
        const nid = (m.data as Record<string, unknown>)._nid as string;
        const entry = perNid.get(nid) ?? { total: 0, ok: 0 };
        entry.total += 1;
        const ticket = Array.isArray(tickets) ? tickets[i] : undefined;
        if (res.ok && (ticket as { status?: string } | undefined)?.status === "ok") entry.ok += 1;
        perNid.set(nid, entry);
      });

      for (const [nid, s] of perNid) {
        const allOk = s.ok === s.total;
        await admin
          .schema("app")
          .from("notifications")
          .update({
            push_status: allOk ? "sent" : "pending",
            pushed_at: allOk ? new Date().toISOString() : null,
          })
          .eq("id", nid);
        if (allOk) pushed += 1;
      }
    }

    return jsonOk({ ok: true, flushed: rows.length, pushed, pending: Math.max(0, rows.length - pushed) });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "INTERNAL";
    if (msg === "UNAUTHORIZED") return jsonError("UNAUTHORIZED", "Unauthorized", false, 401);
    if (msg === "FORBIDDEN") return jsonError("FORBIDDEN", "Forbidden", false, 403);
    return jsonError("INTERNAL", "Internal server error", true, 500);
  }
});
