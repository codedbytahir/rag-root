import { corsHeaders } from '../_shared/cors.ts';
import { jsonError, jsonOk } from '../_shared/errors.ts';
import { createAdminClient } from '../_shared/supabase.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const authHeader = req.headers.get('authorization') ?? '';
    const token = authHeader.replace(/^Bearer\s+/i, '');
    if (!token) return jsonError('UNAUTHORIZED', 'Missing token', false, 401);

    const body = await req.json().catch(() => null);
    const userId = body?.user_id;
    if (!userId) return jsonError('VALIDATION_ERROR', 'user_id is required');

    const admin = createAdminClient();
    const { data: auth, error: authErr } = await admin.auth.getUser(token);
    if (authErr || !auth.user) return jsonError('UNAUTHORIZED', 'Invalid token', false, 401);
    if (auth.user.id !== userId) {
      return jsonError('FORBIDDEN', 'user_id must match the authenticated user', false, 403);
    }

    const { data, error } = await admin.rpc('complete_profile', {
      p_user_id: userId,
      p_display_name: body?.display_name,
      p_ff_uid: body?.ff_uid,
      p_in_game_name: body?.in_game_name,
      p_whatsapp_phone: body?.whatsapp_phone,
      p_avatar_path: body?.avatar_path ?? null,
      p_referral_code_input: body?.referral_code ?? null,
    });

    if (error) {
      return jsonError(error.message ?? 'PROFILE_FAILED', error.message ?? 'Profile setup failed.');
    }
    return jsonOk(data);
  } catch {
    return jsonError('INTERNAL', 'Internal server error', true, 500);
  }
});
