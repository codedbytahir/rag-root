# Rush Zone — Android Release Launch Crash: Findings & Fix

**Status: ROOT CAUSE FOUND, FIX APPLIED IN SOURCE, FINAL APK REBUILD NOT YET VERIFIED.**

The app was crashing on launch in every release build ("Rush Zone keeps stopping",
no UI ever rendered). The crash is a **pure JavaScript error at startup**, NOT an
R8/ProGuard native-module stripping issue (despite what an earlier pasted report claimed).

---

## 1. TL;DR — The crash and the fix

| | |
|---|---|
| **Symptom** | `TypeError: undefined is not a function` ~55 ms after `Running "main"`, thrown during `src/app/_layout.tsx` module evaluation, kills the app before any UI renders. |
| **Root cause** | `src/lib/errorReporter.ts` imported `{ ErrorUtils } from 'react-native'` — **RN 0.86 does not export `ErrorUtils` at runtime** (only in type defs), so it is `undefined`. The optional-chaining fallback then called `installWebHandler()`, whose guard `typeof window === 'undefined'` is **false on native** because **RN 0.86 defines `global.window = global`** (web-compat shim). It then called `window.addEventListener(...)` on the **global object**, which has no `addEventListener` → `TypeError: undefined is not a function`. |
| **Fix** | `src/lib/errorReporter.ts`: read `ErrorUtils` from the **global** (`globalThis.ErrorUtils`, which RN's polyfill sets) instead of the dead named import, and guard `installWebHandler` on `typeof window.addEventListener !== 'function'`. |
| **Proof** | On-device diagnostics (see §4) + RN source `node_modules/react-native/Libraries/Core/setUpGlobals.js:18-20` (`if (global.window === undefined) { ...; global.window = global; }`). |

---

## 2. How it was found (evidence chain)

1. Built the release APK in the cloud (Limrun) — `lim gradle build . --task :app:assembleRelease`.
2. Installed it on a remote Limrun Android emulator; it crashed on launch (launcher never even closed).
3. Got the crash trace via ADB logcat:
   ```
   com.facebook.react.common.JavascriptException: TypeError: undefined is not a function, stack:
   installGlobalErrorHandler@1:1273812
   anonymous@1:425179
   loadModuleImplementation ... loadRoute ... getRoutes ... ContextNavigator ... renderWithHooks
   ```
   → thrown during expo-router route loading, at module-eval time, attributed to `installGlobalErrorHandler()`.
4. Static bytecode analysis of the exact Hermes bundle inside the APK showed `installGlobalErrorHandler` itself is **null-guarded and provably safe** — the stack position was misleading (the APK's HBC has no debug info, so positions are garbage).
5. Instrumented `_layout.tsx` with try/catch + `console.error` around the two module-level calls. Result (on device):
   - `typeof ErrorUtils === 'undefined'` (the named import is dead)
   - `typeof installGlobalErrorHandler === 'function'` (export exists)
   - `RZ-A` caught a real throw from the `installGlobalErrorHandler()` call
   - With the call wrapped in try/catch, **the app stopped crashing** (`MainActivity` resumed, no FATAL) — this proved the throw was at that one call site and nothing else was broken.
6. Bytecode of `installWebHandler` path: `GetByIdShort window; JmpTypeOfIs L4` → when `window` is an object (it is — the global shim), it falls through to `Call window.addEventListener(...)` → callee undefined → **"undefined is not a function"**. Matches perfectly.

---

## 3. The fix (already applied to source)

**`src/lib/errorReporter.ts`** — the full corrected logic:

- `ErrorUtils` is now read from the **global**:
  ```ts
  const ErrorUtils = (globalThis as typeof globalThis & { ErrorUtils?: ErrorUtilsLike }).ErrorUtils
  ```
  RN sets `global.ErrorUtils` in `Libraries/Core/setUpErrorHandling.js` (→ `Libraries/vendor/core/ErrorUtils`), which runs at bundle init before app modules. The named import `import { ErrorUtils } from 'react-native'` is **undefined** in RN 0.86 runtime (only the `.d.ts` exports it).
- `installWebHandler()` now guards both:
  ```ts
  function installWebHandler(): void {
    if (typeof window === 'undefined') return
    if (typeof window.addEventListener !== 'function') return   // ← the fix for RN 0.86's window=global shim
    ...
  }
  ```
- `globalThis.__rzReportError` declaration kept; the `declare global` no longer re-declares `ErrorUtils` (avoided a TS redeclare conflict).

**`src/app/_layout.tsx`** — reverted to its original clean state (all temporary diagnostics removed; no net change).

**Typecheck & tests pass:** `npx tsc --noEmit` (0 errors), `npm test` (4 suites / 28 tests pass).

---

## 4. Why the pasted "Crash Fix & Build Report" was wrong

A report from another machine claimed the crash was R8 stripping native module classes (missing ProGuard keep rules for `expo.modules.**`, etc.) and prescribed:

- Rewriting `android/app/proguard-rules.pro` with huge `-keep` lists
- Moving `import 'react-native-get-random-values'` to the top of `LargeSecureStore.ts`
- Disabling New Architecture / parallel builds (host-RAM trade-offs)

**Verification result:**

| Claim | Verdict |
|---|---|
| R8 stripping native classes caused the crash | **FALSE.** The crash is a JS `TypeError`, confirmed by logcat (`JavascriptException`, not `ClassNotFoundException`/`NoSuchMethodError`). The app's native layer loaded fine (SoLoader initialized all libs, activity reached JS bundle execution). |
| `app.json` enables minify/R8 | **TRUE but irrelevant** — `expo-build-properties` plugin sets `enableMinifyInReleaseBuilds: true` etc. R8 ran, and it did not break anything observable. |
| `proguard-rules.pro` is the bare template | **TRUE** — but not the cause. Adding comprehensive keep rules is optional hardening, not a fix for this crash. |
| `LargeSecureStore.ts` import order | **TRUE that it's fragile, but not the crash.** Not applied — the crash occurs before any secure-store usage. |
| `gradle.properties` memory trade-offs | Host-specific, already reverted-style (cloud build has enough RAM). Not applied. |

The report's proposed ProGuard fix would NOT have fixed the crash. The real fix is in §3.

---

## 5. Build / environment reference (Limrun)

- **CLI**: `lim` (v0.28.0) installed via `npm install --global lim`. Docs: https://docs.limrun.com/docs/android/build-with-gradle
- **Auth**: API key stored in `~/.lim/config.yaml` (`lim set-api-key lim_...`). Workspace for this repo: `fresh-build` (`lim set-workspace-dir fresh-build --dir "$(pwd)"`).
- **Cloud build command** (Expo pipeline: npm install + `expo prebuild` + gradle on a fresh sandbox):
  ```bash
  lim gradle build . --task :app:assembleRelease --upload rushzone.apk
  ```
  Note: `android/`, `node_modules/`, `.env` are gitignored → not synced; the sandbox regenerates them. The APK therefore uses the **production fallback config** baked into `app.config.ts` (`EXPO_PUBLIC_APP_ENV=production`, Supabase project `gwtipxyhyalikdaqnvdp.supabase.co`).
- **Corrupt-cache gotcha**: a sandbox can hit `ZipException: invalid stored block lengths` (corrupt Gradle cache). Fix: delete the instance (`lim gradle delete <id>`) or switch to a fresh workspace so a new sandbox is provisioned.
- **Signed download URL** from a build expires in 15 min; refresh with `lim asset list --name rushzone.apk --download-url`.

### Remote Android emulator (crash repro + verification)

- Instance: `android_usea_01m01t2d2zfprvxbngmg9h4sxe` (may need recreating; it's disposable)
- Create with app preinstalled: `lim android create --install-asset rushzone.apk --reuse-if-exists`
- Console/stream: `lim android get <id>` → Console URL (streams the screen in a browser)
- **ADB**: binary at `/opt/android-sdk/platform-tools/adb`. Tunnel:
  ```bash
  export PATH=/opt/android-sdk/platform-tools:$PATH
  setsid nohup lim android connect --id <instance-id> > /tmp/lim_tunnel.log 2>&1 < /dev/null &
  adb devices   # → 127.0.0.1:<port>  device
  ```
  (Must run detached — the CLI command blocks while the tunnel is live. `setsid nohup ... &` survives tool-call boundaries.)
- **Watch crash logs**: `adb -s 127.0.0.1:<port> logcat -d | grep -E 'FATAL|AndroidRuntime|ReactNativeJS'`
- Launch: `adb -s <dev> shell am start -n com.rushzone.app/.MainActivity`
- Pull the installed APK: `adb pull $(adb shell pm path com.rushzone.app | sed 's/package://') app.apk`

### Artifacts (Limrun asset storage)

| Asset | Content |
|---|---|
| `rushzone.apk` | **OLD build — still the crashing one** (uploaded before the fix; last final rebuild was interrupted) |
| `rushzone-dbg.apk` / `rushzone-dbg2.apk` | Diagnostic builds with try/catch — prove the app survives when the throw is contained |

Local copy of the OLD APK exists at `rushzone.apk` (project root, 20 MB, untracked).

---

## 6. Current repo state

Uncommitted changes on `main`:

- **`src/lib/errorReporter.ts`** ← THE FIX (+22/−3)
- Pre-existing (from before this task, NOT mine): `app.config.ts`, `package.json`, `package-lock.json`, `src/lib/env.ts`, `src/lib/supabase.ts`, untracked `__tests__/env.test.ts`, `build_apk.sh`, `rushzone-user.zip`, plus the local `rushzone.apk` (old crashing build).

`src/app/_layout.tsx` is byte-identical to the committed version (diagnostics removed).

---

## 7. NEXT STEPS for the next agent

1. **Rebuild the fixed APK on Limrun** (was interrupted):
   ```bash
   lim gradle build . --task :app:assembleRelease --upload rushzone.apk
   ```
2. **Reinstall on the emulator and verify no crash + UI renders:**
   ```bash
   # download the fresh signed URL printed by the build, then:
   adb -s <dev> install -r rushzone.apk
   adb -s <dev> shell am start -n com.rushzone.app/.MainActivity
   adb -s <dev> logcat -d | grep -E 'FATAL|AndroidRuntime|ReactNativeJS'
   ```
   Expected: **no FATAL**, `Running "main"` then the launch screen ("RUSH ZONE / PLAYER APP"), then the **login screen** (email/password — production env; auth gate routes `signedOut → /login`). Check with `lim android element-tree` / screenshot.
3. Optional hardening (NOT required for the crash): if R8 minification is kept on, a comprehensive `proguard-rules.pro` (`-keep class expo.modules.**`, `com.facebook.react.**`, etc.) is good practice — but keep the file in a place that survives `expo prebuild` (e.g. root `proguard-rules.pro` if supported by the SDK's prebuild, otherwise patch after prebuild). Confirm against the SDK version before relying on prebuild to copy it.
4. Optional: `src/lib/LargeSecureStore.ts` — move `import 'react-native-get-random-values'` to the very top (defensive, not the crash).
5. Cleanup: the emulator instance and background tunnel can be deleted (`lim android delete <id>`; kill the setsid'd `lim android connect` process).

---

*Investigation date: 2026-08-15. Environment: Expo SDK 57 / React Native 0.86.2, Limrun cloud build + Android emulator, Hermes bytecode (version 98) bundles.*
