import type { ExpoConfig } from 'expo/config'

/**
 * Public values — safe to commit. The publishable key is designed to ship in
 * the client and RLS is the real gate. These act as a fallback so the app
 * always boots with a working Supabase client even if build-time env vars
 * (.env / EAS project vars) are unavailable in a given build pipeline.
 *
 * Precedence: build-time EXPO_PUBLIC_* env vars win over these defaults.
 */
const PUBLIC_FALLBACK = {
  EXPO_PUBLIC_SUPABASE_URL: 'https://gwtipxyhyalikdaqnvdp.supabase.co',
  EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY: 'sb_publishable_941EchiFjbq9HSc2TQi1xA_iJytPQB4',
  EXPO_PUBLIC_APP_ENV: 'production',
} as const

/** Treat empty/whitespace env vars as unset so the fallback always applies. */
const value = (v: string | undefined, fallback: string): string => (v ?? '').trim() || fallback

export default ({ config }: { config: ExpoConfig }): ExpoConfig => ({
  ...config,
  extra: {
    ...(config.extra ?? {}),
    publicEnv: {
      EXPO_PUBLIC_SUPABASE_URL: value(
        process.env.EXPO_PUBLIC_SUPABASE_URL,
        PUBLIC_FALLBACK.EXPO_PUBLIC_SUPABASE_URL,
      ),
      EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY: value(
        process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
        PUBLIC_FALLBACK.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
      ),
      EXPO_PUBLIC_APP_ENV: value(
        process.env.EXPO_PUBLIC_APP_ENV,
        PUBLIC_FALLBACK.EXPO_PUBLIC_APP_ENV,
      ),
    },
  },
})
