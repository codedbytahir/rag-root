// https://docs.expo.dev/guides/using-eslint/
const { defineConfig } = require('eslint/config');
const expoConfig = require("eslint-config-expo/flat");

module.exports = defineConfig([
  expoConfig,
  {
    ignores: ["dist/*", "supabase/**"], // Deno Edge Functions aren't part of the RN app lint scope
  },
  {
    rules: {
      // New React Compiler-era rules. This project does not enable the React
      // Compiler (app.json `experiments.reactCompiler` is off), and these two
      // flag standard async data-fetch-on-mount patterns as false positives.
      "react-hooks/set-state-in-effect": "off",
      "react-hooks/preserve-manual-memoization": "off",
    },
  },
]);
