import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { callEdge } from './api';

/**
 * Register this device's Expo push token with the backend (best-effort).
 * Push is not the source of truth — the in-app inbox is. Failures never block.
 */
export async function registerPushToken(): Promise<void> {
  // Push tokens are native-only; expo-notifications has no push support on web.
  if (Platform.OS === 'web') return;
  if (!Device.isDevice) return;

  try {
    const current = await Notifications.getPermissionsAsync();
    let granted = current.status === 'granted';
    if (current.status !== 'granted' && current.status !== 'denied') {
      const req = await Notifications.requestPermissionsAsync();
      granted = req.status === 'granted';
    }
    if (!granted) return;

    const token = await Notifications.getExpoPushTokenAsync();
    await callEdge('push-token-register', {
      token: token.data,
      platform: Platform.OS,
      device: Device.modelName ?? undefined,
    });
  } catch {
    // best-effort — never throw into the app flow
  }
}

/** Configure how foreground notifications are presented. */
export function configureNotifications(): void {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldShowBanner: true,
      shouldShowList: true,
      shouldPlaySound: false,
      shouldSetBadge: false,
    }),
  });
}
