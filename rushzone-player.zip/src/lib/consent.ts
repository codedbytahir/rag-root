import AsyncStorage from '@react-native-async-storage/async-storage'

const KEY = 'rz.consent.accepted'

/**
 * MVP policy-consent tracking. The spec requires recording accepted policy
 * versions/timestamps; until the server table lands we store a local flag.
 * A material policy change re-prompts by clearing this key.
 */
export async function hasAcceptedConsent(): Promise<boolean> {
  try {
    return (await AsyncStorage.getItem(KEY)) === '1'
  } catch {
    return false
  }
}

export async function recordConsent(): Promise<void> {
  await AsyncStorage.setItem(KEY, '1')
}

export async function clearConsent(): Promise<void> {
  await AsyncStorage.removeItem(KEY)
}
