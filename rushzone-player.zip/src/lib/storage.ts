import { supabase } from './supabase';

/**
 * Public URL for an object in a public bucket (avatars, banners,
 * tournament-thumbnails). Returns null for empty paths.
 */
export function publicStorageUrl(bucket: string, path?: string | null): string | null {
  if (!path) return null;
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data?.publicUrl ?? null;
}
