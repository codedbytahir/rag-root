import * as ImagePicker from 'expo-image-picker'
import * as ImageManipulator from 'expo-image-manipulator'
import { File } from 'expo-file-system'
import { supabase } from './supabase'
import { uuidv4 } from './idempotency'

const BUCKET = 'avatars'
const MAX_DIM = 512

/** Open the image library and return a resized local URI (≤512px JPEG). */
export async function pickAndResizeAvatar(): Promise<string | null> {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync()
  if (!perm.granted) return null

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    allowsEditing: true,
    aspect: [1, 1],
    quality: 1,
  })
  const asset = result.assets?.[0]
  if (result.canceled || !asset) return null

  const resized = await ImageManipulator.manipulateAsync(
    asset.uri,
    [{ resize: { width: MAX_DIM, height: MAX_DIM } }],
    { compress: 0.7, format: ImageManipulator.SaveFormat.JPEG },
  )
  return resized.uri
}

/**
 * Upload a resized avatar to the `avatars` bucket under the user's id.
 * Best-effort: returns the storage path or null on any failure so profile
 * setup can proceed without an avatar.
 */
export async function uploadAvatar(uid: string, localUri: string): Promise<string | null> {
  try {
    const file = new File(localUri)
    const bytes = await file.arrayBuffer()
    const path = `${uid}/${uuidv4()}.jpg`
    const { error } = await supabase.storage.from(BUCKET).upload(path, bytes, {
      contentType: 'image/jpeg',
      upsert: false,
    })
    if (error) return null
    return path
  } catch {
    return null
  }
}
