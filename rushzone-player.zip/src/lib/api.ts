import { supabase } from './supabase';
import { env } from './env';
import { uuidv4 } from './idempotency';

export type ApiErrorShape = {
  code: string;
  message: string;
  retryable: boolean;
};

export type ApiResult<T> = {
  data: T | null;
  error: ApiErrorShape | null;
};

const REQUEST_FAILED: ApiErrorShape = {
  code: 'REQUEST_FAILED',
  message: 'Request failed. Please try again.',
  retryable: true,
};

interface RequestOptions {
  method?: 'GET' | 'POST';
  body?: Record<string, unknown>;
  query?: Record<string, string>;
  idempotencyKey?: string;
}

async function request<T>(name: string, options: RequestOptions): Promise<ApiResult<T>> {
  const {
    data: { session },
  } = await supabase.auth.getSession();

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    apikey: env.supabasePublishableKey,
  };
  if (session) headers.Authorization = `Bearer ${session.access_token}`;
  if (options.idempotencyKey) headers['Idempotency-Key'] = options.idempotencyKey;

  const query = options.query ? `?${new URLSearchParams(options.query).toString()}` : '';

  try {
    const res = await fetch(`${env.functionsBaseUrl}/${name}${query}`, {
      method: options.method ?? 'POST',
      headers,
      body: options.body ? JSON.stringify(options.body) : undefined,
    });

    const text = await res.text();
    let json: unknown = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }

    if (!res.ok) {
      const err = (json as { error?: ApiErrorShape } | null)?.error;
      return { data: null, error: err ?? REQUEST_FAILED };
    }
    return { data: json as T, error: null };
  } catch {
    return { data: null, error: { ...REQUEST_FAILED, retryable: true } };
  }
}

/**
 * Call an authenticated Edge Function (user JWT attached). Every mutation is
 * idempotent by default — a fresh UUID Idempotency-Key is generated per call
 * so retries can never double-apply money/registration/reward effects.
 */
export function callEdge<T = unknown>(
  name: string,
  body?: Record<string, unknown>,
  options: { idempotencyKey?: string } = {},
): Promise<ApiResult<T>> {
  return request<T>(name, {
    method: 'POST',
    body,
    idempotencyKey: options.idempotencyKey ?? uuidv4(),
  });
}

/** Call a public Edge Function (no auth required, e.g. app-config/app-version). */
export function callPublic<T = unknown>(
  name: string,
  query?: Record<string, string>,
): Promise<ApiResult<T>> {
  return request<T>(name, { method: 'GET', query });
}
