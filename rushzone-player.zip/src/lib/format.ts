const PKT = 'Asia/Karachi';

function toDate(iso?: string | null): Date | null {
  if (!iso) return null;
  const d = new Date(iso);
  return isNaN(d.getTime()) ? null : d;
}

/** Full date + time in PKT (Asia/Karachi). */
export function formatPKTDateTime(iso?: string | null): string {
  const d = toDate(iso);
  if (!d) return '—';
  return new Intl.DateTimeFormat('en-US', {
    timeZone: PKT,
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  }).format(d);
}

export function formatPktDateTime(iso?: string | null): string {
  return formatPKTDateTime(iso);
}

export function formatPktDate(iso?: string | null): string {
  const d = toDate(iso);
  if (!d) return '—';
  return new Intl.DateTimeFormat('en-US', {
    timeZone: PKT,
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(d);
}

export function formatPktTime(iso?: string | null): string {
  const d = toDate(iso);
  if (!d) return '—';
  return new Intl.DateTimeFormat('en-US', {
    timeZone: PKT,
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  }).format(d);
}

export function formatPktShort(iso?: string | null): string {
  const d = toDate(iso);
  if (!d) return '—';
  return new Intl.DateTimeFormat('en-US', {
    timeZone: PKT,
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  }).format(d);
}

/** Whole integer coins with grouping. */
export function formatCoins(value: number | string | null | undefined): string {
  const n = typeof value === 'string' ? Number(value) : value ?? 0;
  if (!Number.isFinite(n)) return '0';
  return new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(Math.round(n));
}

/** 1 Rush Coin = PKR 1. */
export function coinsToPkr(value: number | string | null | undefined): string {
  return `PKR ${formatCoins(value)}`;
}

export function maskEmail(email?: string | null): string {
  if (!email) return '';
  const [user, domain] = email.split('@');
  if (!user || !domain) return email;
  const head = user.slice(0, 1);
  const tail = user.slice(-1);
  const masked =
    user.length <= 2 ? `${head}*` : `${head}${'*'.repeat(Math.max(1, user.length - 2))}${tail}`;
  return `${masked}@${domain}`;
}

/** Mask E.164 phone: +92 3xx •••• 1234. */
export function maskPhone(phone?: string | null): string {
  if (!phone) return '';
  const digits = phone.replace(/\D/g, '');
  if (digits.length < 7) return phone;
  const last4 = digits.slice(-4);
  const first = digits.slice(0, 3);
  return `+${first} •••• ${last4}`;
}

export function initials(name?: string | null): string {
  if (!name) return '?';
  return name
    .split(/\s+/)
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

// ---------------------------------------------------------------------------
// Profile field validators (mirror the server rules in the migrations).
// ---------------------------------------------------------------------------

export function isValidDisplayName(name: string): boolean {
  const s = name.trim();
  if (s.length < 2 || s.length > 30) return false;
  return /^[\p{L}\p{N} _.'-]+$/u.test(s);
}

/** Free Fire UID: numeric, 6–12 digits. */
export function isValidFFUID(input: string): boolean {
  return /^[0-9]{6,12}$/.test(input.trim());
}

/**
 * Normalize a Pakistan mobile number to E.164 (+92…). Returns null if invalid.
 * Accepts +92…, 92…, 03…, or 3… forms.
 */
export function normalizeWhatsappPhone(input: string): string | null {
  let digits = input.replace(/[^\d+]/g, '');
  digits = digits.replace(/^\+/, '');
  if (digits.startsWith('92') && digits.length === 12) {
    // already E.164
  } else if (digits.startsWith('03') && digits.length === 11) {
    digits = '92' + digits.slice(1);
  } else if (digits.startsWith('3') && digits.length === 10) {
    digits = '92' + digits;
  } else {
    return null;
  }
  if (!/^92[0-9]{10}$/.test(digits)) return null;
  return `+${digits}`;
}

export function isValidWhatsappPhone(input: string): boolean {
  return normalizeWhatsappPhone(input) !== null;
}
