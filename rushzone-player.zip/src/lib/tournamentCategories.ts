import type { ComponentProps } from 'react'
import { Ionicons } from '@expo/vector-icons'
import { prettyMode } from './tournaments'
import type { TournamentsRow } from './database.types'

export type IoniconName = ComponentProps<typeof Ionicons>['name']

export interface TournamentCategory {
  key: string
  label: string
  icon: IoniconName
  /** Known spellings of the mode in the DB (compared after normalizing). */
  aliases: string[]
}

/**
 * The tournament categories shown as cards on Home and as folders in the
 * Tournaments tab. Matching is flexible so the cards work no matter how the
 * mode value is stored ('solo', 'br_solo', 'battle royale solo', …).
 */
export const CATEGORIES: TournamentCategory[] = [
  {
    key: 'br_solo',
    label: 'Battle Royale Solo',
    icon: 'person-outline',
    aliases: ['solo', 'brsolo', 'battleroyalesolo', 'battle-royale-solo', 'battle royale solo'],
  },
  {
    key: 'br_duo',
    label: 'Battle Royale Duo',
    icon: 'people-outline',
    aliases: ['duo', 'brduo', 'battleroyaleduo', 'battle-royale-duo', 'battle royale duo'],
  },
  {
    key: 'br_squad',
    label: 'Battle Royale Squad',
    icon: 'shield-outline',
    aliases: ['squad', 'brsquad', 'battleroyalesquad', 'battle-royale-squad', 'battle royale squad'],
  },
  {
    key: 'cs_1v1',
    label: 'CS 1v1',
    icon: 'flash-outline',
    aliases: ['cs1v1', 'cs 1v1', 'cs1vs1', 'cs 1 vs 1', 'counterstrike1v1'],
  },
  {
    key: 'cs_2v2',
    label: 'CS 2v2',
    icon: 'flash-outline',
    aliases: ['cs2v2', 'cs 2v2', 'cs2vs2', 'cs 2 vs 2', 'counterstrike2v2'],
  },
  {
    key: 'cs_4v6',
    label: 'CS 4v6',
    icon: 'flame-outline',
    aliases: ['cs4v6', 'cs 4v6', 'cs4vs6', 'cs 4 vs 6', 'counterstrike4v6'],
  },
  {
    key: 'lonewolf_1v1',
    label: 'Lone Wolf 1v1',
    icon: 'paw-outline',
    aliases: ['lonewolf1v1', 'lonewolf', 'lone wolf 1v1', 'lw1v1', 'lonewolf1vs1'],
  },
  {
    key: 'lw_low_entry',
    label: 'LW Low Entry',
    icon: 'trending-down-outline',
    aliases: ['lwlowentry', 'lw low entry', 'lowentry', 'lw-low-entry', 'lw low-entry'],
  },
]

/** Lowercase + strip non-alphanumerics for tolerant comparisons. */
export function normalizeModeKey(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]/g, '')
}

export function findCategory(categoryOrMode: string): TournamentCategory | null {
  const n = normalizeModeKey(categoryOrMode)
  if (!n) return null
  return (
    CATEGORIES.find((c) => normalizeModeKey(c.key) === n) ??
    CATEGORIES.find((c) => c.aliases.some((a) => normalizeModeKey(a) === n)) ??
    null
  )
}

/** True when a tournament's mode belongs to the given filter (key or alias). */
export function modeMatchesFilter(mode: string | null | undefined, filter: string): boolean {
  const f = normalizeModeKey(filter)
  if (!f) return false
  const n = normalizeModeKey(mode ?? '')
  if (n === f) return true
  const cat = findCategory(f)
  if (!cat) return false
  return cat.aliases.some((a) => normalizeModeKey(a) === n)
}

/** Pretty label for a raw mode value ('solo' → 'Battle Royale Solo'). */
export function labelForMode(mode: string | null | undefined): string {
  const cat = mode ? findCategory(mode) : null
  return cat ? cat.label : prettyMode(mode)
}

/** Icon for a raw mode value, falling back to a plain folder. */
export function iconForMode(mode: string | null | undefined): IoniconName {
  const cat = mode ? findCategory(mode) : null
  return cat ? cat.icon : 'folder-outline'
}

export interface CategoryFolder {
  key: string
  label: string
  icon: IoniconName
  count: number
}

/** Modes where the whole team registers together (normalized keys). */
const DUO_MODES = new Set(['duo', 'brduo', 'battleroyaleduo', 'cs2v2', 'cs2vs2', 'counterstrike2v2'])
const SQUAD_MODES = new Set([
  'squad',
  'brsquad',
  'battleroyalesquad',
  'cs4v6',
  'cs4vs6',
  'counterstrike4v6',
])

/**
 * Players per team for a mode (1 = individual entry). Unknown modes default
 * to individual so they never break the join flow.
 */
export function teamSizeForMode(mode: string | null | undefined): number {
  const n = normalizeModeKey(mode ?? '')
  if (DUO_MODES.has(n)) return 2
  if (SQUAD_MODES.has(n)) return 4
  return 1
}

/** True when a tournament expects a whole team to register together. */
export function isTeamTournament(mode: string | null | undefined): boolean {
  return teamSizeForMode(mode) > 1
}

/**
 * Build the folder list for a set of tournaments: curated categories first
 * (in display order), then any unrecognized modes alphabetically.
 */
export function buildCategoryFolders(list: TournamentsRow[]): CategoryFolder[] {
  const counts = new Map<string, number>()
  const meta = new Map<string, { label: string; icon: IoniconName }>()
  for (const t of list) {
    const cat = findCategory(t.mode ?? '')
    const key = cat ? cat.key : normalizeModeKey(t.mode ?? '') || 'other'
    counts.set(key, (counts.get(key) ?? 0) + 1)
    meta.set(key, cat ? { label: cat.label, icon: cat.icon } : { label: prettyMode(t.mode), icon: 'folder-outline' })
  }
  const known = CATEGORIES.map((c) => c.key).filter((k) => counts.has(k))
  const unknown = Array.from(counts.keys())
    .filter((k) => !CATEGORIES.some((c) => c.key === k))
    .sort()
  return [...known, ...unknown].map((key) => ({
    key,
    label: meta.get(key)?.label ?? prettyMode(key),
    icon: meta.get(key)?.icon ?? 'folder-outline',
    count: counts.get(key) ?? 0,
  }))
}
