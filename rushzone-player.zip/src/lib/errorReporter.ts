declare global {
  // eslint-disable-next-line no-var
  var __rzReportError:
    | ((error: unknown, componentStack?: string, isFatal?: boolean) => void)
    | undefined
}

type ErrorUtilsLike = {
  getGlobalHandler?: () => ((error: unknown, isFatal: boolean) => void) | undefined
  setGlobalHandler?: (handler: (error: unknown, isFatal: boolean) => void) => void
}

/**
 * ErrorUtils is a global set up by React Native (Libraries/Core/setUpErrorHandling,
 * via Libraries/vendor/core/ErrorUtils). It is NOT exported from the 'react-native'
 * package at runtime in RN 0.86+ — only from its type definitions — so a named
 * import would resolve to `undefined` and silently break the error handler.
 */
const ErrorUtils = (globalThis as typeof globalThis & { ErrorUtils?: ErrorUtilsLike }).ErrorUtils

/** Last uncaught error — surfaced by the fatal screen if the app is relaunched. */
let lastError: { message: string; at: number } | null = null

export function getLastReportedError(): { message: string; at: number } | null {
  return lastError
}

async function reportToObserve(error: unknown, componentStack?: string) {
  try {
    // expo-observe (SDK 57) can record JS errors. Lazy import keeps this safe
    // even if the module is ever removed from the bundle.
    const observe = (await import('expo-observe')) as typeof import('expo-observe')
    observe.Observe.reportError(error)
    if (componentStack) {
      observe.Observe.logEvent('error.componentStack', {
        attributes: { componentStack },
      })
    }
  } catch {
    // never let reporting break the app
  }
}

/**
 * Install a global handler for uncaught JS errors. In release builds an
 * unhandled exception normally kills the app with no explanation; this records
 * the exact message and forwards it to EAS Observe. Call once at startup.
 *
 * Platform-safe: `ErrorUtils` only exists on native (react-native-web does not
 * provide it), so on web we fall back to the window `error` event.
 */
export function installGlobalErrorHandler(): void {
  // Capture the ORIGINAL handler (RedBox in dev, native termination in release)
  // BEFORE replacing it. Calling `ErrorUtils.getGlobalHandler()` after
  // `setGlobalHandler` returns our own wrapper, which would recurse forever.
  const originalHandler = ErrorUtils?.getGlobalHandler?.()

  globalThis.__rzReportError = (error, componentStack, isFatal = false) => {
    const err = error instanceof Error ? error : new Error(String(error))
    lastError = { message: err.message || err.name || 'Unknown error', at: Date.now() }
    void reportToObserve(error, componentStack)
    // Preserve the original behavior (RedBox in dev, termination in release).
    try {
      originalHandler?.(error, isFatal)
    } catch {
      // no-op — original handler unavailable
    }
  }

  if (!ErrorUtils?.setGlobalHandler) {
    installWebHandler()
    return
  }

  ErrorUtils.setGlobalHandler((error, isFatal) => {
    globalThis.__rzReportError?.(error, undefined, isFatal)
    if (isFatal) {
      // Last chance to surface the message before the process dies — log it.
      // eslint-disable-next-line no-console
      console.error('RushZone fatal error:', error)
    }
  })
}

/**
 * Web fallback: catch window error/unhandledrejection events.
 *
 * NOTE: RN 0.86+ defines `global.window = global` on native for web compat, so
 * `typeof window === 'undefined'` is NOT enough to detect web. The global object
 * has no `addEventListener`, so guard on it too — otherwise this path throws
 * "undefined is not a function" at startup on Android.
 */
function installWebHandler(): void {
  if (typeof window === 'undefined') return
  if (typeof window.addEventListener !== 'function') return
  window.addEventListener('error', (event) => {
    globalThis.__rzReportError?.(event.error ?? new Error(event.message))
  })
  window.addEventListener('unhandledrejection', (event) => {
    globalThis.__rzReportError?.(event.reason)
  })
}
