import * as Sharing from 'expo-sharing'
import type { ViewShotRef } from 'react-native-view-shot'
import { callEdge } from './api'

export type ShareCardType = 'result' | 'win' | 'prize' | 'streak' | 'spin' | 'referral' | 'profile'

/** Default share format per card type — profile/referral are square by design. */
export function defaultCardFormat(type: ShareCardType): 'story' | 'square' {
  return type === 'profile' || type === 'referral' ? 'square' : 'story'
}

/**
 * Capture a rendered card (a <ViewShot ref>) to a PNG and open the system
 * share sheet. Returns null on success or an exact, user-readable error message
 * on failure. Never throws.
 */
export async function shareCardImage(viewShotRef: ViewShotRef | null): Promise<string | null> {
  try {
    if (!viewShotRef?.capture) {
      return 'The share card isn’t ready yet. Try again in a moment.'
    }
    const uri = await viewShotRef.capture()
    if (!(await Sharing.isAvailableAsync())) {
      return 'Sharing isn’t available on this device.'
    }
    await Sharing.shareAsync(uri, {
      mimeType: 'image/png',
      dialogTitle: 'Share your Rush Zone card',
      UTI: 'public.png',
    })
    return null
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e)
    return `Couldn’t create the share card (${message}). Please try again.`
  }
}

/** Record a marketing-card share for attribution (fire-and-forget). */
export function recordShareEvent(
  cardType: ShareCardType,
  channel?: string,
  refType?: string,
  refId?: string,
): void {
  void callEdge('share-event', {
    card_type: cardType,
    channel: channel ?? null,
    ref_type: refType ?? null,
    ref_id: refId ?? null,
  })
}
