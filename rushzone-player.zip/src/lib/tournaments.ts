import type { TournamentStatus, TournamentsRow } from './database.types'

export type ChipTone = 'success' | 'danger' | 'neutral' | 'info'

interface StatusMeta {
  label: string
  tone: ChipTone
}

/** Human label + chip tone for each publicly visible lifecycle status. */
export function statusMeta(status: TournamentStatus): StatusMeta | null {
  switch (status) {
    case 'registration_open':
      return { label: 'Open', tone: 'success' }
    case 'registration_full':
      return { label: 'Full', tone: 'danger' }
    case 'registration_closed':
      return { label: 'Closed', tone: 'neutral' }
    case 'scheduled':
      return { label: 'Upcoming', tone: 'info' }
    case 'room_released':
      return { label: 'Room Ready', tone: 'success' }
    case 'live':
      return { label: 'Live', tone: 'info' }
    case 'results_pending':
      return { label: 'Results Soon', tone: 'info' }
    case 'completed':
      return { label: 'Completed', tone: 'neutral' }
    default:
      return null // draft / cancelled are never shown to players
  }
}

/** Statuses a player can browse (excludes draft/cancelled). */
export const BROWSEABLE_STATUSES: TournamentStatus[] = [
  'scheduled',
  'registration_open',
  'registration_full',
  'registration_closed',
  'room_released',
  'live',
  'results_pending',
  'completed',
]

export function canRegister(status: TournamentStatus): boolean {
  return status === 'registration_open'
}

/** Matches currently running or about to resolve. */
export const ONGOING_STATUSES: TournamentStatus[] = ['room_released', 'live', 'results_pending']
/** Matches that haven't started yet. */
export const UPCOMING_STATUSES: TournamentStatus[] = [
  'scheduled',
  'registration_open',
  'registration_full',
  'registration_closed',
]
/** Finished matches. */
export const COMPLETED_STATUSES: TournamentStatus[] = ['completed']

export function isOngoing(status: TournamentStatus): boolean {
  return ONGOING_STATUSES.includes(status)
}

export function isUpcoming(status: TournamentStatus): boolean {
  return UPCOMING_STATUSES.includes(status)
}

export function isCompleted(status: TournamentStatus): boolean {
  return COMPLETED_STATUSES.includes(status)
}

export interface TournamentSection {
  key: string
  title: string
  tournaments: TournamentsRow[]
}

/**
 * Split a tournament list into Ongoing / Upcoming / Completed sections,
 * dropping empty sections.
 */
export function groupTournamentSections(list: TournamentsRow[]): TournamentSection[] {
  return [
    { key: 'ongoing', title: 'Ongoing', tournaments: list.filter((t) => isOngoing(t.status)) },
    { key: 'upcoming', title: 'Upcoming', tournaments: list.filter((t) => isUpcoming(t.status)) },
    { key: 'completed', title: 'Completed', tournaments: list.filter((t) => isCompleted(t.status)) },
  ].filter((s) => s.tournaments.length > 0)
}

/** Pretty display label for a tournament mode ('solo' → 'Solo'). */
export function prettyMode(mode: string | null | undefined): string {
  if (!mode) return 'All'
  return mode.charAt(0).toUpperCase() + mode.slice(1)
}

/** Title-case a map/folder name ('erangel' → 'Erangel', 'nusa penida' → 'Nusa Penida'). */
export function prettyMap(map: string | null | undefined): string {
  if (!map) return '—'
  return map
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ')
}
