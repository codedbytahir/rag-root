import Constants from 'expo-constants'

/** Build-time env vars (inlined by babel-preset-expo from .env / EAS vars). */
const buildEnv = {
  supabaseUrl: process.env.EXPO_PUBLIC_SUPABASE_URL ?? '',
  supabasePublishableKey: process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? '',
  appEnv: process.env.EXPO_PUBLIC_APP_ENV ?? '',
} as const

/**
 * Fallback values baked into the app config (see app.config.ts). They keep the
 * app bootable even when build-time env vars are unavailable.
 */
const configEnv =
  (Constants.expoConfig?.extra as { publicEnv?: Record<string, string> } | undefined)
    ?.publicEnv ?? {}

const clean = (v: string | undefined): string => (v ?? '').trim()

export const env = {
  supabaseUrl: clean(buildEnv.supabaseUrl) || clean(configEnv.EXPO_PUBLIC_SUPABASE_URL) || '',
  supabasePublishableKey:
    clean(buildEnv.supabasePublishableKey) ||
    clean(configEnv.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY) ||
    '',
  appEnv: clean(buildEnv.appEnv) || clean(configEnv.EXPO_PUBLIC_APP_ENV) || 'development',
  /**
   * True when the app cannot reach its backend. `createClient` throws on an
   * empty or non-http(s) URL — that throw would happen at module-eval time,
   * before any error handler is installed, so we detect it here instead of
   * crashing silently at launch.
   */
  get isMisconfigured(): boolean {
    return !this.supabaseUrl || !this.supabasePublishableKey || !/^https?:\/\//.test(this.supabaseUrl)
  },
  get functionsBaseUrl(): string {
    return `${this.supabaseUrl.replace(/\/$/, '')}/functions/v1`
  },
} as const
