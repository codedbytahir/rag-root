import { callPublic } from './api'

export interface PolicyLink {
  id?: string
  label?: string
  url?: string
}

export interface VersionGate {
  player_min_version?: string
  player_latest_version?: string
  admin_min_version?: string
  admin_latest_version?: string
  force_update?: boolean
  maintenance?: boolean
  maintenance_message?: string
  cash_operations_enabled?: boolean
}

export interface AppAnnouncement {
  link?: string
  text?: string
  active?: boolean
}

export interface AppConfigVersions {
  player_min?: string
  player_latest?: string
  admin_min?: string
  admin_latest?: string
  force_update?: boolean
}

export interface AppMaintenance {
  enabled?: boolean
  message?: string
}

export interface AppConfig {
  policy_links?: PolicyLink[]
  policies?: unknown
  landing_page_url?: string
  home_page_url?: string
  about_app_url?: string
  about_app?: string
  support_phone?: string
  admin_phone?: string
  whatsapp_support_url?: string
  support_email?: string
  announcement?: AppAnnouncement | null
  featured_tournament_id?: string | null
  versions?: AppConfigVersions
  maintenance?: AppMaintenance | boolean
  maintenance_message?: string
  cash_operations_enabled?: boolean
  social?: unknown
  stores?: unknown
  [key: string]: unknown
}

/** Fetch the single app shell config bundle (no auth required). */
export async function fetchAppConfig(): Promise<AppConfig | null> {
  const res = await callPublic<AppConfig>('app-config')
  return res.data
}

/** Fetch the version/maintenance gate (no auth required). */
export async function fetchAppVersion(): Promise<VersionGate | null> {
  const res = await callPublic<VersionGate>('app-version')
  return res.data
}

export type GateState =
  | { status: 'loading' }
  | { status: 'maintenance'; message?: string }
  | { status: 'forceUpdate' }
  | { status: 'ready'; config: AppConfig }

const CURRENT_VERSION = '1.0.0'

/**
 * Decide the gate. `version` (from app-version) is the authoritative source
 * for the maintenance/force-update flags; `config` (from app-config) carries
 * content the rest of the app needs. Either may be null on a failed fetch.
 */
function asBoolean(v: unknown): boolean | undefined {
  if (typeof v === 'boolean') return v
  if (v && typeof v === 'object' && 'enabled' in v) return Boolean((v as AppMaintenance).enabled)
  return undefined
}

function asString(v: unknown): string | undefined {
  if (typeof v === 'string' && v.length > 0) return v
  if (v && typeof v === 'object' && 'message' in v) {
    const m = (v as AppMaintenance).message
    return m && m.length > 0 ? m : undefined
  }
  return undefined
}

/**
 * Decide the gate. `version` (from app-version) is the authoritative source
 * for the maintenance/force-update flags; `config` (from app-config) carries
 * content the rest of the app needs. Either may be null on a failed fetch.
 */
export function evaluateGate(config: AppConfig | null, version: VersionGate | null): GateState {
  const merged = { ...(config ?? {}) }
  const maintenance = version?.maintenance ?? asBoolean(config?.maintenance)
  const maintenanceMessage = version?.maintenance_message ?? asString(config?.maintenance)
  if (maintenance) {
    return { status: 'maintenance', message: maintenanceMessage }
  }
  const min = version?.player_min_version ?? config?.versions?.player_min
  const force = version?.force_update ?? config?.versions?.force_update
  if (force && min && isOlder(CURRENT_VERSION, min)) {
    return { status: 'forceUpdate' }
  }
  return { status: 'ready', config: merged }
}

export function isOlder(current: string, minimum: string): boolean {
  const a = current.split('.').map((n) => parseInt(n, 10) || 0)
  const b = minimum.split('.').map((n) => parseInt(n, 10) || 0)
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] ?? 0
    const y = b[i] ?? 0
    if (x !== y) return x < y
  }
  return false
}
