import * as SecureStore from 'expo-secure-store';
import * as aesjs from 'aes-js';
import 'react-native-get-random-values';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Crypto from 'expo-crypto';

const ENC_KEY = 'rz.session.enc';

/**
 * Encrypted session storage: a 256-bit AES key lives in expo-secure-store
 * (Keystore/Keychain); the encrypted Supabase session blob lives in AsyncStorage
 * (SecureStore alone has a 2048-byte value limit).
 */
class LargeSecureStore {
  private async getKey(): Promise<Uint8Array> {
    const stored = await SecureStore.getItemAsync(ENC_KEY);
    if (stored) return aesjs.utils.hex.toBytes(stored);
    const key = Crypto.getRandomBytes(32);
    await SecureStore.setItemAsync(ENC_KEY, aesjs.utils.hex.fromBytes(key));
    return key;
  }

  async getItem(key: string): Promise<string | null> {
    try {
      const encKey = await this.getKey();
      const enc = await AsyncStorage.getItem(key);
      if (!enc) return null;
      const ctr = new aesjs.ModeOfOperation.ctr(encKey, new aesjs.Counter(1));
      return aesjs.utils.utf8.fromBytes(ctr.decrypt(aesjs.utils.hex.toBytes(enc)));
    } catch {
      return null;
    }
  }

  async setItem(key: string, value: string): Promise<void> {
    const encKey = await this.getKey();
    const ctr = new aesjs.ModeOfOperation.ctr(encKey, new aesjs.Counter(1));
    const enc = aesjs.utils.hex.fromBytes(ctr.encrypt(aesjs.utils.utf8.toBytes(value)));
    await AsyncStorage.setItem(key, enc);
  }

  async removeItem(key: string): Promise<void> {
    await AsyncStorage.removeItem(key);
  }
}

export default LargeSecureStore;
