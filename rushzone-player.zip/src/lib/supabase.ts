import 'react-native-url-polyfill/auto';
import { createClient, processLock } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppState, Platform } from 'react-native';
import LargeSecureStore from './LargeSecureStore';
import { env } from './env';

// expo-secure-store (used by LargeSecureStore) isn't available on web, so web
// builds persist the session in AsyncStorage (localStorage) instead.
const sessionStorage = Platform.OS === 'web' ? AsyncStorage : new LargeSecureStore();

const clientOptions = {
  auth: {
    storage: sessionStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
    lock: processLock,
  },
  db: { schema: 'app' },
} as const;

/**
 * Single Supabase client. Uses the publishable key (sb_publishable_…), the
 * encrypted LargeSecureStore session adapter (AsyncStorage on web), and the
 * `app` DB schema (all player tables live in `app.*`).
 *
 * The constructor is deliberately wrapped: this module is evaluated at startup
 * BEFORE the global error handler is installed, so a throw here (e.g. an empty
 * or malformed URL baked into the build) would kill the app at launch with no
 * log, no redbox, and no Observe event. Instead we build a client that fails
 * every request gracefully and let the `env.isMisconfigured` startup guard
 * show the exact reason on screen.
 */
export const supabase = (() => {
  try {
    return createClient(env.supabaseUrl, env.supabasePublishableKey, clientOptions);
  } catch {
    // Unreachable backend: any call resolves to an error the app already
    // handles everywhere (auth → signedOut, API → REQUEST_FAILED, …).
    return createClient('https://invalid.invalid', 'sb_publishable_misconfigured', clientOptions);
  }
})();

if (Platform.OS !== 'web') {
  AppState.addEventListener('change', (state) => {
    if (state === 'active') supabase.auth.startAutoRefresh();
    else supabase.auth.stopAutoRefresh();
  });
}
