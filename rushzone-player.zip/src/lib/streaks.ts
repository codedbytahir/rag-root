/**
 * Pure streak math. PKT calendar days (Asia/Karachi) are the only unit —
 * the client never writes streak state; it just renders server-computed
 * `streak_days` values. All functions are unit-testable.
 */

export const PKT = 'Asia/Karachi'

/** Format a JS Date as YYYY-MM-DD in PKT. */
export function pktDateStr(date: Date): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: PKT,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date)
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? ''
  return `${get('year')}-${get('month')}-${get('day')}`
}

/** Today's calendar date in PKT as YYYY-MM-DD. */
export function pktToday(): string {
  return pktDateStr(new Date())
}

/** Add n calendar days to a YYYY-MM-DD string. */
export function addDays(dateStr: string, n: number): string {
  const d = new Date(`${dateStr}T00:00:00Z`)
  d.setUTCDate(d.getUTCDate() + n)
  return d.toISOString().slice(0, 10)
}

export interface StreakStats {
  current: number
  longest: number
  total: number
  thisMonth: number
  monthKey: string
}

export interface StreakDayInput {
  day: string
  intensity?: number
}

export function computeStreaks(days: StreakDayInput[], today: string): StreakStats {
  const active = new Set(days.map((d) => d.day))
  const keys = [...active].sort()

  // Current streak: counts consecutive active days ending today, with a one-day
  // grace — if today has no qualifying action yet, yesterday may hold the streak.
  let cursor = today
  if (!active.has(cursor)) cursor = addDays(cursor, -1)
  let current = 0
  while (active.has(cursor)) {
    current++
    cursor = addDays(cursor, -1)
  }

  // Longest run.
  let longest = 0
  let run = 0
  let prev: string | null = null
  for (const k of keys) {
    run = prev && addDays(prev, 1) === k ? run + 1 : 1
    if (run > longest) longest = run
    prev = k
  }

  const monthKey = today.slice(0, 7)
  const thisMonth = keys.filter((k) => k.startsWith(monthKey)).length

  return { current, longest, total: keys.length, thisMonth, monthKey }
}

export interface HeatCell {
  date: string
  intensity: number
  isToday: boolean
  isFuture: boolean
}

export interface HeatWeek {
  days: HeatCell[]
  monthLabel: string
}

/**
 * Build a GitHub-style heat-map grid: `weeks` columns of 7 day tiles each
 * (Sunday → Saturday), ending on `today`. Intensity 0–4 shades each tile.
 */
export function buildHeatmap(days: StreakDayInput[], today: string, weeks = 17): HeatWeek[] {
  const byDay = new Map(days.map((d) => [d.day, d.intensity ?? 1]))
  const gridStart = addDays(today, -(weeks * 7 - 1))
  const result: HeatWeek[] = []
  for (let w = 0; w < weeks; w++) {
    const week: HeatCell[] = []
    let monthLabel = ''
    for (let d = 0; d < 7; d++) {
      const date = addDays(gridStart, w * 7 + d)
      const cell: HeatCell = {
        date,
        intensity: byDay.get(date) ?? 0,
        isToday: date === today,
        isFuture: date > today,
      }
      week.push(cell)
      if (d === 0) monthLabel = monthLabelOf(date)
    }
    result.push({ days: week, monthLabel })
  }
  return result
}

export function monthLabelOf(dateStr: string): string {
  const d = new Date(`${dateStr}T00:00:00Z`)
  return new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', month: 'short' }).format(d)
}

/** Default milestone tiers (admin-configurable; see seed). */
export const DEFAULT_STREAK_TIERS: { day: number; coins: number }[] = [
  { day: 3, coins: 10 },
  { day: 7, coins: 25 },
  { day: 14, coins: 60 },
  { day: 30, coins: 150 },
  { day: 60, coins: 300 },
  { day: 100, coins: 500 },
]
