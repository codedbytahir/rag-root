import { Platform } from 'react-native'

/**
 * Rush Zone — Monochrome (black & white) design tokens with a muted red accent.
 * Authoritative source: docs/shared/07-design-tokens.md
 * White is the primary accent; red is reserved for destructive actions,
 * streaks, the spin pointer, and share-card brand moments.
 */
export const colors = {
  canvas: '#0A0A0A',
  deep: '#000000',
  surface: '#161616',
  surfaceRaised: '#1E1E1E',
  inset: '#101010',

  text: '#FFFFFF',
  textSecondary: '#A6A6A6',
  textDisabled: '#565656',

  action: '#FFFFFF',
  actionPressed: '#E2E2E2',
  onAction: '#0A0A0A',
  emphasis: '#FFFFFF',

  stroke: '#2C2C2C',
  strokeStrong: '#4A4A4A',
  divider: '#1C1C1C',

  clayHighlight: 'rgba(255,255,255,0.07)',
  clayShade: 'rgba(0,0,0,0.55)',
  scrim: 'rgba(0,0,0,0.72)',

  // Status is always icon + label, never color-only. These are the chip fills.
  // Red accent — used sparingly for destructive actions, the spin pointer,
  // streaks, and share-card brand moments. Kept muted for the dark theme.
  accent: '#E5484D',
  accentSoft: 'rgba(229,72,77,0.16)',
  accentInk: '#FFFFFF',

  successFill: '#FFFFFF',
  successInk: '#0A0A0A',
  dangerFill: '#E5484D',
  dangerInk: '#FFFFFF',
} as const

export const radii = {
  card: 12,
  button: 8,
  input: 8,
  badge: 999,
} as const

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  xxxxl: 40,
} as const

export const touchTarget = 44

const serifFamily = Platform.select({
  ios: 'Georgia',
  android: 'serif',
  default: 'Georgia, Times New Roman, serif',
})

const sansFamily = Platform.select({
  ios: 'System',
  android: 'sans-serif',
  default: 'Inter, system-ui, sans-serif',
})

export const fonts = {
  display: serifFamily,
  body: sansFamily,
  mono: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }),
} as const

export const type = {
  display: { fontSize: 32, lineHeight: 38, weight: '700' as const },
  heading: { fontSize: 22, lineHeight: 28, weight: '700' as const },
  title: { fontSize: 17, lineHeight: 24, weight: '600' as const },
  body: { fontSize: 15, lineHeight: 22, weight: '400' as const },
  label: { fontSize: 13, lineHeight: 18, weight: '600' as const },
  caption: { fontSize: 12, lineHeight: 16, weight: '400' as const },
  micro: { fontSize: 10, lineHeight: 14, weight: '600' as const, letterSpacing: 0.8 },
  money: { fontSize: 15, lineHeight: 22, weight: '600' as const },
} as const

export const motion = {
  durations: {
    instant: 80,
    fast: 140,
    base: 220,
    slow: 360,
  },
  easings: {
    standard: 'cubic-bezier(0.2, 0, 0, 1)',
    emphasize: 'cubic-bezier(0.3, 0.7, 0.2, 1)',
  },
} as const

/**
 * Clay-style outer shadow for cards/sheets (Android elevation + iOS shadow).
 * Web uses the modern `boxShadow` — the legacy `shadow*` props are deprecated
 * in react-native-web.
 */
const nativeShadow = (y: number, opacity: number, radius: number, elevation: number) =>
  Platform.OS === 'web'
    ? { boxShadow: `0 ${y}px ${radius}px rgba(0, 0, 0, ${opacity})` }
    : {
        shadowColor: '#000000',
        shadowOffset: { width: 0, height: y },
        shadowOpacity: opacity,
        shadowRadius: radius,
        elevation,
      }

export const shadows = {
  card: nativeShadow(6, 0.55, 20, 8),
  button: nativeShadow(3, 0.4, 8, 4),
} as const
