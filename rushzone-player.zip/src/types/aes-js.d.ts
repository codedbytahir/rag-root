declare module 'aes-js' {
  interface Ctr {
    encrypt(bytes: Uint8Array): Uint8Array
    decrypt(bytes: Uint8Array): Uint8Array
  }

  export class Counter {
    constructor(initial: number)
  }

  export const ModeOfOperation: {
    ctr: new (key: Uint8Array, counter: Counter) => Ctr
  }

  export const utils: {
    hex: { toBytes(hex: string): Uint8Array; fromBytes(bytes: Uint8Array): string }
    utf8: { toBytes(str: string): Uint8Array; fromBytes(bytes: Uint8Array): string }
  }
}
