import { Linking, Pressable, StyleSheet } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useConfig } from '@/stores/config'
import { colors, radii, shadows, spacing } from '@/theme/tokens'

const DEFAULT_TEXT = 'Hi Rush Zone support! I need help.'

/**
 * Build a wa.me chat link from the server-provided support settings, appending
 * a prefilled message. Returns null when no support channel is configured.
 */
export function supportChatUrl(
  whatsappUrl?: string | null,
  phone?: string | null,
  text: string = DEFAULT_TEXT,
): string | null {
  let base = whatsappUrl || null
  if (!base && phone) {
    const digits = phone.replace(/\D/g, '')
    if (digits) base = `https://wa.me/${digits}`
  }
  if (!base) return null
  const sep = base.includes('?') ? '&' : '?'
  return `${base}${sep}text=${encodeURIComponent(text)}`
}

/** Floating WhatsApp support button. Hidden until the server supplies a channel. */
export function FloatingSupportButton() {
  const { config } = useConfig()
  const url = supportChatUrl(
    config?.whatsapp_support_url as string | undefined,
    config?.support_phone as string | undefined,
  )
  if (!url) return null

  return (
    <Pressable
      onPress={() => void Linking.openURL(url)}
      accessibilityRole="button"
      accessibilityLabel="Contact support on WhatsApp"
      style={({ pressed }) => [styles.fab, pressed && styles.fabPressed]}
    >
      <Ionicons name="logo-whatsapp" size={26} color={colors.onAction} />
    </Pressable>
  )
}

const styles = StyleSheet.create({
  fab: {
    position: 'absolute',
    right: spacing.lg,
    bottom: 104,
    width: 56,
    height: 56,
    borderRadius: radii.badge,
    backgroundColor: colors.action,
    alignItems: 'center',
    justifyContent: 'center',
    ...shadows.button,
  },
  fabPressed: { backgroundColor: colors.actionPressed, transform: [{ scale: 0.96 }] },
})
