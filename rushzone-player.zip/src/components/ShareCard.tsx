import { StyleSheet, View } from 'react-native'
import { Text } from './ui/Text'
import { colors, spacing } from '@/theme/tokens'
import type { ShareCardType } from '@/lib/shareCards'

export interface ShareCardData {
  type: ShareCardType
  displayName?: string
  appUid?: string
  tournamentTitle?: string
  placement?: number | null
  kills?: number
  prizeCoins?: number
  streakDays?: number
  coinsWon?: number
  referralCode?: string
  stats?: { joined: number; wins: number; kills: number; longestStreak?: number }
  date?: string
}

const ACHIEVEMENT: Record<ShareCardType, string> = {
  result: 'RESULT',
  win: 'VICTORY',
  prize: 'PRIZE',
  streak: 'STREAK',
  spin: 'SPIN WIN',
  referral: 'JOIN THE ZONE',
  profile: 'PLAYER PROFILE',
}

interface ShareCardProps {
  data: ShareCardData
  width: number
  /** Explicit height — the card fills whatever format the share sheet picked
   *  (9:16 story or 1:1 square) instead of deriving its own aspect. */
  height?: number
}

export function ShareCard({ data, width, height }: ShareCardProps) {
  const cardHeight =
    height ?? (data.type === 'profile' || data.type === 'referral' ? width : width * (16 / 9))

  // Coin/prize values and the referral code carry the red brand accent.
  const accentValue =
    data.type === 'referral' || data.type === 'prize' || data.type === 'spin'
  const bigColor = accentValue ? colors.accent : colors.text

  return (
    <View style={[styles.card, { width, height: cardHeight }]}>
      <View style={styles.accentStripe} pointerEvents="none" />

      <View style={styles.lockup}>
        <Text variant="micro" color={colors.accent} style={styles.lockupTop}>
          RUSH ZONE · PLAYER APP
        </Text>
      </View>

      <View style={styles.middle}>
        <Text variant="micro" color={colors.accent} style={styles.achievement}>
          {ACHIEVEMENT[data.type]}
        </Text>
        {data.type === 'result' || data.type === 'win' ? (
          <>
            <Text style={[styles.big, { color: colors.text }]}>
              #{data.placement ?? '—'}
            </Text>
            <Text variant="body" color={colors.textSecondary} style={styles.line}>
              {data.tournamentTitle ?? ''}
              {data.kills ? ` · ${data.kills} kills` : ''}
            </Text>
          </>
        ) : data.type === 'prize' ? (
          <>
            <Text style={[styles.big, { color: bigColor }]}>
              +{data.prizeCoins ?? 0}
            </Text>
            <Text variant="body" color={colors.textSecondary} style={styles.line}>
              coins earned · {data.tournamentTitle ?? ''}
            </Text>
          </>
        ) : data.type === 'streak' ? (
          <>
            <Text style={[styles.big, { color: colors.text }]}>
              {data.streakDays ?? 0}
            </Text>
            <Text variant="body" color={colors.textSecondary} style={styles.line}>
              day streak
            </Text>
          </>
        ) : data.type === 'spin' ? (
          <>
            <Text style={[styles.big, { color: bigColor }]}>
              +{data.coinsWon ?? 0}
            </Text>
            <Text variant="body" color={colors.textSecondary} style={styles.line}>
              coins won on the Spin Wheel
            </Text>
          </>
        ) : data.type === 'referral' ? (
          <>
            <Text style={[styles.big, { color: bigColor, letterSpacing: 4 }]}>
              {data.referralCode ?? '—'}
            </Text>
            <Text variant="body" color={colors.textSecondary} style={styles.line}>
              Enter my code and join Rush Zone
            </Text>
          </>
        ) : (
          <>
            <Text style={[styles.big, { color: colors.text }]} numberOfLines={1}>
              {data.displayName ?? 'Player'}
            </Text>
            <Text variant="body" color={colors.textSecondary} style={styles.line}>
              UID {data.appUid ?? '—'} · {data.stats?.wins ?? 0} wins · {data.stats?.kills ?? 0} kills
            </Text>
          </>
        )}
      </View>

      <View style={styles.footer}>
        <Mountains />
        <View style={styles.footerRow}>
          <Text variant="micro" color={colors.textSecondary}>
            {data.displayName ?? 'PLAYER'} · UID {data.appUid ?? '—'}
          </Text>
          <Text variant="micro" color={colors.textSecondary}>
            JOIN ME ON RUSH ZONE
          </Text>
        </View>
      </View>
    </View>
  )
}

function Mountains() {
  return (
    <View style={styles.mountains} pointerEvents="none">
      <View style={[styles.mountain, { borderBottomWidth: 46, left: 0 }]} />
      <View style={[styles.mountain, { borderBottomWidth: 64, left: 90 }]} />
      <View style={[styles.mountain, { borderBottomWidth: 40, left: 190 }]} />
    </View>
  )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.canvas,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.stroke,
    overflow: 'hidden',
    padding: spacing.lg,
    justifyContent: 'space-between',
  },
  accentStripe: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 5,
    backgroundColor: colors.accent,
  },
  lockup: { alignItems: 'flex-start', marginTop: spacing.md },
  lockupTop: { letterSpacing: 2 },
  middle: { flex: 1, justifyContent: 'center', gap: spacing.sm },
  achievement: { letterSpacing: 3 },
  big: { fontSize: 64, fontWeight: '700', lineHeight: 72, fontFamily: 'serif' },
  line: {},
  footer: { gap: spacing.md },
  mountains: { height: 70, position: 'relative' },
  mountain: {
    position: 'absolute',
    bottom: 0,
    width: 0,
    height: 0,
    borderLeftWidth: 80,
    borderRightWidth: 80,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: 'rgba(255,255,255,0.10)',
  },
  footerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: colors.divider,
    paddingTop: spacing.md,
  },
})
