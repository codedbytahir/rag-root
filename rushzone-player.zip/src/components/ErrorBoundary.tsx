import { Component, type ErrorInfo, type ReactNode } from 'react'
import { Pressable, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { Text } from '@/components/ui/Text'
import { Button } from '@/components/ui/Button'
import { colors, radii, spacing } from '@/theme/tokens'

interface Props {
  children: ReactNode
  /** Optional title override — used when the app is shown a fatal startup error. */
  title?: string
  /** Optional message override — used when a fatal startup error is known up front. */
  message?: string
  /** Optional extra context line (e.g. "Missing EXPO_PUBLIC_SUPABASE_URL"). */
  detail?: string
}

interface State {
  error: Error | null
}

/**
 * Catches render/JS errors that would otherwise crash the app in release
 * builds and shows the exact error message on screen instead of silently
 * closing. Errors are also forwarded to the global handler (EAS Observe).
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null }

  static getDerivedStateFromError(error: Error): State {
    return { error }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Forward to the global handler so EAS Observe / logs still see it.
    if (globalThis.__rzReportError) {
      globalThis.__rzReportError(error, info.componentStack ?? undefined)
    }
  }

  private reset = () => {
    this.setState({ error: null })
  }

  render() {
    const { error } = this.state
    if (!error) return this.props.children

    return (
      <FatalErrorScreen
        title={this.props.title ?? 'Something went wrong'}
        message={error.message || String(error)}
        detail={this.props.detail}
        onRetry={this.reset}
      />
    )
  }
}

/**
 * Full-screen fatal error presentation. Used by the ErrorBoundary and by the
 * startup guard when the app is misconfigured (e.g. missing env vars) — in
 * that case the "Restart" button reloads the app so a fresh build/update can
 * take effect.
 */
export function FatalErrorScreen({
  title = 'Something went wrong',
  message,
  detail,
  onRetry,
}: {
  title?: string
  message?: string
  detail?: string
  onRetry?: () => void
}) {
  return (
    <View style={styles.screen}>
      <View style={styles.card}>
        <View style={styles.iconWrap}>
          <Ionicons name="alert-circle-outline" size={34} color={colors.text} />
        </View>
        <Text variant="heading" style={styles.title}>
          {title}
        </Text>
        {message ? (
          <Text variant="body" color={colors.textSecondary} style={styles.message}>
            {message}
          </Text>
        ) : null}
        {detail ? (
          <View style={styles.detailBox}>
            <Text variant="caption" color={colors.textDisabled} style={styles.detailText}>
              {detail}
            </Text>
          </View>
        ) : null}
        {onRetry ? (
          <Button label="Restart" onPress={onRetry} style={styles.retry} />
        ) : null}
        <Pressable onPress={() => undefined} hitSlop={8}>
          <Text variant="caption" color={colors.textDisabled} style={styles.hint}>
            Close the app and reopen it if this keeps happening.
          </Text>
        </Pressable>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.canvas,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radii.card,
    borderWidth: 1,
    borderColor: colors.stroke,
    padding: spacing.xl,
    alignItems: 'center',
    gap: spacing.md,
    width: '100%',
    maxWidth: 420,
  },
  iconWrap: {
    width: 64,
    height: 64,
    borderRadius: radii.badge,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.strokeStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { textAlign: 'center' },
  message: { textAlign: 'center' },
  detailBox: {
    backgroundColor: colors.inset,
    borderRadius: radii.input,
    borderWidth: 1,
    borderColor: colors.stroke,
    padding: spacing.md,
    alignSelf: 'stretch',
  },
  detailText: { fontFamily: 'monospace', fontSize: 12 },
  retry: { alignSelf: 'stretch', marginTop: spacing.sm },
  hint: { textAlign: 'center', marginTop: spacing.xs },
})
