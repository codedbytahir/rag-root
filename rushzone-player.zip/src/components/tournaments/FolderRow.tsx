import type { ComponentProps } from 'react'
import { StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { Card } from '@/components/ui/Card'
import { Text } from '@/components/ui/Text'
import { colors, radii, spacing } from '@/theme/tokens'

type IoniconName = ComponentProps<typeof Ionicons>['name']

interface FolderRowProps {
  icon: IoniconName
  title: string
  subtitle?: string
  count?: number
  onPress: () => void
}

/** A folder-style row: icon tile, title/subtitle, count badge, chevron. */
export function FolderRow({ icon, title, subtitle, count, onPress }: FolderRowProps) {
  return (
    <Card onPress={onPress} style={styles.row}>
      <View style={styles.iconWrap}>
        <Ionicons name={icon} size={22} color={colors.text} />
      </View>
      <View style={styles.body}>
        <Text variant="title" numberOfLines={1}>
          {title}
        </Text>
        {subtitle ? (
          <Text variant="caption" color={colors.textSecondary} numberOfLines={1}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {count != null ? (
        <View style={styles.count}>
          <Text variant="label" color={colors.textSecondary}>
            {count}
          </Text>
        </View>
      ) : null}
      <Ionicons name="chevron-forward" size={18} color={colors.textDisabled} />
    </Card>
  )
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: radii.button,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: { flex: 1, gap: 2 },
  count: {
    minWidth: 32,
    height: 24,
    paddingHorizontal: spacing.sm,
    borderRadius: radii.badge,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
    justifyContent: 'center',
  },
})
