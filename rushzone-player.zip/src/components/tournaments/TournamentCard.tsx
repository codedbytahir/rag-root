import { StyleSheet, View } from 'react-native'
import { Image } from 'expo-image'
import { Card } from '@/components/ui/Card'
import { Text } from '@/components/ui/Text'
import { StatusChip } from '@/components/ui/StatusChip'
import { colors, spacing } from '@/theme/tokens'
import type { TournamentsRow } from '@/lib/database.types'
import { formatCoins, formatPKTDateTime } from '@/lib/format'
import { publicStorageUrl } from '@/lib/storage'
import { statusMeta } from '@/lib/tournaments'

interface TournamentCardProps {
  tournament: TournamentsRow
  onPress: () => void
}

export function TournamentCard({ tournament, onPress }: TournamentCardProps) {
  const meta = statusMeta(tournament.status)
  const cover = publicStorageUrl('tournament-thumbnails', tournament.cover_path)

  return (
    <Card onPress={onPress} padded={false} style={styles.card}>
      <View style={styles.coverWrap}>
        {cover ? (
          <Image source={{ uri: cover }} style={styles.cover} contentFit="cover" transition={200} />
        ) : (
          <View style={[styles.cover, styles.coverFallback]}>
            <Text variant="display" color={colors.textDisabled}>
              RZ
            </Text>
          </View>
        )}
        {meta ? (
          <View style={styles.badge}>
            <StatusChip tone={meta.tone} label={meta.label} />
          </View>
        ) : null}
      </View>

      <View style={styles.body}>
        <Text variant="title" numberOfLines={1}>
          {tournament.title}
        </Text>
        <View style={styles.metaRow}>
          <Text variant="caption" color={colors.textSecondary} style={styles.flex}>
            {[tournament.mode, tournament.map].filter(Boolean).join(' · ') || '—'}
          </Text>
          <Text variant="caption" color={colors.textSecondary}>
            {tournament.match_start_at ? formatPKTDateTime(tournament.match_start_at) : 'TBA'}
          </Text>
        </View>
        <View style={styles.footer}>
          <Text variant="money" color={colors.emphasis}>
            {tournament.entry_fee > 0 ? `${formatCoins(tournament.entry_fee)} coins` : 'Free entry'}
          </Text>
          <Text variant="caption" color={colors.textDisabled}>
            Pool {formatCoins(tournament.prize_pool)}
          </Text>
        </View>
      </View>
    </Card>
  )
}

const styles = StyleSheet.create({
  card: { overflow: 'hidden', marginBottom: spacing.lg },
  coverWrap: { position: 'relative' },
  cover: { width: '100%', height: 140 },
  coverFallback: { backgroundColor: colors.inset, alignItems: 'center', justifyContent: 'center' },
  badge: { position: 'absolute', top: spacing.md, left: spacing.md },
  body: { padding: spacing.lg, gap: spacing.xs },
  metaRow: { flexDirection: 'row', justifyContent: 'space-between', gap: spacing.sm },
  flex: { flex: 1 },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.sm,
    paddingTop: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.divider,
  },
})
