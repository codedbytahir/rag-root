import { useEffect, useRef } from 'react'
import { ActivityIndicator, Animated, StyleSheet, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { useAuth } from '@/stores/auth'
import { colors, radii, shadows, spacing } from '@/theme/tokens'
import { Text } from '@/components/ui/Text'

/**
 * Floating "Uploading avatar… 42%" pill, styled like a system file-transfer
 * dialog. Mounted at the root so it stays visible while the avatar uploads in
 * the background after profile setup.
 */
export function UploadProgressOverlay() {
  const { avatarUploadProgress } = useAuth()
  const insets = useSafeAreaInsets()
  const opacity = useRef(new Animated.Value(0)).current

  useEffect(() => {
    Animated.timing(opacity, {
      toValue: 1,
      duration: 160,
      useNativeDriver: true,
    }).start()
  }, [opacity])

  if (avatarUploadProgress == null) return null

  return (
    <View pointerEvents="none" style={[styles.wrap, { top: insets.top + spacing.sm }]}>
      <Animated.View style={[styles.card, { opacity }]}>
        <ActivityIndicator size="small" color={colors.text} />
        <View style={styles.body}>
          <View style={styles.row}>
            <Text variant="label">Uploading avatar…</Text>
            <Text variant="label" color={colors.textSecondary} tabular>
              {avatarUploadProgress}%
            </Text>
          </View>
          <View style={styles.track}>
            <View style={[styles.fill, { width: `${avatarUploadProgress}%` }]} />
          </View>
        </View>
      </Animated.View>
    </View>
  )
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    zIndex: 1000,
    elevation: 10,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    alignSelf: 'stretch',
    maxWidth: 420,
    padding: spacing.md,
    backgroundColor: colors.surfaceRaised,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.stroke,
    borderRadius: radii.card,
    ...shadows.card,
  },
  body: { flex: 1, gap: spacing.xs },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.md,
  },
  track: {
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.inset,
    overflow: 'hidden',
  },
  fill: { height: '100%', borderRadius: 2, backgroundColor: colors.accent },
})
