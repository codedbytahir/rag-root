import { FlatList, Pressable, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { Text } from '@/components/ui/Text'
import { LottieIcon } from '@/components/ui/LottieIcon'
import { colors, radii, spacing } from '@/theme/tokens'
import { CATEGORIES, modeMatchesFilter } from '@/lib/tournamentCategories'
import type { TournamentsRow } from '@/lib/database.types'

interface CategoryCardsProps {
  tournaments: TournamentsRow[]
}

/** Horizontal scroll of tournament category cards (filters). */
export function CategoryCards({ tournaments }: CategoryCardsProps) {
  const router = useRouter()
  return (
    <FlatList
      horizontal
      showsHorizontalScrollIndicator={false}
      data={CATEGORIES}
      keyExtractor={(c) => c.key}
      contentContainerStyle={styles.row}
      renderItem={({ item }) => {
        const count = tournaments.filter((t) => modeMatchesFilter(t.mode, item.key)).length
        return (
          <Pressable
            style={styles.card}
            accessibilityRole="button"
            onPress={() => router.push(`/tournament/browse/${encodeURIComponent(item.key)}`)}
          >
            <View style={styles.iconWrap}>
              <Ionicons name={item.icon} size={22} color={colors.text} />
              <LottieIcon name="pulse" size={52} style={styles.pulse} />
            </View>
            <Text variant="label" style={styles.label} numberOfLines={2}>
              {item.label}
            </Text>
            <Text variant="micro" color={colors.textDisabled}>
              {count} {count === 1 ? 'match' : 'matches'}
            </Text>
          </Pressable>
        )
      }}
    />
  )
}

const styles = StyleSheet.create({
  row: { gap: spacing.md, paddingVertical: spacing.xs },
  card: {
    width: 148,
    minHeight: 128,
    padding: spacing.md,
    borderRadius: radii.card,
    backgroundColor: colors.surface,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.stroke,
    gap: spacing.sm,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: radii.button,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  pulse: { position: 'absolute', opacity: 0.9 },
  label: { flex: 1 },
})
