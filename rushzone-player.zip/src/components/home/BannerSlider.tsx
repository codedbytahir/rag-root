import { useEffect, useRef, useState } from 'react'
import {
  FlatList,
  Linking,
  Pressable,
  StyleSheet,
  useWindowDimensions,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native'
import { Image } from 'expo-image'
import { colors, radii, spacing } from '@/theme/tokens'
import type { BannersRow } from '@/lib/database.types'
import { publicStorageUrl } from '@/lib/storage'

/** Fallback height while the first banner is still loading. */
const DEFAULT_HEIGHT = 170
/** Height is derived from the image's aspect ratio, clamped to this range. */
const MIN_HEIGHT = 130
const MAX_HEIGHT = 240

function clampHeight(h: number): number {
  return Math.min(MAX_HEIGHT, Math.max(MIN_HEIGHT, Math.round(h)))
}

interface BannerSliderProps {
  banners: BannersRow[]
}

export function BannerSlider({ banners }: BannerSliderProps) {
  const { width } = useWindowDimensions()
  const cardWidth = width - spacing.lg * 2

  const [index, setIndex] = useState(0)
  // The whole slider shares one height (derived from the first banner that
  // loads) so the layout doesn't jump between pages.
  const [height, setHeight] = useState<number | null>(null)
  const sizedRef = useRef(false)
  const listRef = useRef<FlatList<BannersRow>>(null)
  const timer = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    if (banners.length < 2) return
    timer.current = setInterval(() => {
      setIndex((i) => {
        const next = (i + 1) % banners.length
        listRef.current?.scrollToOffset({ offset: next * cardWidth, animated: true })
        return next
      })
    }, 4000)
    return () => {
      if (timer.current) clearInterval(timer.current)
    }
  }, [banners.length, cardWidth])

  const onScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const i = Math.round(e.nativeEvent.contentOffset.x / cardWidth)
    if (i !== index) setIndex(i)
  }

  if (!banners.length) return null

  const cardHeight = height ?? DEFAULT_HEIGHT

  return (
    <View>
      <FlatList
        ref={listRef}
        data={banners}
        keyExtractor={(b) => b.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={onScroll}
        scrollEventThrottle={16}
        snapToInterval={cardWidth}
        decelerationRate="fast"
        renderItem={({ item }) => {
          const uri = publicStorageUrl('banners', item.image_path)
          const inner = uri ? (
            <Image
              source={{ uri }}
              style={styles.img}
              contentFit="cover"
              transition={200}
              onLoad={(e) => {
                // Size the whole slider from the first banner that reports its
                // dimensions, so every page uses the same height.
                if (sizedRef.current) return
                const w = e.source?.width
                const h = e.source?.height
                if (w && h && w > 0) {
                  sizedRef.current = true
                  setHeight(clampHeight((cardWidth / w) * h))
                }
              }}
            />
          ) : null
          return item.link_url ? (
            <Pressable
              style={[styles.card, { width: cardWidth, height: cardHeight }]}
              onPress={() => void Linking.openURL(item.link_url as string)}
            >
              {inner}
            </Pressable>
          ) : (
            <View style={[styles.card, { width: cardWidth, height: cardHeight }]}>{inner}</View>
          )
        }}
      />
      {banners.length > 1 ? (
        <View style={styles.dots}>
          {banners.map((b, i) => (
            <View key={b.id} style={[styles.dot, i === index ? styles.dotActive : null]} />
          ))}
        </View>
      ) : null}
    </View>
  )
}

const styles = StyleSheet.create({
  card: {
    height: DEFAULT_HEIGHT,
    borderRadius: radii.card,
    overflow: 'hidden',
    backgroundColor: colors.inset,
  },
  img: { width: '100%', height: '100%' },
  dots: { flexDirection: 'row', gap: spacing.xs, justifyContent: 'center', marginTop: spacing.sm },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.stroke },
  dotActive: { backgroundColor: colors.text, width: 16 },
})
