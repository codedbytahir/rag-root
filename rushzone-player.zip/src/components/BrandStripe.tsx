import { StyleSheet, View } from 'react-native'

/**
 * Monochrome brand hairline shown above the bottom nav on every screen:
 * white → grey → black.
 */
export function BrandStripe() {
  return (
    <View style={styles.row} pointerEvents="none" aria-hidden>
      <View style={[styles.seg, { backgroundColor: '#FFFFFF' }]} />
      <View style={[styles.seg, { backgroundColor: '#8A8A8A' }]} />
      <View style={[styles.seg, { backgroundColor: '#000000' }]} />
    </View>
  )
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', height: 2, width: '100%' },
  seg: { flex: 1, height: '100%' },
})
