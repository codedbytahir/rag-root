import { View } from 'react-native'
import {
  BottomTabBar,
  type BottomTabBarProps,
} from 'expo-router/build/react-navigation/bottom-tabs'
import { BrandStripe } from '../BrandStripe'
import { colors } from '@/theme/tokens'

/** Bottom tab bar with the monochrome brand hairline rendered above it. */
export function RushTabBar(props: BottomTabBarProps) {
  return (
    <View style={{ backgroundColor: colors.surfaceRaised }}>
      <BrandStripe />
      <BottomTabBar {...props} />
    </View>
  )
}
