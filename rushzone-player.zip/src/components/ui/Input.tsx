import { useState } from 'react'
import { StyleSheet, TextInput, View, type TextInputProps, type ViewStyle } from 'react-native'
import { colors, radii, spacing, touchTarget } from '@/theme/tokens'
import { Text } from './Text'

interface InputProps extends TextInputProps {
  label?: string
  error?: string | null
  helper?: string | null
  containerStyle?: ViewStyle
}

export function Input({ label, error, helper, containerStyle, style, ...rest }: InputProps) {
  const [focused, setFocused] = useState(false)
  return (
    <View style={[styles.wrap, containerStyle]}>
      {label ? (
        <Text variant="label" color={colors.textSecondary} style={styles.label}>
          {label}
        </Text>
      ) : null}
      <TextInput
        {...rest}
        onFocus={(e) => {
          setFocused(true)
          rest.onFocus?.(e)
        }}
        onBlur={(e) => {
          setFocused(false)
          rest.onBlur?.(e)
        }}
        placeholderTextColor={colors.textDisabled}
        style={[
          styles.input,
          focused ? styles.focused : null,
          error ? styles.error : null,
          style,
        ]}
      />
      {error ? (
        <Text variant="caption" color={colors.textSecondary} style={styles.hint}>
          ⚠ {error}
        </Text>
      ) : helper ? (
        <Text variant="caption" color={colors.textDisabled} style={styles.hint}>
          {helper}
        </Text>
      ) : null}
    </View>
  )
}

const styles = StyleSheet.create({
  wrap: { gap: spacing.xs },
  label: { marginBottom: spacing.xs },
  input: {
    backgroundColor: colors.inset,
    borderRadius: radii.input,
    borderWidth: 1,
    borderColor: colors.stroke,
    color: colors.text,
    minHeight: touchTarget + 8,
    paddingHorizontal: spacing.lg,
    fontSize: 16,
  },
  focused: { borderColor: colors.strokeStrong },
  error: { borderColor: colors.strokeStrong },
  hint: { marginTop: spacing.xs },
})
