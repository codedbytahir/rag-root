import { StyleSheet, View } from 'react-native'
import { colors, spacing } from '@/theme/tokens'
import { Text } from './Text'
import { Button } from './Button'

interface EmptyStateProps {
  title: string
  body?: string
  icon?: string
  actionLabel?: string
  onAction?: () => void
}

export function EmptyState({ title, body, icon = '○', actionLabel, onAction }: EmptyStateProps) {
  return (
    <View style={styles.wrap}>
      <Text variant="display" color={colors.textDisabled} style={styles.icon}>
        {icon}
      </Text>
      <Text variant="title" align="center">
        {title}
      </Text>
      {body ? (
        <Text variant="body" color={colors.textSecondary} align="center" style={styles.body}>
          {body}
        </Text>
      ) : null}
      {actionLabel && onAction ? (
        <Button label={actionLabel} onPress={onAction} size="md" fullWidth={false} style={styles.action} />
      ) : null}
    </View>
  )
}

const styles = StyleSheet.create({
  wrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xxl,
    gap: spacing.md,
  },
  icon: { fontSize: 40 },
  body: { marginTop: spacing.xs },
  action: { marginTop: spacing.lg, paddingHorizontal: spacing.xxl },
})
