import { ActivityIndicator, Pressable, StyleSheet, type StyleProp, type ViewStyle } from 'react-native'
import type { ReactNode } from 'react'
import { colors, radii, shadows, spacing, touchTarget } from '@/theme/tokens'
import { Text } from './Text'

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger'
type Size = 'sm' | 'md' | 'lg'

interface ButtonProps {
  label: string
  onPress?: () => void
  variant?: Variant
  size?: Size
  loading?: boolean
  disabled?: boolean
  fullWidth?: boolean
  icon?: ReactNode
  style?: StyleProp<ViewStyle>
}

const HEIGHTS: Record<Size, number> = { sm: 36, md: 44, lg: 52 }
const PADDINGS: Record<Size, number> = { sm: spacing.md, md: spacing.lg, lg: spacing.xl }

export function Button({
  label,
  onPress,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  fullWidth = true,
  icon,
  style,
}: ButtonProps) {
  const isDisabled = disabled || loading
  const pressed = variant === 'primary'

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      accessibilityRole="button"
      accessibilityState={{ disabled: isDisabled, busy: loading }}
      style={({ pressed: isPressed }) => [
        styles.base,
        { height: HEIGHTS[size], minHeight: touchTarget, paddingHorizontal: PADDINGS[size] },
        fullWidth ? styles.fullWidth : null,
        variantStyles[variant],
        isPressed && pressed ? styles.primaryPressed : null,
        isPressed && !pressed ? styles.secondaryPressed : null,
        isDisabled ? styles.disabled : null,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={pressed ? colors.onAction : colors.text} size="small" />
      ) : (
        <>
          {icon}
          <Text
            variant={size === 'sm' ? 'label' : 'title'}
            color={
              variant === 'primary'
                ? colors.onAction
                : variant === 'danger'
                  ? colors.dangerInk
                  : colors.text
            }
            style={styles.label}
          >
            {label}
          </Text>
        </>
      )}
    </Pressable>
  )
}

const styles = StyleSheet.create({
  base: {
    borderRadius: radii.button,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
  },
  fullWidth: { alignSelf: 'stretch' },
  label: { textAlign: 'center' },
  primaryPressed: { backgroundColor: colors.actionPressed, transform: [{ scale: 0.98 }] },
  secondaryPressed: { borderColor: colors.strokeStrong, transform: [{ scale: 0.98 }] },
  disabled: { opacity: 0.45 },
})

const variantStyles: Record<Variant, ViewStyle> = {
  primary: {
    backgroundColor: colors.action,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.strokeStrong,
    ...shadows.button,
  },
  secondary: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.stroke,
  },
  ghost: {
    backgroundColor: 'transparent',
    borderWidth: 0,
  },
  danger: {
    backgroundColor: colors.dangerFill,
    borderWidth: 1,
    borderColor: colors.accent,
  },
}
