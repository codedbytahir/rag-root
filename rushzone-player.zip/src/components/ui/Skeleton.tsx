import { useEffect, useState } from 'react'
import { Animated, type StyleProp, type ViewStyle } from 'react-native'
import { colors, radii } from '@/theme/tokens'

interface SkeletonProps {
  width?: number | `${number}%`
  height?: number
  radius?: number
  style?: StyleProp<ViewStyle>
}

export function Skeleton({ width = '100%', height = 16, radius = radii.button, style }: SkeletonProps) {
  const [opacity] = useState(() => new Animated.Value(0.35))

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 0.8, duration: 600, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.35, duration: 600, useNativeDriver: true }),
      ]),
    )
    loop.start()
    return () => loop.stop()
  }, [opacity])

  return (
    <Animated.View
      style={[{ width, height, borderRadius: radius, backgroundColor: colors.surfaceRaised, opacity }, style]}
    />
  )
}
