import { StyleSheet, View } from 'react-native'
import { colors, radii, spacing } from '@/theme/tokens'
import { Text } from './Text'

type Tone = 'success' | 'danger' | 'neutral' | 'info'

interface StatusChipProps {
  tone: Tone
  label: string
  /** Optional leading glyph; defaults to tone-appropriate icon. */
  icon?: string
}

const DEFAULT_ICON: Record<Tone, string> = {
  success: '✓',
  danger: '⚠',
  neutral: '',
  info: '●',
}

export function StatusChip({ tone, label, icon }: StatusChipProps) {
  const glyph = icon ?? DEFAULT_ICON[tone]
  return (
    <View style={[styles.chip, toneStyles[tone]]}>
      {glyph ? (
        <Text
          variant="micro"
          color={tone === 'success' ? colors.successInk : tone === 'danger' ? colors.dangerInk : colors.textSecondary}
        >
          {glyph}
        </Text>
      ) : null}
      <Text
        variant="micro"
        color={
          tone === 'success'
            ? colors.successInk
            : tone === 'danger'
              ? colors.dangerInk
              : colors.textSecondary
        }
      >
        {label.toUpperCase()}
      </Text>
    </View>
  )
}

const styles = StyleSheet.create({
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    borderRadius: radii.badge,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    alignSelf: 'flex-start',
  },
})

const toneStyles: Record<Tone, object> = {
  success: { backgroundColor: colors.successFill },
  danger: { backgroundColor: colors.accentSoft, borderWidth: 1, borderColor: colors.accent },
  neutral: { backgroundColor: colors.inset, borderWidth: 1, borderColor: colors.stroke },
  info: { backgroundColor: colors.inset, borderWidth: 1, borderColor: colors.stroke },
}
