import { Pressable, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native'
import type { ReactNode } from 'react'
import { colors, radii, shadows, spacing } from '@/theme/tokens'

interface CardProps {
  children: ReactNode
  style?: StyleProp<ViewStyle>
  onPress?: () => void
  padded?: boolean
  raised?: boolean
}

export function Card({ children, style, onPress, padded = true, raised = false }: CardProps) {
  const content = (
    <View
      style={[
        styles.card,
        padded ? styles.padded : null,
        raised ? styles.raised : null,
        style,
      ]}
    >
      {children}
    </View>
  )

  if (onPress) {
    return (
      <Pressable
        onPress={onPress}
        accessibilityRole="button"
        style={({ pressed }) => [pressed ? styles.pressed : null]}
      >
        {content}
      </Pressable>
    )
  }
  return content
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radii.card,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.stroke,
    ...shadows.card,
  },
  padded: { padding: spacing.lg },
  raised: { backgroundColor: colors.surfaceRaised },
  pressed: { transform: [{ translateY: 2 }], opacity: 0.95 },
})
