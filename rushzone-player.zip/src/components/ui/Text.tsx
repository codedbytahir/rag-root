import { Text as RNText, type TextProps, type TextStyle } from 'react-native'
import { colors, fonts, type } from '@/theme/tokens'

export type TextVariant = keyof typeof type

export interface RzTextProps extends TextProps {
  variant?: TextVariant
  color?: string
  align?: TextStyle['textAlign']
  /** Use tabular/monospaced figures for money + numeric detail. */
  tabular?: boolean
}

export function Text({
  variant = 'body',
  color,
  align,
  tabular,
  style,
  children,
  ...rest
}: RzTextProps) {
  const t = type[variant]
  const family =
    variant === 'display' || variant === 'heading' ? fonts.display : fonts.body
  return (
    <RNText
      {...rest}
      style={[
        {
          color: color ?? colors.text,
          fontSize: t.fontSize,
          lineHeight: t.lineHeight,
          fontWeight: t.weight,
          fontFamily: family,
          textAlign: align,
        },
        'letterSpacing' in t ? { letterSpacing: (t as { letterSpacing?: number }).letterSpacing } : null,
        tabular ? { fontVariant: ['tabular-nums'] } : null,
        style,
      ]}
    >
      {children}
    </RNText>
  )
}
