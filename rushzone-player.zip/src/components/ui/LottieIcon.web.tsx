import { StyleSheet, type StyleProp, type ViewStyle } from 'react-native'
import { DotLottieReact } from '@lottiefiles/dotlottie-react'
import coin from '../../../assets/lottie/coin.json'
import pulse from '../../../assets/lottie/pulse.json'
import sparkle from '../../../assets/lottie/sparkle.json'
import wallet from '../../../assets/lottie/wallet.json'
import sendMoney from '../../../assets/lottie/send-money.json'
import money from '../../../assets/lottie/money.json'

const SOURCES = {
  coin,
  pulse,
  sparkle,
  wallet,
  sendMoney,
  money,
} as const

export type LottieName = keyof typeof SOURCES

interface LottieIconProps {
  name: LottieName
  size?: number
  style?: StyleProp<ViewStyle>
}

/**
 * Web variant — renders with @lottiefiles/dotlottie-react so the web bundle
 * never resolves `lottie-react-native` (whose ESM build has broken on some
 * installs). The native variant lives in LottieIcon.tsx.
 */
export function LottieIcon({ name, size = 24, style }: LottieIconProps) {
  const flattened = StyleSheet.flatten([{ width: size, height: size }, style]) as Record<string, unknown>
  return <DotLottieReact data={SOURCES[name] as unknown as Record<string, unknown>} autoplay loop style={flattened} />
}
