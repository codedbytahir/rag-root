import type { ReactNode } from 'react'
import { Pressable, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { colors, spacing, touchTarget } from '@/theme/tokens'
import { Text } from '@/components/ui/Text'

interface ScreenHeaderProps {
  title: string
  onBack?: () => void
  right?: ReactNode
}

/**
 * Standard pushed-screen header: back chevron + editorial title (+ optional
 * right-side action). Screens wrap this in their own padded container.
 */
export function ScreenHeader({ title, onBack, right }: ScreenHeaderProps) {
  const router = useRouter()
  return (
    <View style={styles.row}>
      <Pressable
        onPress={onBack ?? (() => router.back())}
        hitSlop={8}
        accessibilityRole="button"
        accessibilityLabel="Go back"
        style={styles.back}
      >
        <Ionicons name="arrow-back" size={24} color={colors.text} />
      </Pressable>
      <Text variant="display" style={styles.title} numberOfLines={1}>
        {title}
      </Text>
      {right ? <View style={styles.right}>{right}</View> : null}
    </View>
  )
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  back: {
    width: touchTarget,
    height: touchTarget,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: -spacing.sm,
  },
  title: { flex: 1 },
  right: { marginLeft: 'auto' },
})
