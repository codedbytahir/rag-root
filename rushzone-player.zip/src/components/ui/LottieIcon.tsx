import type { StyleProp, ViewStyle } from 'react-native'
import LottieView from 'lottie-react-native'
import coin from '../../../assets/lottie/coin.json'
import pulse from '../../../assets/lottie/pulse.json'
import sparkle from '../../../assets/lottie/sparkle.json'
import wallet from '../../../assets/lottie/wallet.json'
import sendMoney from '../../../assets/lottie/send-money.json'
import money from '../../../assets/lottie/money.json'

const SOURCES = {
  coin,
  pulse,
  sparkle,
  wallet,
  sendMoney,
  money,
} as const

export type LottieName = keyof typeof SOURCES

interface LottieIconProps {
  name: LottieName
  size?: number
  style?: StyleProp<ViewStyle>
}

/**
 * Tiny wrapper over LottieView for the bundled animations (coin bounce,
 * pulse rings, cross sparkle). Loops forever; wrap in a parent with
 * overflow hidden / positioning when overlaying content.
 */
export function LottieIcon({ name, size = 24, style }: LottieIconProps) {
  return (
    <LottieView
      source={SOURCES[name] as never}
      autoPlay
      loop
      style={[{ width: size, height: size }, style]}
    />
  )
}
