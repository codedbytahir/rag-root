import { StyleSheet, View } from 'react-native'
import { colors, spacing } from '@/theme/tokens'
import { Text } from './ui/Text'

export function LaunchScreen() {
  return (
    <View style={styles.root}>
      <View style={styles.lockup}>
        <Text variant="display" align="center">
          RUSH ZONE
        </Text>
        <Text variant="micro" color={colors.textSecondary} align="center" style={styles.sub}>
          PLAYER APP
        </Text>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.canvas,
    alignItems: 'center',
    justifyContent: 'center',
  },
  lockup: { gap: spacing.sm },
  sub: { letterSpacing: 2 },
})
