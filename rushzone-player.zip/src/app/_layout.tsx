import { useEffect, useRef } from 'react'
import { Stack, usePathname, useRouter } from 'expo-router'
import { StatusBar } from 'expo-status-bar'
import { ObserveRoot, useObserve } from 'expo-observe'
import { AuthProvider, useAuth } from '@/stores/auth'
import { ConfigProvider, useConfig } from '@/stores/config'
import { colors } from '@/theme/tokens'
import { LaunchScreen } from '@/components/LaunchScreen'
import { UploadProgressOverlay } from '@/components/UploadProgressOverlay'
import { FloatingSupportButton } from '@/components/FloatingSupportButton'
import { FatalErrorScreen } from '@/components/ErrorBoundary'
import { configureNotifications, registerPushToken } from '@/lib/notifications'
import { installGlobalErrorHandler } from '@/lib/errorReporter'
import { env } from '@/lib/env'

// Catch uncaught JS errors globally (recorded + reported to EAS Observe)
// instead of letting release builds die with no explanation.
installGlobalErrorHandler()

// Configure foreground notification presentation before any notification fires.
configureNotifications()

export default function RootLayout() {
  return (
    <ObserveRoot
      errorBoundaryFallback={({ error, resetError }) => (
        <FatalErrorScreen
          title="Something went wrong"
          message={error instanceof Error ? error.message : String(error)}
          onRetry={resetError}
        />
      )}
    >
      <AuthProvider>
        <ConfigProvider>
          <RootNavigator />
        </ConfigProvider>
      </AuthProvider>
    </ObserveRoot>
  )
}

function RootNavigator() {
  const { phase } = useAuth()
  const { gate } = useConfig()
  const router = useRouter()
  const pathname = usePathname()
  const { markInteractive } = useObserve()

  const isLoading = gate.status === 'loading' || phase === 'loading'
  const pushRegistered = useRef(false)

  // Fatal startup guard: never boot with a broken Supabase client. Show the
  // exact reason instead of a silent crash.
  if (env.isMisconfigured) {
    return (
      <>
        <StatusBar style="light" />
        <FatalErrorScreen
          title="App not configured"
          message="The app is missing its backend connection settings."
          detail="Missing EXPO_PUBLIC_SUPABASE_URL or EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY. Reinstall the latest build."
        />
      </>
    )
  }

  useEffect(() => {
    if (phase === 'ready' && !pushRegistered.current) {
      pushRegistered.current = true
      void registerPushToken()
    }
  }, [phase])

  useEffect(() => {
    if (isLoading) return

    if (gate.status === 'maintenance') {
      router.replace('/maintenance')
    } else if (gate.status === 'forceUpdate') {
      router.replace('/force-update')
    } else if (phase === 'signedOut') {
      router.replace('/login')
    } else if (phase === 'needsConsent') {
      router.replace('/consent')
    } else if (phase === 'needsProfile') {
      router.replace('/profile-setup')
    } else if (phase === 'ready') {
      const nonMain =
        pathname === '/login' ||
        pathname === '/consent' ||
        pathname === '/profile-setup' ||
        pathname === '/maintenance' ||
        pathname === '/force-update'
      if (nonMain) router.replace('/')
    }
  }, [isLoading, gate.status, phase, pathname, router])

  // App is interactive once the splash/bootstrap work is done.
  useEffect(() => {
    if (!isLoading) markInteractive()
  }, [isLoading, markInteractive])

  if (isLoading) {
    return (
      <>
        <StatusBar style="light" />
        <LaunchScreen />
      </>
    )
  }

  return (
    <>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: colors.canvas },
          animation: 'fade',
        }}
      />
      <UploadProgressOverlay />
      {phase === 'ready' ? <FloatingSupportButton /> : null}
    </>
  )
}
