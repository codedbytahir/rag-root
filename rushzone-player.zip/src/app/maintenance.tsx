import { StyleSheet, View } from 'react-native'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Button } from '@/components/ui/Button'
import { useConfig } from '@/stores/config'
import { colors, spacing } from '@/theme/tokens'

export default function MaintenanceScreen() {
  const { gate, refresh } = useConfig()
  const message = gate.status === 'maintenance' ? gate.message : undefined

  return (
    <Screen edges={['top', 'bottom']} contentContainerStyle={styles.center}>
      <View style={styles.content}>
        <Text variant="display" align="center">
          Maintenance
        </Text>
        <Text variant="body" color={colors.textSecondary} align="center" style={styles.body}>
          {message && message.trim() ? message : 'Rush Zone is briefly offline for maintenance. Please check back soon.'}
        </Text>
        <Button label="Try again" variant="secondary" fullWidth={false} onPress={() => void refresh()} style={styles.button} />
      </View>
    </Screen>
  )
}

const styles = StyleSheet.create({
  center: { justifyContent: 'center' },
  content: { alignItems: 'center', gap: spacing.md },
  body: { marginTop: spacing.xs },
  button: { marginTop: spacing.xxl, paddingHorizontal: spacing.xxl },
})
