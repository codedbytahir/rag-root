import { useCallback, useEffect, useMemo, useState } from 'react'
import { RefreshControl, ScrollView, StyleSheet, View } from 'react-native'
import { useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { StatusChip } from '@/components/ui/StatusChip'
import { EmptyState } from '@/components/ui/EmptyState'
import { Skeleton } from '@/components/ui/Skeleton'
import { useAuth } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing } from '@/theme/tokens'
import { formatCoins, formatPKTDateTime } from '@/lib/format'
import { statusMeta } from '@/lib/tournaments'
import type { RegistrationsRow, TournamentsRow } from '@/lib/database.types'

type Item = { reg: RegistrationsRow; tournament: TournamentsRow }

const ROOM_STATUSES = ['room_released', 'live']
const UPCOMING_STATUSES = ['scheduled', 'registration_open', 'registration_full', 'registration_closed']
const RESULT_STATUSES = ['results_pending', 'completed']

export default function MyTournamentsScreen() {
  const router = useRouter()
  const { profile } = useAuth()
  const [items, setItems] = useState<Item[] | null>(null)
  const [refreshing, setRefreshing] = useState(false)

  const load = useCallback(async () => {
    if (!profile?.id) return
    const regs = await supabase
      .from('registrations')
      .select('*')
      .eq('profile_id', profile.id)
      .order('created_at', { ascending: false })
    const rows = (regs.data as RegistrationsRow[] | null) ?? []
    if (rows.length === 0) {
      setItems([])
      return
    }
    const ids = rows.map((r) => r.tournament_id)
    const t = await supabase.from('tournaments').select('*').in('id', ids)
    const tournaments = new Map((t.data as TournamentsRow[] | null ?? []).map((x) => [x.id, x]))
    setItems(
      rows
        .map((reg) => ({ reg, tournament: tournaments.get(reg.tournament_id) }))
        .filter((x): x is Item => Boolean(x.tournament)),
    )
  }, [profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  const onRefresh = useCallback(async () => {
    setRefreshing(true)
    await load()
    setRefreshing(false)
  }, [load])

  const sections = useMemo(() => {
    if (!items) return null
    const pick = (statuses: string[]) => items.filter((i) => statuses.includes(i.tournament.status))
    return [
      { key: 'room', title: 'Room released', list: pick(ROOM_STATUSES) },
      { key: 'upcoming', title: 'Upcoming', list: pick(UPCOMING_STATUSES) },
      { key: 'results', title: 'Live & results', list: pick(RESULT_STATUSES) },
      { key: 'cancelled', title: 'Cancelled', list: pick(['cancelled']) },
    ].filter((s) => s.list.length > 0)
  }, [items])

  const open = (tournament: TournamentsRow) => {
    if (ROOM_STATUSES.includes(tournament.status)) router.push(`/room/${tournament.id}`)
    else if (RESULT_STATUSES.includes(tournament.status)) router.push(`/result/${tournament.id}`)
    else router.push(`/tournament/${tournament.id}`)
  }

  return (
    <Screen edges={['top']} padded={false}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.text} />
        }
      >
        <View style={styles.head}>
          <ScreenHeader title="My Tournaments" />
        </View>

        {!items ? (
          <View style={styles.skeletonWrap}>
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} height={120} radius={radii.card} style={styles.skeleton} />
            ))}
          </View>
        ) : items.length === 0 ? (
          <EmptyState
            title="No tournaments yet"
            body="Join a tournament and it will show up here with room details and results."
            actionLabel="Browse tournaments"
            onAction={() => router.push('/tournaments')}
          />
        ) : (
          sections?.map((section) => (
            <View key={section.key} style={styles.section}>
              <Text variant="heading" style={styles.sectionTitle}>
                {section.title}
              </Text>
              {section.list.map(({ reg, tournament }) => {
                const meta = statusMeta(tournament.status)
                return (
                  <Card key={reg.id} onPress={() => open(tournament)} style={styles.card}>
                    <View style={styles.cardHead}>
                      <Text variant="title" style={{ flex: 1 }} numberOfLines={1}>
                        {tournament.title}
                      </Text>
                      {meta ? <StatusChip tone={meta.tone} label={meta.label} /> : null}
                    </View>
                    <Text variant="caption" color={colors.textSecondary}>
                      Slot #{reg.slot_number ?? '—'} · {tournament.mode}
                      {tournament.map ? ` · ${tournament.map}` : ''}
                    </Text>
                    <View style={styles.cardFoot}>
                      <Text variant="caption" color={colors.textDisabled}>
                        {tournament.match_start_at ? formatPKTDateTime(tournament.match_start_at) : 'TBA'}
                      </Text>
                      <Text variant="money" color={colors.emphasis}>
                        {formatCoins(reg.fee_snapshot)} coins
                      </Text>
                    </View>
                  </Card>
                )
              })}
            </View>
          ))
        )}
      </ScrollView>
    </Screen>
  )
}

const styles = StyleSheet.create({
  scroll: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  head: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.lg },
  skeletonWrap: { gap: spacing.lg },
  skeleton: { marginBottom: spacing.sm },
  section: { marginTop: spacing.lg },
  sectionTitle: { marginBottom: spacing.md },
  card: { marginBottom: spacing.md },
  cardHead: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.xs },
  cardFoot: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.sm,
    paddingTop: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.divider,
  },
})
