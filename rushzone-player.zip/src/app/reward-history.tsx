import { useCallback, useEffect, useState } from 'react'
import { FlatList, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { Skeleton } from '@/components/ui/Skeleton'
import { useAuth } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import { colors, spacing } from '@/theme/tokens'
import { formatCoins, formatPKTDateTime } from '@/lib/format'
// Minimal local type — reward_attempts isn't in the typed schema yet.
interface AttemptLike {
  id: string
  coins_won: number
  source: string
  created_at: string
}

export default function RewardHistoryScreen() {
  const router = useRouter()
  const { profile } = useAuth()
  const [items, setItems] = useState<AttemptLike[] | null>(null)

  const load = useCallback(async () => {
    if (!profile?.id) return
    const res = await supabase
      .from('reward_attempts')
      .select('id, coins_won, source, created_at')
      .eq('profile_id', profile.id)
      .order('created_at', { ascending: false })
      .limit(50)
    setItems((res.data as AttemptLike[] | null) ?? [])
  }, [profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  return (
    <Screen edges={['top']} padded={false}>
      <View style={styles.head}>
        <ScreenHeader title="Reward history" />
      </View>

      {!items ? (
        <View style={styles.skeletonWrap}>
          <Skeleton height={80} />
          <Skeleton height={80} />
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(i) => i.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <Card style={styles.row}>
              <View style={styles.rowHead}>
                <Ionicons name="gift-outline" size={18} color={colors.textSecondary} />
                <Text variant="body" style={{ flex: 1 }}>
                  {item.source === 'paid' ? 'Paid spin' : 'Ad spin'}
                </Text>
                <Text variant="money" color={colors.emphasis}>
                  +{formatCoins(item.coins_won)}
                </Text>
              </View>
              <Text variant="caption" color={colors.textDisabled}>
                {formatPKTDateTime(item.created_at)}
              </Text>
            </Card>
          )}
          ListEmptyComponent={
            <EmptyState title="No spins yet" body="Your spin results will appear here." />
          }
        />
      )}
    </Screen>
  )
}

const styles = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, padding: spacing.lg, paddingBottom: spacing.sm },
  skeletonWrap: { padding: spacing.lg, gap: spacing.md },
  list: { padding: spacing.lg, paddingBottom: spacing.xxxl, flexGrow: 1 },
  row: { gap: spacing.xs, marginBottom: spacing.md },
  rowHead: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
})
