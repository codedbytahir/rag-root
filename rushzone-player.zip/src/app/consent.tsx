import { useMemo, useState } from 'react'
import { Linking, Pressable, StyleSheet, View } from 'react-native'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/stores/auth'
import { useConfig } from '@/stores/config'
import { colors, spacing, touchTarget } from '@/theme/tokens'
import type { PolicyLink } from '@/lib/config'

export default function ConsentScreen() {
  const { acceptConsent } = useAuth()
  const { config } = useConfig()
  const [checked, setChecked] = useState<Record<string, boolean>>({})

  const links: PolicyLink[] = useMemo(() => {
    const list = config?.policy_links
    if (Array.isArray(list)) return list.filter((p) => p?.label && p?.url)
    return []
  }, [config])

  const allChecked = links.length > 0 && links.every((p) => checked[p.id ?? p.label ?? ''])

  const toggle = (key: string) => setChecked((c) => ({ ...c, [key]: !c[key] }))

  return (
    <Screen scroll edges={['top', 'bottom']}>
      <Text variant="display" style={styles.title}>
        Before you start
      </Text>
      <Text variant="body" color={colors.textSecondary}>
        Review and accept our policies to continue. You can read each one below.
      </Text>

      <View style={styles.list}>
        {links.map((p) => {
          const key = p.id ?? p.label ?? ''
          const isChecked = Boolean(checked[key])
          return (
            <View key={key} style={styles.row}>
              <Pressable
                style={[styles.check, isChecked ? styles.checkOn : null]}
                onPress={() => toggle(key)}
                accessibilityRole="checkbox"
                accessibilityState={{ checked: isChecked }}
                hitSlop={8}
              >
                {isChecked ? <Text variant="title">✓</Text> : null}
              </Pressable>
              <Pressable
                style={styles.rowLabel}
                onPress={() => toggle(key)}
                accessibilityRole="checkbox"
                accessibilityState={{ checked: isChecked }}
              >
                <Text variant="body" color={colors.text}>
                  I accept the {p.label}
                </Text>
              </Pressable>
              {p.url ? (
                <Pressable
                  style={styles.link}
                  onPress={() => Linking.openURL(p.url as string)}
                  hitSlop={8}
                >
                  <Text variant="label" color={colors.textSecondary}>
                    View
                  </Text>
                </Pressable>
              ) : null}
            </View>
          )
        })}
      </View>

      <View style={styles.footer}>
        <Button label="Accept & continue" onPress={() => acceptConsent()} disabled={!allChecked} />
        <Text variant="caption" color={colors.textDisabled} align="center">
          You can review these anytime from Profile → Policies.
        </Text>
      </View>
    </Screen>
  )
}

const styles = StyleSheet.create({
  title: { marginBottom: spacing.sm },
  list: { gap: spacing.md, marginTop: spacing.xxl },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    minHeight: touchTarget,
  },
  check: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: colors.strokeStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkOn: { backgroundColor: colors.action, borderColor: colors.action },
  rowLabel: { flex: 1, justifyContent: 'center' },
  link: { paddingVertical: spacing.sm },
  footer: { gap: spacing.md, marginTop: spacing.xxxl },
})
