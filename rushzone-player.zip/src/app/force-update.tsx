import { Linking, StyleSheet, View } from 'react-native'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Button } from '@/components/ui/Button'
import { useConfig } from '@/stores/config'
import { colors, spacing } from '@/theme/tokens'

export default function ForceUpdateScreen() {
  const { config } = useConfig()
  const storeUrl =
    (config?.stores as { android?: string } | undefined)?.android ??
    config?.landing_page_url

  return (
    <Screen edges={['top', 'bottom']} contentContainerStyle={styles.center}>
      <View style={styles.content}>
        <Text variant="display" align="center">
          Update required
        </Text>
        <Text variant="body" color={colors.textSecondary} align="center" style={styles.body}>
          A newer version of Rush Zone is available. Update to keep playing.
        </Text>
        {storeUrl ? (
          <Button
            label="Update now"
            onPress={() => void Linking.openURL(storeUrl)}
            style={styles.button}
            fullWidth={false}
          />
        ) : null}
      </View>
    </Screen>
  )
}

const styles = StyleSheet.create({
  center: { justifyContent: 'center' },
  content: { alignItems: 'center', gap: spacing.md },
  body: { marginTop: spacing.xs },
  button: { marginTop: spacing.xxl, paddingHorizontal: spacing.xxl },
})
