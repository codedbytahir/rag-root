import { useState } from 'react'
import { Image, Pressable, StyleSheet, View } from 'react-native'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/stores/auth'
import { colors, radii, spacing } from '@/theme/tokens'
import { isValidDisplayName, isValidFFUID, isValidWhatsappPhone } from '@/lib/format'
import { pickAndResizeAvatar } from '@/lib/avatar'

interface FieldErrors {
  displayName?: string
  ffUid?: string
  inGameName?: string
  whatsappPhone?: string
}

export default function ProfileSetupScreen() {
  const { completeProfile } = useAuth()
  const [displayName, setDisplayName] = useState('')
  const [ffUid, setFfUid] = useState('')
  const [inGameName, setInGameName] = useState('')
  const [whatsappPhone, setWhatsappPhone] = useState('')
  const [referralCode, setReferralCode] = useState('')
  const [avatarUri, setAvatarUri] = useState<string | null>(null)
  const [errors, setErrors] = useState<FieldErrors>({})
  const [formError, setFormError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [picking, setPicking] = useState(false)

  const onPickAvatar = async () => {
    setPicking(true)
    const uri = await pickAndResizeAvatar()
    setPicking(false)
    if (uri) setAvatarUri(uri)
  }

  const validate = (): FieldErrors => {
    const e: FieldErrors = {}
    if (!isValidDisplayName(displayName)) e.displayName = '2–30 characters.'
    if (!isValidFFUID(ffUid)) e.ffUid = 'Enter a valid Free Fire UID (digits).'
    if (!inGameName.trim()) e.inGameName = 'Enter your in-game name.'
    if (!isValidWhatsappPhone(whatsappPhone)) e.whatsappPhone = 'Use +92 format, e.g. +923001234567.'
    return e
  }

  const onSubmit = async () => {
    setFormError(null)
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length > 0) return

    setLoading(true)
    try {
      const err = await completeProfile({
        displayName,
        ffUid,
        inGameName,
        whatsappPhone,
        avatarUri,
        referralCode: referralCode.trim() || null,
      })
      if (err) setFormError(err)
    } catch {
      setFormError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Screen scroll keyboard edges={['top', 'bottom']}>
      <Text variant="display" style={styles.title}>
        Set up your profile
      </Text>
      <Text variant="body" color={colors.textSecondary}>
        This is how you&apos;ll appear in Rush Zone. Your Free Fire UID is used to
        verify results and cannot be linked to multiple accounts.
      </Text>

      <View style={styles.avatarRow}>
        <Pressable
          onPress={onPickAvatar}
          accessibilityRole="button"
          accessibilityLabel="Add profile photo"
          style={styles.avatar}
        >
          {avatarUri ? (
            <Image source={{ uri: avatarUri }} style={styles.avatarImg} />
          ) : (
            <Text variant="display" color={colors.textDisabled}>
              +
            </Text>
          )}
        </Pressable>
        <View style={styles.avatarMeta}>
          <Text variant="label">Profile photo</Text>
          <Text variant="caption" color={colors.textDisabled}>
            {picking ? 'Opening library…' : 'Optional · compressed to 512px'}
          </Text>
        </View>
      </View>

      <View style={styles.form}>
        <Input
          label="Display name"
          value={displayName}
          onChangeText={setDisplayName}
          placeholder="e.g. FalconX"
          autoCapitalize="words"
          error={errors.displayName}
        />
        <Input
          label="Free Fire UID"
          value={ffUid}
          onChangeText={(t) => setFfUid(t.replace(/\D/g, ''))}
          placeholder="Your Free Fire player UID"
          keyboardType="number-pad"
          error={errors.ffUid}
        />
        <Input
          label="In-game name"
          value={inGameName}
          onChangeText={setInGameName}
          placeholder="Your Free Fire in-game name"
          autoCapitalize="words"
          error={errors.inGameName}
        />
        <Input
          label="WhatsApp number"
          value={whatsappPhone}
          onChangeText={setWhatsappPhone}
          placeholder="+923001234567"
          keyboardType="phone-pad"
          error={errors.whatsappPhone}
          helper="Used for support & withdrawal details only — not to log in."
        />
        <Input
          label="Referral code (optional)"
          value={referralCode}
          onChangeText={setReferralCode}
          placeholder="Friend's code"
          autoCapitalize="characters"
          autoCorrect={false}
        />

        {formError ? (
          <Text variant="caption" color={colors.textSecondary}>
            ⚠ {formError}
          </Text>
        ) : null}

        <Button label="Create profile" onPress={onSubmit} loading={loading} />
      </View>
    </Screen>
  )
}

const styles = StyleSheet.create({
  title: { marginBottom: spacing.sm },
  avatarRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg, marginTop: spacing.xxl },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: radii.badge,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarImg: { width: '100%', height: '100%' },
  avatarMeta: { gap: spacing.xs },
  form: { gap: spacing.lg, marginTop: spacing.xxl },
})
