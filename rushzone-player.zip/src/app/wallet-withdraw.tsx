import { useCallback, useEffect, useState } from 'react'
import { Linking, Pressable, ScrollView, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { StatusChip } from '@/components/ui/StatusChip'
import { Skeleton } from '@/components/ui/Skeleton'
import { LottieIcon } from '@/components/ui/LottieIcon'
import { supportChatUrl } from '@/components/FloatingSupportButton'
import { useAuth } from '@/stores/auth'
import { useConfig } from '@/stores/config'
import { supabase } from '@/lib/supabase'
import { callEdge } from '@/lib/api'
import { colors, radii, spacing } from '@/theme/tokens'
import { formatCoins, formatPKTDateTime, normalizeWhatsappPhone } from '@/lib/format'
import type { WalletAccountsRow, WithdrawalRequestsRow } from '@/lib/database.types'

const METHODS = ['easypaisa', 'jazzcash'] as const
const METHOD_LABEL: Record<string, string> = { easypaisa: 'Easypaisa', jazzcash: 'JazzCash' }
const STATUS_TONE: Record<string, 'success' | 'danger' | 'neutral' | 'info'> = {
  pending_review: 'info',
  approved: 'info',
  paid: 'success',
  rejected: 'danger',
  cancelled: 'neutral',
}

export default function WithdrawScreen() {
  const { profile } = useAuth()
  const { config } = useConfig()
  const adminChatUrl = supportChatUrl(
    config?.whatsapp_support_url as string | undefined,
    config?.support_phone as string | undefined,
    'Hi! I have a question about my withdrawal request.',
  )
  const [wallet, setWallet] = useState<WalletAccountsRow | null>(null)
  const [method, setMethod] = useState<(typeof METHODS)[number]>('easypaisa')
  const [phone, setPhone] = useState('')
  const [amount, setAmount] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [requests, setRequests] = useState<WithdrawalRequestsRow[] | null>(null)
  const [initialLoading, setInitialLoading] = useState(true)

  const load = useCallback(async () => {
    if (!profile?.id) return
    const [w, r] = await Promise.all([
      supabase.from('wallet_accounts').select('*').eq('profile_id', profile.id).maybeSingle(),
      supabase
        .from('withdrawal_requests')
        .select('*')
        .eq('profile_id', profile.id)
        .order('created_at', { ascending: false })
        .limit(10),
    ])
    setWallet((w.data as WalletAccountsRow | null) ?? null)
    setRequests((r.data as WithdrawalRequestsRow[] | null) ?? [])
    setInitialLoading(false)
  }, [profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  const submit = async () => {
    setError(null)
    const coins = Number(amount)
    const account = normalizeWhatsappPhone(phone)
    if (!Number.isInteger(coins) || coins <= 0) {
      setError('Enter a valid whole number of coins.')
      return
    }
    if (wallet && coins > wallet.available_balance) {
      setError('You do not have enough available coins.')
      return
    }
    if (!account) {
      setError('Enter a valid Pakistan mobile number (+92…).')
      return
    }
    setLoading(true)
    const res = await callEdge('wallet-withdraw-create', {
      method,
      account_snapshot: account,
      amount_coins: coins,
    })
    setLoading(false)
    if (res.error) {
      setError(res.error.message)
      return
    }
    setAmount('')
    setPhone('')
    await load()
  }

  const cancel = async (withdrawalId: string) => {
    const res = await callEdge('wallet-withdraw-cancel', { withdrawal_id: withdrawalId })
    if (!res.error) await load()
  }

  const available = wallet?.available_balance ?? 0
  const held = wallet?.held_balance ?? 0

  return (
    <Screen scroll edges={['top', 'bottom']}>
      <View style={styles.head}>
        <ScreenHeader title="Withdraw" />
      </View>
      <View style={styles.hero}>
        <LottieIcon name="money" size={140} />
      </View>
      <Text variant="body" color={colors.textSecondary} style={styles.sub}>
        Withdrawals are reviewed and paid manually — target within 24 hours.
      </Text>

      <Card style={styles.card}>
        <View style={styles.balances}>
          {initialLoading ? (
            <>
              <Skeleton height={64} radius={radii.input} style={styles.balanceBox} />
              <Skeleton height={64} radius={radii.input} style={styles.balanceBox} />
            </>
          ) : (
            <>
              <BalanceBox label="Available" value={formatCoins(available)} />
              <BalanceBox label="Held" value={formatCoins(held)} />
            </>
          )}
        </View>

        <Text variant="label" color={colors.textSecondary} style={styles.fieldLabel}>
          Payout method
        </Text>
        <View style={styles.methods}>
          {METHODS.map((m) => {
            const active = m === method
            return (
              <Pressable
                key={m}
                onPress={() => setMethod(m)}
                style={[styles.method, active ? styles.methodActive : null]}
              >
                <Text variant="label" color={active ? colors.onAction : colors.textSecondary}>
                  {METHOD_LABEL[m]}
                </Text>
              </Pressable>
            )
          })}
        </View>

        <Input
          label="Payout phone (Easypaisa / JazzCash)"
          value={phone}
          onChangeText={setPhone}
          keyboardType="phone-pad"
          placeholder="+923001234567"
          containerStyle={styles.field}
        />
        <Input
          label="Amount (Rush Coins)"
          value={amount}
          onChangeText={(v) => setAmount(v.replace(/\D/g, ''))}
          keyboardType="number-pad"
          placeholder={`Up to ${formatCoins(available)}`}
          containerStyle={styles.field}
        />

        {error ? (
          <Text variant="caption" color={colors.textSecondary} style={styles.error}>
            ⚠ {error}
          </Text>
        ) : null}

        <Button label="Request withdrawal" onPress={submit} loading={loading} variant="danger" />
      </Card>

      {adminChatUrl ? (
        <Card style={styles.adminCard}>
          <View style={styles.adminRow}>
            <Ionicons name="headset-outline" size={22} color={colors.text} />
            <View style={{ flex: 1 }}>
              <Text variant="title">Need help with a withdrawal?</Text>
              <Text variant="caption" color={colors.textSecondary}>
                Chat with an admin — we usually reply quickly on WhatsApp.
              </Text>
            </View>
          </View>
          <Button
            label="Contact admin"
            variant="secondary"
            onPress={() => void Linking.openURL(adminChatUrl)}
          />
        </Card>
      ) : null}

      {initialLoading ? (
        <View style={styles.history}>
          <Skeleton height={24} width="50%" />
          <Skeleton height={96} radius={radii.card} />
          <Skeleton height={96} radius={radii.card} />
        </View>
      ) : requests && requests.length > 0 ? (
        <View style={styles.history}>
          <Text variant="heading">Recent withdrawals</Text>
          {requests.map((r) => (
            <Card key={r.id} style={styles.historyCard}>
              <View style={styles.historyHead}>
                <Text variant="body" style={{ flex: 1 }}>
                  {METHOD_LABEL[r.method] ?? r.method} · {formatCoins(r.amount_coins)} coins
                </Text>
                <StatusChip tone={STATUS_TONE[r.status] ?? 'neutral'} label={r.status.replace('_', ' ')} />
              </View>
              <Text variant="caption" color={colors.textDisabled}>
                {formatPKTDateTime(r.created_at)}
                {r.reject_reason ? ` · ${r.reject_reason}` : ''}
              </Text>
              {r.status === 'pending_review' ? (
                <Button label="Cancel request" variant="ghost" size="sm" fullWidth={false} onPress={() => void cancel(r.id)} />
              ) : null}
            </Card>
          ))}
        </View>
      ) : null}
    </Screen>
  )
}

function BalanceBox({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.balanceBox}>
      <Text variant="caption" color={colors.textSecondary}>
        {label}
      </Text>
      <Text variant="money" color={colors.emphasis}>
        {value}
      </Text>
    </View>
  )
}

const styles = StyleSheet.create({
  head: { marginBottom: spacing.lg },
  sub: { marginTop: spacing.xs },
  card: { marginTop: spacing.lg, gap: spacing.md },
  balances: { flexDirection: 'row', gap: spacing.md },
  balanceBox: {
    flex: 1,
    backgroundColor: colors.inset,
    borderRadius: radii.input,
    padding: spacing.md,
    gap: spacing.xs,
  },
  fieldLabel: { marginTop: spacing.md },
  methods: { flexDirection: 'row', gap: spacing.sm },
  method: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radii.button,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
  },
  methodActive: { backgroundColor: colors.action, borderColor: colors.action },
  field: { marginTop: spacing.md },
  error: { marginTop: spacing.xs },
  history: { marginTop: spacing.xxl, gap: spacing.md },
  historyCard: { gap: spacing.xs },
  historyHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: spacing.sm },
  hero: { alignItems: 'center', marginTop: spacing.lg },
  adminCard: { marginTop: spacing.xl, gap: spacing.md },
  adminRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
})
