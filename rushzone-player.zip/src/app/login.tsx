import { useState } from 'react'
import { StyleSheet, View } from 'react-native'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/stores/auth'
import { colors, spacing } from '@/theme/tokens'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export default function LoginScreen() {
  const { signInWithPassword } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const onSubmit = async () => {
    setError(null)
    const normalizedEmail = email.trim()
    if (!EMAIL_RE.test(normalizedEmail)) {
      setError('Enter a valid email address.')
      return
    }
    if (password.length < 6) {
      setError('Enter a password (at least 6 characters).')
      return
    }
    setLoading(true)
    try {
      const err = await signInWithPassword(normalizedEmail, password)
      if (err) setError(err)
      // On success, onAuthStateChange re-derives the phase from the new session.
    } catch (e) {
      // signInWithPassword already returns errors as strings, but guard against
      // anything unexpected so the button can never stay stuck in loading.
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Screen scroll keyboard edges={['top', 'bottom']} contentContainerStyle={styles.center}>
      <View style={styles.lockup}>
        <Text variant="display" align="center">
          RUSH ZONE
        </Text>
        <Text variant="micro" color={colors.textSecondary} align="center">
          PLAYER APP
        </Text>
      </View>

      <Text variant="heading" align="center" style={styles.title}>
        Sign in to play
      </Text>
      <Text variant="body" color={colors.textSecondary} align="center">
        Enter your email and password to sign in. New here? Your account is created automatically.
      </Text>

      <View style={styles.form}>
        <Input
          label="Email"
          value={email}
          onChangeText={setEmail}
          placeholder="you@example.com"
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
          autoCorrect={false}
          error={error}
        />
        <Input
          label="Password"
          value={password}
          onChangeText={setPassword}
          placeholder="••••••••"
          secureTextEntry
          autoCapitalize="none"
          autoComplete="password"
          autoCorrect={false}
        />
        <Button label="Sign in" onPress={onSubmit} loading={loading} />
      </View>
    </Screen>
  )
}

const styles = StyleSheet.create({
  center: { justifyContent: 'center' },
  lockup: { gap: spacing.xs, marginBottom: spacing.xxxl },
  title: { marginBottom: spacing.sm },
  form: { gap: spacing.lg, marginTop: spacing.xxl },
})
