import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Animated, Easing, Modal, Pressable, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import * as Haptics from 'expo-haptics'
import Svg, { Circle, G, Path, Text as SvgText } from 'react-native-svg'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { useAuth } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import { callEdge } from '@/lib/api'
import { colors, fonts, radii, spacing } from '@/theme/tokens'
import { formatCoins } from '@/lib/format'
import type { RewardCampaignsRow, RewardItemsRow, WalletAccountsRow } from '@/lib/database.types'

const SIZE = 280
const R = SIZE / 2
// Monochrome wedge palette — alternating tones keep neighbours distinct.
const WEDGE_COLORS = ['#3A3A3A', '#1E1E1E', '#2C2C2C', '#161616']

interface SpinResult {
  coins_won?: number
  balance_after?: number
  attempt_id?: string
}

/** Point on a circle at `angleDeg` (0° = 3 o'clock, clockwise). */
function polar(cx: number, cy: number, r: number, angleDeg: number) {
  const rad = (angleDeg * Math.PI) / 180
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) }
}

/** Pie-slice path from start to end degrees (clockwise sweep). */
function wedgePath(cx: number, cy: number, r: number, startDeg: number, endDeg: number) {
  const start = polar(cx, cy, r, startDeg)
  const end = polar(cx, cy, r, endDeg)
  const largeArc = endDeg - startDeg > 180 ? 1 : 0
  return `M ${cx} ${cy} L ${start.x} ${start.y} A ${r} ${r} 0 ${largeArc} 1 ${end.x} ${end.y} Z`
}

export default function SpinScreen() {
  const router = useRouter()
  const { profile } = useAuth()
  const rotation = useRef(new Animated.Value(0)).current
  const rotationValue = useRef(0)

  const [campaign, setCampaign] = useState<RewardCampaignsRow | null>(null)
  const [items, setItems] = useState<RewardItemsRow[]>([])
  const [balance, setBalance] = useState<number>(0)
  const [loading, setLoading] = useState(true)
  const [spinning, setSpinning] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<SpinResult | null>(null)

  const load = useCallback(async () => {
    if (!profile?.id) return
    const [c, w] = await Promise.all([
      supabase.from('reward_campaigns').select('*').eq('status', 'active').limit(1).maybeSingle(),
      supabase.from('wallet_accounts').select('*').eq('profile_id', profile.id).maybeSingle(),
    ])
    const camp = (c.data as RewardCampaignsRow | null) ?? null
    setCampaign(camp)
    setBalance(((w.data as WalletAccountsRow | null)?.available_balance) ?? 0)
    if (camp) {
      const i = await supabase.from('reward_items').select('*').eq('campaign_id', camp.id)
      setItems((i.data as RewardItemsRow[] | null) ?? [])
    }
    setLoading(false)
  }, [profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  const paidCost = campaign?.paid_cost ?? 5
  const segments = useMemo(() => Math.max(4, items.length || 8), [items.length])
  const canSpin = !spinning && campaign?.paid_enabled && balance >= paidCost

  const spinPaid = async () => {
    if (!campaign || !canSpin) return
    setError(null)
    setSpinning(true)
    const res = await callEdge<SpinResult>('rewards-attempt-paid', { campaign_id: campaign.id })
    if (res.error) {
      setError(res.error.message)
      setSpinning(false)
      return
    }
    const won = res.data?.coins_won ?? 0

    // Land the winning wedge (the one matching coins_won) under the pointer at
    // the top; fall back to a random stop when the result has no matching slot.
    const seg = 360 / segments
    const winIndex = items.findIndex((it) => it.coins === won)
    let extra = winIndex >= 0 ? (270 - (winIndex + 0.5) * seg + 360) % 360 : 90 + Math.random() * 270
    if (extra < 90) extra += 360
    const target = rotationValue.current + 360 * 5 + extra
    rotationValue.current = target

    if (won > 0) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {})

    Animated.timing(rotation, {
      toValue: target,
      duration: 2600,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start(() => {
      setResult(res.data ?? {})
      setSpinning(false)
      setBalance((prev) => Math.max(0, prev - paidCost + won))
      void load()
    })
  }

  return (
    <Screen scroll edges={['top']}>
      <View style={styles.head}>
        <ScreenHeader title="Spin Wheel" />
      </View>
      <Text variant="body" color={colors.textSecondary} style={styles.sub}>
        Win Rush Coins. Results are decided and recorded by the server.
      </Text>

      <Card style={styles.wheelCard}>
        {loading ? (
          <Skeleton height={SIZE} radius={R} />
        ) : (
          <View style={styles.wheelWrap}>
            <View style={styles.pointer} pointerEvents="none">
              <Ionicons name="caret-down" size={32} color={colors.accent} />
            </View>
            <View style={styles.wheel}>
              <Animated.View style={{ transform: [{ rotate: rotation }] }}>
                <Svg width={SIZE} height={SIZE} viewBox={`0 0 ${SIZE} ${SIZE}`}>
                  <Circle cx={R} cy={R} r={R} fill={colors.inset} />
                  {Array.from({ length: segments }).map((_, i) => {
                    const start = i * (360 / segments)
                    const label = items[i] ? String(items[i].coins) : ''
                    return (
                      <G key={i} rotation={start} origin={`${R}, ${R}`}>
                        <Path
                          d={wedgePath(R, R, R, 0, 360 / segments)}
                          fill={WEDGE_COLORS[i % WEDGE_COLORS.length]}
                          stroke={colors.deep}
                          strokeWidth={1.5}
                        />
                        {label ? (
                          <SvgText
                            x={R + R * 0.6}
                            y={R}
                            fill={colors.text}
                            fontSize={15}
                            fontWeight="700"
                            fontFamily={fonts.body}
                            textAnchor="middle"
                            alignmentBaseline="middle"
                          >
                            {label}
                          </SvgText>
                        ) : null}
                      </G>
                    )
                  })}
                </Svg>
              </Animated.View>
              <View style={styles.hub} pointerEvents="none">
                <Ionicons name="gift" size={30} color={colors.accent} />
              </View>
            </View>
          </View>
        )}

        <Text variant="caption" color={colors.textSecondary}>
          Balance: {formatCoins(balance)} coins
        </Text>

        {error ? (
          <Text variant="caption" color={colors.textSecondary}>
            ⚠ {error}
          </Text>
        ) : null}

        <View style={styles.actions}>
          <Button
            label={`Spin · ${formatCoins(paidCost)} coins`}
            onPress={() => void spinPaid()}
            loading={spinning}
            disabled={!canSpin}
          />
          {campaign?.ad_enabled ? (
            <Button
              label="Watch ad (coming soon)"
              variant="secondary"
              disabled
            />
          ) : null}
        </View>

        <Pressable onPress={() => router.push('/reward-history')} hitSlop={8}>
          <Text variant="label" color={colors.textSecondary} style={styles.history}>
            Reward history →
          </Text>
        </Pressable>
      </Card>

      <Card style={styles.card}>
        <Text variant="title">How it works</Text>
        <Text variant="body" color={colors.textSecondary} style={styles.body}>
          A paid spin costs {formatCoins(paidCost)} coins and always awards a prize from the
          configured pool. Rewarded-ad spins are enabled later with the ad SDK — the server
          verifies ad completion before granting coins.
        </Text>
      </Card>

      <Modal visible={result !== null} transparent animationType="fade" onRequestClose={() => setResult(null)}>
        <View style={styles.modalBackdrop}>
          <View style={styles.sheet}>
            <Ionicons name="gift" size={48} color={colors.text} />
            <Text variant="display" color={colors.emphasis}>
              +{formatCoins(result?.coins_won ?? 0)} coins
            </Text>
            <Text variant="body" color={colors.textSecondary} align="center">
              Credited to your wallet.
            </Text>
            <Button
              label="Share"
              variant="secondary"
              fullWidth={false}
              onPress={() => {
                const coins = result?.coins_won ?? 0
                setResult(null)
                router.push({ pathname: '/share', params: { type: 'spin', coins: String(coins) } })
              }}
            />
            <Button label="Done" variant="ghost" fullWidth={false} onPress={() => setResult(null)} />
          </View>
        </View>
      </Modal>
    </Screen>
  )
}

const styles = StyleSheet.create({
  head: { marginBottom: spacing.md },
  sub: { marginTop: spacing.xs },
  wheelCard: { marginTop: spacing.lg, alignItems: 'center', gap: spacing.md },
  wheelWrap: { marginVertical: spacing.md, alignItems: 'center' },
  pointer: {
    position: 'absolute',
    top: -10,
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 10,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 4,
    elevation: 5,
  },
  wheel: {
    width: SIZE,
    height: SIZE,
    borderRadius: R,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.strokeStrong,
    backgroundColor: colors.inset,
  },
  hub: {
    position: 'absolute',
    left: R - 30,
    top: R - 30,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: colors.surfaceRaised,
    borderWidth: 1,
    borderColor: colors.strokeStrong,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10,
  },
  actions: { gap: spacing.sm, alignSelf: 'stretch' },
  history: { marginTop: spacing.md },
  card: { marginTop: spacing.lg },
  body: { marginTop: spacing.sm },
  modalBackdrop: { flex: 1, backgroundColor: colors.scrim, justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: colors.surfaceRaised,
    borderTopLeftRadius: radii.card,
    borderTopRightRadius: radii.card,
    borderWidth: 1,
    borderColor: colors.stroke,
    padding: spacing.xl,
    alignItems: 'center',
    gap: spacing.md,
  },
})
