import { useCallback, useEffect, useRef, useState } from 'react'
import { Pressable, ScrollView, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Dimensions } from 'react-native'
import ViewShot, { type ViewShotRef } from 'react-native-view-shot'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { ShareCard, type ShareCardData } from '@/components/ShareCard'
import {
  defaultCardFormat,
  recordShareEvent,
  shareCardImage,
  type ShareCardType,
} from '@/lib/shareCards'
import { useAuth } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing } from '@/theme/tokens'
import { computeStreaks, pktToday } from '@/lib/streaks'
import type { MatchResultsRow, ProfileStatsRow, TournamentsRow } from '@/lib/database.types'

const { width: screenWidth } = Dimensions.get('window')

const VALID_TYPES: ShareCardType[] = ['result', 'win', 'prize', 'streak', 'spin', 'referral', 'profile']

export default function ShareScreen() {
  const router = useRouter()
  const params = useLocalSearchParams<{ type?: string; tournamentId?: string; coins?: string }>()
  const { profile } = useAuth()
  const cardRef = useRef<ViewShotRef>(null)

  const type = VALID_TYPES.includes(params.type as ShareCardType) ? (params.type as ShareCardType) : 'profile'
  const [data, setData] = useState<ShareCardData | null>(null)
  const [sharing, setSharing] = useState(false)
  const [shareError, setShareError] = useState<string | null>(null)
  const [referralConfirmed, setReferralConfirmed] = useState(type !== 'referral')
  // Profile + referral cards are square (1:1) by design; the rest are 9:16.
  const [format, setFormat] = useState<'story' | 'square'>(() => defaultCardFormat(type))

  const cardWidth = Math.min(screenWidth - spacing.lg * 2, 400)

  const load = useCallback(async () => {
    if (!profile) return
    const base: ShareCardData = {
      type,
      displayName: profile.display_name,
      appUid: profile.app_uid,
      date: new Date().toISOString(),
    }

    if (type === 'referral') {
      setData({ ...base, referralCode: profile.referral_code })
      return
    }

    if (type === 'profile') {
      const s = await supabase.from('profile_stats').select('*').eq('profile_id', profile.id).maybeSingle()
      const stats = (s.data as ProfileStatsRow | null) ?? null
      setData({
        ...base,
        stats: {
          joined: stats?.tournaments_joined ?? 0,
          wins: stats?.wins ?? 0,
          kills: stats?.total_kills ?? 0,
        },
      })
      return
    }

    if (type === 'streak') {
      const d = await supabase.from('streak_days').select('day, intensity').eq('profile_id', profile.id)
      const days = (d.data as { day: string; intensity?: number }[] | null) ?? []
      setData({ ...base, streakDays: computeStreaks(days, pktToday()).current })
      return
    }

    if (type === 'spin') {
      setData({ ...base, coinsWon: Number(params.coins ?? 0) })
      return
    }

    // result / win / prize — need tournament + match result
    const tournamentId = params.tournamentId
    if (!tournamentId) {
      setData(base)
      return
    }
    const [t, r] = await Promise.all([
      supabase.from('tournaments').select('*').eq('id', tournamentId).maybeSingle(),
      supabase
        .from('match_results')
        .select('*')
        .eq('tournament_id', tournamentId)
        .eq('profile_id', profile.id)
        .maybeSingle(),
    ])
    const tournament = (t.data as TournamentsRow | null) ?? null
    const result = (r.data as MatchResultsRow | null) ?? null
    const effective =
      type === 'win' ? 'win' : result?.placement && result.placement <= 3 ? 'win' : 'result'
    setData({
      ...base,
      type: effective,
      tournamentTitle: tournament?.title,
      placement: result?.placement ?? null,
      kills: result?.kills ?? 0,
      prizeCoins: result?.prize_coins ?? 0,
    })
  }, [profile, type, params.coins, params.tournamentId])

  useEffect(() => {
    void load()
  }, [load])

  const canShare = referralConfirmed && data !== null

  const onShare = async () => {
    if (!canShare) return
    setSharing(true)
    setShareError(null)
    const error = await shareCardImage(cardRef.current)
    if (error) {
      setShareError(error)
    } else {
      recordShareEvent(type)
    }
    setSharing(false)
  }

  const isStory = format === 'story'
  const displayHeight = isStory ? cardWidth * (16 / 9) : cardWidth

  return (
    <Screen edges={['top']} padded={false}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.head}>
          <ScreenHeader title="Share card" />
        </View>

        <View style={styles.formatRow}>
          {(['story', 'square'] as const).map((f) => {
            const active = f === format
            return (
              <Pressable
                key={f}
                onPress={() => setFormat(f)}
                style={[styles.formatBtn, active ? styles.formatActive : null]}
              >
                <Text variant="label" color={active ? colors.onAction : colors.textSecondary}>
                  {f === 'story' ? '9:16' : '1:1'}
                </Text>
              </Pressable>
            )
          })}
        </View>

        <View style={styles.previewWrap}>
          {data ? (
            <ViewShot
              ref={cardRef}
              style={{ width: cardWidth, height: displayHeight, borderRadius: 20 }}
              options={{ format: 'png', quality: 1, result: 'tmpfile' }}
            >
              <ShareCard data={{ ...data, type }} width={cardWidth} height={displayHeight} />
            </ViewShot>
          ) : (
            <Skeleton height={displayHeight} radius={radii.card} />
          )}
        </View>

        {type === 'referral' ? (
          <Pressable style={styles.confirm} onPress={() => setReferralConfirmed((c) => !c)}>
            <View style={[styles.check, referralConfirmed ? styles.checkOn : null]}>
              {referralConfirmed ? <Text variant="title">✓</Text> : null}
            </View>
            <Text variant="body" color={colors.textSecondary} style={{ flex: 1 }}>
              My referral code will be visible on this card.
            </Text>
          </Pressable>
        ) : null}

        {shareError ? (
          <Text variant="caption" color={colors.accent} style={styles.error}>
            ⚠ {shareError}
          </Text>
        ) : null}

        <Button
          label="Share"
          icon={<Ionicons name="share-outline" size={18} color={colors.onAction} />}
          onPress={() => void onShare()}
          loading={sharing}
          disabled={!canShare}
          style={styles.shareBtn}
        />
        <Text variant="caption" color={colors.textDisabled} style={styles.note}>
          Cards never include room details, your phone number, Free Fire UID, or balance.
        </Text>
      </ScrollView>
    </Screen>
  )
}

const styles = StyleSheet.create({
  scroll: { padding: spacing.lg, paddingBottom: spacing.xxxl, alignItems: 'center' },
  head: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, alignSelf: 'stretch', marginBottom: spacing.lg },
  formatRow: { flexDirection: 'row', gap: spacing.sm, alignSelf: 'flex-start', marginBottom: spacing.lg },
  formatBtn: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radii.badge,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
  },
  formatActive: { backgroundColor: colors.action, borderColor: colors.action },
  previewWrap: { alignItems: 'center' },
  confirm: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginTop: spacing.lg, alignSelf: 'stretch' },
  check: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: colors.strokeStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkOn: { backgroundColor: colors.action, borderColor: colors.action },
  error: { marginTop: spacing.md, alignSelf: 'center' },
  shareBtn: { marginTop: spacing.lg, alignSelf: 'stretch' },
  note: { marginTop: spacing.md, textAlign: 'center' },
})
