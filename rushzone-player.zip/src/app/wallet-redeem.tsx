import { useState } from 'react'
import { StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { LottieIcon } from '@/components/ui/LottieIcon'
import { callEdge } from '@/lib/api'
import { colors, spacing } from '@/theme/tokens'
import { formatCoins } from '@/lib/format'

interface RedeemResult {
  credited_coins?: number
  balance?: number
}

export default function RedeemScreen() {
  const [code, setCode] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<RedeemResult | null>(null)

  const submit = async () => {
    setError(null)
    setResult(null)
    if (!/^[0-9]{6}$/.test(code.trim())) {
      setError('Enter the 6-digit code from your receipt or top-up.')
      return
    }
    setLoading(true)
    const res = await callEdge<RedeemResult>('topup-codes-redeem', { code: code.trim() })
    setLoading(false)
    if (res.error) {
      setError(res.error.message)
      return
    }
    setResult(res.data ?? {})
    setCode('')
  }

  return (
    <Screen scroll edges={['top', 'bottom']}>
      <View style={styles.head}>
        <ScreenHeader title="Redeem code" />
      </View>
      <View style={styles.hero}>
        <LottieIcon name="wallet" size={140} />
      </View>
      <Text variant="body" color={colors.textSecondary} style={styles.sub}>
        Enter the one-time 6-digit code from an admin-issued top-up. Codes credit instantly and
        can only be used once.
      </Text>

      <Card style={styles.card}>
        <Input
          label="Top-up code"
          value={code}
          onChangeText={(v) => setCode(v.replace(/\D/g, '').slice(0, 6))}
          keyboardType="number-pad"
          maxLength={6}
          placeholder="••••••"
          style={styles.codeInput}
          error={error}
        />
        <Button label="Redeem" onPress={submit} loading={loading} icon={<Ionicons name="gift" size={18} color={colors.onAction} />} />
      </Card>

      {result ? (
        <Card style={styles.success}>
          <Ionicons name="checkmark-circle" size={36} color={colors.text} />
          <Text variant="display" color={colors.emphasis}>
            +{formatCoins(result.credited_coins ?? 0)} coins
          </Text>
          <Text variant="body" color={colors.textSecondary}>
            Credited to your wallet. New balance: {formatCoins(result.balance ?? 0)} coins.
          </Text>
        </Card>
      ) : null}
    </Screen>
  )
}

const styles = StyleSheet.create({
  head: { marginBottom: spacing.lg },
  hero: { alignItems: 'center', marginTop: spacing.lg },
  sub: { marginTop: spacing.xs },
  card: { marginTop: spacing.lg, gap: spacing.lg },
  codeInput: { fontSize: 24, letterSpacing: 10, textAlign: 'center' },
  success: { marginTop: spacing.xl, alignItems: 'center', gap: spacing.sm, borderColor: colors.strokeStrong },
})
