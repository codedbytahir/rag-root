import { useCallback, useEffect, useMemo, useState } from 'react'
import { SectionList, StyleSheet, View } from 'react-native'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Skeleton } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { TournamentCard } from '@/components/tournaments/TournamentCard'
import { FolderRow } from '@/components/tournaments/FolderRow'
import { buildCategoryFolders, findCategory, modeMatchesFilter } from '@/lib/tournamentCategories'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing } from '@/theme/tokens'
import { BROWSEABLE_STATUSES, groupTournamentSections, prettyMap, prettyMode } from '@/lib/tournaments'
import type { TournamentsRow } from '@/lib/database.types'

interface Subfolder {
  key: string
  title: string
  subtitle: string
  count: number
  href: string
  icon: 'map-outline' | 'folder-outline'
}

export default function BrowseModeScreen() {
  const router = useRouter()
  const { mode } = useLocalSearchParams<{ mode: string }>()
  const modeKey = (mode ?? 'all').toLowerCase()
  const isAll = modeKey === 'all'

  const [all, setAll] = useState<TournamentsRow[] | null>(null)

  const load = useCallback(async () => {
    const res = await supabase
      .from('tournaments')
      .select('*')
      .in('status', BROWSEABLE_STATUSES)
      .order('match_start_at')
      .limit(100)
    setAll((res.data as TournamentsRow[] | null) ?? [])
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const scoped = useMemo(() => {
    if (!all) return null
    if (isAll) return all
    return all.filter((t) => modeMatchesFilter(t.mode, modeKey))
  }, [all, isAll, modeKey])

  const sections = useMemo(() => (scoped ? groupTournamentSections(scoped) : null), [scoped])

  const subfolders = useMemo<Subfolder[] | null>(() => {
    if (!scoped) return null
    if (isAll) {
      // Inside "All": subfolders are the categories, then the full list below.
      return buildCategoryFolders(scoped).map((f) => ({
        key: `mode:${f.key}`,
        title: f.label,
        subtitle: `${f.count} ${f.count === 1 ? 'tournament' : 'tournaments'}`,
        count: f.count,
        href: `/tournament/browse/${encodeURIComponent(f.key)}`,
        icon: 'folder-outline' as const,
      }))
    }
    // Inside a mode: subfolders are the maps (only when there's more than one).
    const mapTitles = scoped.map((t) => t.map).filter((m): m is string => Boolean(m))
    const distinct = [...new Set(mapTitles.map((m) => m.toLowerCase()))]
    if (distinct.length < 2) return []
    return distinct
      .map((lower) => {
        const original = mapTitles.find((m) => m.toLowerCase() === lower) ?? lower
        const count = mapTitles.filter((m) => m.toLowerCase() === lower).length
        return {
          key: `map:${lower}`,
          title: prettyMap(original),
          subtitle: `${count} ${count === 1 ? 'tournament' : 'tournaments'}`,
          count,
          href: `/tournament/browse/${encodeURIComponent(modeKey)}/${encodeURIComponent(original)}`,
          icon: 'map-outline' as const,
        }
      })
      .sort((a, b) => a.title.localeCompare(b.title))
  }, [scoped, isAll, modeKey])

  const title = isAll ? 'All Tournaments' : (findCategory(modeKey)?.label ?? prettyMode(modeKey))

  return (
    <Screen edges={['top']} padded={false}>
      {!scoped ? (
        <View style={styles.list}>
          <View style={styles.head}>
            <ScreenHeader title={title} />
          </View>
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} height={200} radius={radii.card} style={styles.skeleton} />
          ))}
        </View>
      ) : (
        <SectionList
          sections={(sections ?? []).map((s) => ({ key: s.key, title: s.title, data: s.tournaments }))}
          keyExtractor={(t) => t.id}
          contentContainerStyle={styles.list}
          stickySectionHeadersEnabled={false}
          ListHeaderComponent={
            <View style={styles.head}>
              <ScreenHeader title={title} />
              {subfolders && subfolders.length > 0 ? (
                <View style={styles.folders}>
                  {subfolders.map((f) => (
                    <FolderRow
                      key={f.key}
                      icon={f.icon}
                      title={f.title}
                      subtitle={f.subtitle}
                      count={f.count}
                      onPress={() => router.push(f.href)}
                    />
                  ))}
                </View>
              ) : null}
            </View>
          }
          renderItem={({ item }) => (
            <TournamentCard tournament={item} onPress={() => router.push(`/tournament/${item.id}`)} />
          )}
          renderSectionHeader={({ section }) => (
            <Text variant="heading" style={styles.sectionTitle}>
              {section.title}
            </Text>
          )}
          ListEmptyComponent={
            <EmptyState title="Nothing here yet" body="No tournaments in this folder right now." />
          }
        />
      )}
    </Screen>
  )
}

const styles = StyleSheet.create({
  list: { padding: spacing.lg, paddingBottom: spacing.xxxl, flexGrow: 1 },
  head: { gap: spacing.lg, marginBottom: spacing.md },
  folders: { gap: 0 },
  sectionTitle: { marginTop: spacing.lg, marginBottom: spacing.md },
  skeleton: { marginBottom: spacing.lg },
})
