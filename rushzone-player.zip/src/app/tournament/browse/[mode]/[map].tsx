import { useCallback, useEffect, useMemo, useState } from 'react'
import { SectionList, StyleSheet, View } from 'react-native'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Skeleton } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { TournamentCard } from '@/components/tournaments/TournamentCard'
import { modeMatchesFilter } from '@/lib/tournamentCategories'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing } from '@/theme/tokens'
import { BROWSEABLE_STATUSES, groupTournamentSections, prettyMap, prettyMode } from '@/lib/tournaments'
import type { TournamentsRow } from '@/lib/database.types'

export default function BrowseMapScreen() {
  const router = useRouter()
  const { mode, map } = useLocalSearchParams<{ mode: string; map: string }>()
  const modeKey = (mode ?? '').toLowerCase()
  const mapKey = (map ?? '').toLowerCase()

  const [all, setAll] = useState<TournamentsRow[] | null>(null)

  const load = useCallback(async () => {
    const res = await supabase
      .from('tournaments')
      .select('*')
      .in('status', BROWSEABLE_STATUSES)
      .order('match_start_at')
      .limit(100)
    setAll((res.data as TournamentsRow[] | null) ?? [])
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const scoped = useMemo(() => {
    if (!all) return null
    return all.filter(
      (t) => modeMatchesFilter(t.mode, modeKey) && (t.map ?? '').toLowerCase() === mapKey,
    )
  }, [all, modeKey, mapKey])

  const sections = useMemo(() => (scoped ? groupTournamentSections(scoped) : null), [scoped])

  const title = `${prettyMode(modeKey)} · ${prettyMap(mapKey)}`

  return (
    <Screen edges={['top']} padded={false}>
      {!scoped ? (
        <View style={styles.list}>
          <View style={styles.head}>
            <ScreenHeader title={title} />
          </View>
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} height={200} radius={radii.card} style={styles.skeleton} />
          ))}
        </View>
      ) : (
        <SectionList
          sections={(sections ?? []).map((s) => ({ key: s.key, title: s.title, data: s.tournaments }))}
          keyExtractor={(t) => t.id}
          contentContainerStyle={styles.list}
          stickySectionHeadersEnabled={false}
          ListHeaderComponent={
            <View style={styles.head}>
              <ScreenHeader title={title} />
              <Text variant="body" color={colors.textSecondary}>
                {scoped.length} {scoped.length === 1 ? 'tournament' : 'tournaments'} on this map.
              </Text>
            </View>
          }
          renderItem={({ item }) => (
            <TournamentCard tournament={item} onPress={() => router.push(`/tournament/${item.id}`)} />
          )}
          renderSectionHeader={({ section }) => (
            <Text variant="heading" style={styles.sectionTitle}>
              {section.title}
            </Text>
          )}
          ListEmptyComponent={
            <EmptyState title="Nothing here yet" body="No tournaments in this folder right now." />
          }
        />
      )}
    </Screen>
  )
}

const styles = StyleSheet.create({
  list: { padding: spacing.lg, paddingBottom: spacing.xxxl, flexGrow: 1 },
  head: { gap: spacing.lg, marginBottom: spacing.md },
  sectionTitle: { marginTop: spacing.lg, marginBottom: spacing.md },
  skeleton: { marginBottom: spacing.lg },
})
