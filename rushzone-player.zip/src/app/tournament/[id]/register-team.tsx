import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Pressable, ScrollView, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { StatusChip } from '@/components/ui/StatusChip'
import { Skeleton } from '@/components/ui/Skeleton'
import { useAuth } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import { callEdge } from '@/lib/api'
import { colors, radii, spacing } from '@/theme/tokens'
import { formatCoins } from '@/lib/format'
import { publicStorageUrl } from '@/lib/storage'
import { prettyMap, prettyMode } from '@/lib/tournaments'
import { teamSizeForMode } from '@/lib/tournamentCategories'
import type { TournamentsRow, WalletAccountsRow } from '@/lib/database.types'

interface Member {
  id: string
  display_name: string
  ff_uid: string
  in_game_name: string
}

export default function RegisterTeamScreen() {
  const { id } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { profile } = useAuth()

  const [tournament, setTournament] = useState<TournamentsRow | null>(null)
  const [wallet, setWallet] = useState<WalletAccountsRow | null>(null)
  const [notFound, setNotFound] = useState(false)

  const [teamName, setTeamName] = useState('')
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Member[] | null>(null)
  const [selected, setSelected] = useState<Member[]>([])
  const [searching, setSearching] = useState(false)

  const [policyChecked, setPolicyChecked] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [done, setDone] = useState(false)

  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const load = useCallback(async () => {
    if (!id) return
    const res = await supabase.from('tournaments').select('*').eq('id', id).maybeSingle()
    if (!res.data) {
      setNotFound(true)
      return
    }
    setTournament(res.data as TournamentsRow)
    if (profile?.id) {
      const walletRes = await supabase.from('wallet_accounts').select('*').eq('profile_id', profile.id).maybeSingle()
      setWallet((walletRes.data as WalletAccountsRow | null) ?? null)
    }
  }, [id, profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  // Debounced teammate search (by FF UID, in-game name, or display name).
  useEffect(() => {
    if (searchTimer.current) clearTimeout(searchTimer.current)
    const q = query.trim()
    if (q.length < 2) {
      setResults(null)
      return
    }
    searchTimer.current = setTimeout(() => {
      setSearching(true)
      void (async () => {
        const or = `ff_uid.ilike.%${q}%,in_game_name.ilike.%${q}%,display_name.ilike.%${q}%`
        const res = await supabase
          .from('profiles')
          .select('id, display_name, ff_uid, in_game_name')
          .or(or)
          .limit(10)
        setResults((res.data as Member[] | null) ?? [])
        setSearching(false)
      })()
    }, 350)
    return () => {
      if (searchTimer.current) clearTimeout(searchTimer.current)
    }
  }, [query])

  const teamSize = useMemo(() => (tournament ? teamSizeForMode(tournament.mode) : 1), [tournament])
  const memberCount = 1 + selected.length // leader + teammates
  const feePerPlayer = tournament?.entry_fee ?? 0
  const totalFee = feePerPlayer * memberCount
  const available = wallet?.available_balance ?? 0
  const afterBalance = available - totalFee

  const canAdd = memberCount < teamSize
  const chosenIds = useMemo(() => new Set(selected.map((m) => m.id)), [selected])

  const addMember = (m: Member) => {
    if (!canAdd) return
    setSelected((prev) => [...prev, m])
    setResults(null)
    setQuery('')
  }

  const removeMember = (memberId: string) => {
    setSelected((prev) => prev.filter((m) => m.id !== memberId))
  }

  const onSubmit = async () => {
    if (!tournament || !profile?.id) return
    setError(null)
    if (teamName.trim().length < 2) {
      setError('Enter a team name (at least 2 characters).')
      return
    }
    if (selected.length < 1) {
      setError('Add at least one teammate — the leader plus one other player.')
      return
    }
    if (!policyChecked) {
      setError('Accept the tournament rules to continue.')
      return
    }
    if (afterBalance < 0) {
      setError('You do not have enough coins to cover the team entry fees.')
      return
    }
    setSubmitting(true)
    const res = await callEdge<{ roster_id?: string }>('tournaments-team-register', {
      tournament_id: tournament.id,
      profile_id: profile.id,
      team_name: teamName.trim(),
      members: [profile.id, ...selected.map((m) => m.id)],
    })
    setSubmitting(false)
    if (res.error) {
      setError(res.error.message)
      return
    }
    setDone(true)
  }

  if (notFound) {
    return (
      <Screen edges={['top']}>
        <View style={styles.head}>
          <ScreenHeader title="Register team" />
        </View>
      </Screen>
    )
  }

  return (
    <Screen edges={['top']} padded={false}>
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <View style={styles.head}>
          <ScreenHeader title="Register team" />
        </View>

        {!tournament ? (
          <Skeleton height={140} radius={radii.card} />
        ) : (
          <>
            <Card>
              <StatusChip tone="success" label="Open" />
              <Text variant="title" style={styles.cardTitle}>
                {tournament.title}
              </Text>
              <Text variant="caption" color={colors.textSecondary}>
                {[prettyMode(tournament.mode), prettyMap(tournament.map), `${teamSize} players per team`]
                  .filter(Boolean)
                  .join(' · ')}
              </Text>
              <View style={styles.costRows}>
                <CostRow label="Entry fee (per player)" value={feePerPlayer > 0 ? `${formatCoins(feePerPlayer)} coins` : 'Free'} />
                <CostRow label="Team size" value={`${teamSize} players`} />
              </View>
            </Card>

            {done ? (
              <Card style={styles.doneCard}>
                <StatusChip tone="success" label="Team registered" />
                <Text variant="body" color={colors.textSecondary} style={styles.doneBody}>
                  Team “{teamName.trim()}” is in ({memberCount} players). The team leader pays the
                  entry fees and receives the prize. Check My Tournaments for updates.
                </Text>
                <Button label="Done" onPress={() => router.replace(`/tournament/${tournament.id}`)} />
              </Card>
            ) : (
              <>
                <Input
                  label="Team name"
                  value={teamName}
                  onChangeText={setTeamName}
                  placeholder="e.g. Night Owls"
                  autoCapitalize="words"
                  maxLength={40}
                />

                <View style={styles.section}>
                  <Text variant="heading">Members</Text>

                  <Card style={styles.memberRow}>
                    <View style={styles.leaderBadge}>
                      <Text variant="micro" color={colors.onAction}>
                        LEADER
                      </Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text variant="body">{profile?.display_name ?? 'You'}</Text>
                      <Text variant="caption" color={colors.textDisabled}>
                        FF UID {profile?.ff_uid ?? '—'} · pays the fees · receives the prize
                      </Text>
                    </View>
                  </Card>

                  {selected.map((m) => (
                    <Card key={m.id} style={styles.memberRow}>
                      <View style={styles.memberIcon}>
                        <Ionicons name="person-outline" size={18} color={colors.text} />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text variant="body">{m.display_name}</Text>
                        <Text variant="caption" color={colors.textDisabled}>
                          {m.in_game_name} · FF UID {m.ff_uid}
                        </Text>
                      </View>
                      <Pressable onPress={() => removeMember(m.id)} hitSlop={8} accessibilityLabel="Remove member">
                        <Ionicons name="close-circle" size={22} color={colors.textSecondary} />
                      </Pressable>
                    </Card>
                  ))}

                  {canAdd ? (
                    <>
                      <Text variant="caption" color={colors.textDisabled} style={styles.addHint}>
                        Add up to {teamSize - 1} more {teamSize - 1 === 1 ? 'teammate' : 'teammates'} — search by
                        FF UID, in-game name, or display name.
                      </Text>
                      <Input
                        label="Find teammates"
                        value={query}
                        onChangeText={setQuery}
                        placeholder="Search players…"
                        autoCapitalize="none"
                        autoCorrect={false}
                        helper={searching ? 'Searching…' : null}
                      />
                      {results && results.length === 0 ? (
                        <Text variant="caption" color={colors.textDisabled} style={styles.noResults}>
                          No players found. Teammates need a Rush Zone account.
                        </Text>
                      ) : null}
                      {results?.map((m) => (
                        <Pressable
                          key={m.id}
                          style={[styles.result, chosenIds.has(m.id) ? styles.resultDisabled : null]}
                          disabled={chosenIds.has(m.id)}
                          onPress={() => addMember(m)}
                        >
                          <View style={{ flex: 1 }}>
                            <Text variant="body">{m.display_name}</Text>
                            <Text variant="caption" color={colors.textDisabled}>
                              {m.in_game_name} · FF UID {m.ff_uid}
                            </Text>
                          </View>
                          <Ionicons
                            name={chosenIds.has(m.id) ? 'checkmark-circle' : 'add-circle-outline'}
                            size={22}
                            color={chosenIds.has(m.id) ? colors.textDisabled : colors.text}
                          />
                        </Pressable>
                      ))}
                    </>
                  ) : (
                    <Text variant="caption" color={colors.textDisabled} style={styles.addHint}>
                      Team full — {teamSize} players.
                    </Text>
                  )}
                </View>

                <Card>
                  <View style={styles.costRows}>
                    <CostRow label="Players" value={`${memberCount} of ${teamSize}`} />
                    <CostRow label="Total entry fees" value={totalFee > 0 ? `${formatCoins(totalFee)} coins` : 'Free'} />
                    <CostRow label="Your balance" value={`${formatCoins(available)} coins`} />
                    <CostRow label="Balance after" value={`${formatCoins(Math.max(0, afterBalance))} coins`} />
                  </View>
                  {afterBalance < 0 ? (
                    <Text variant="caption" color={colors.textSecondary}>
                      ⚠ You do not have enough coins for the full team. Top up your wallet first.
                    </Text>
                  ) : null}
                </Card>

                <Pressable style={styles.policyRow} onPress={() => setPolicyChecked((c) => !c)}>
                  <View style={[styles.check, policyChecked ? styles.checkOn : null]}>
                    {policyChecked ? <Text variant="title">✓</Text> : null}
                  </View>
                  <Text variant="caption" color={colors.textSecondary} style={{ flex: 1 }}>
                    I agree to the tournament rules and cancellation policy. Entry fees for all members
                    are paid by the team leader, and the prize goes to the leader.
                  </Text>
                </Pressable>

                {error ? (
                  <Text variant="caption" color={colors.textSecondary}>
                    ⚠ {error}
                  </Text>
                ) : null}

                <Button
                  label={`Register team · ${totalFee > 0 ? `${formatCoins(totalFee)} coins` : 'Free'}`}
                  onPress={onSubmit}
                  loading={submitting}
                  disabled={memberCount < 2 || afterBalance < 0}
                  size="lg"
                />
              </>
            )}
          </>
        )}
      </ScrollView>
    </Screen>
  )
}

function CostRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.costRow}>
      <Text variant="body" color={colors.textSecondary}>
        {label}
      </Text>
      <Text variant="money" color={colors.text}>
        {value}
      </Text>
    </View>
  )
}

const styles = StyleSheet.create({
  scroll: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  head: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.lg },
  cardTitle: { marginTop: spacing.sm },
  section: { marginTop: spacing.xxl, gap: spacing.md },
  memberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.sm,
  },
  leaderBadge: {
    backgroundColor: colors.action,
    borderRadius: radii.badge,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
  },
  memberIcon: {
    width: 34,
    height: 34,
    borderRadius: radii.badge,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addHint: { marginTop: spacing.xs },
  result: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radii.input,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    marginBottom: spacing.xs,
  },
  resultDisabled: { opacity: 0.45 },
  noResults: { marginTop: spacing.xs },
  costRows: { gap: spacing.md },
  costRow: { flexDirection: 'row', justifyContent: 'space-between' },
  policyRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginTop: spacing.md },
  check: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: colors.strokeStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkOn: { backgroundColor: colors.action, borderColor: colors.action },
  doneCard: { gap: spacing.md, marginTop: spacing.md },
  doneBody: { lineHeight: 20 },
})
