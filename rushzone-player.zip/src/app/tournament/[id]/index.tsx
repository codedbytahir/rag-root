import { useCallback, useEffect, useState } from 'react'
import { Modal, Pressable, ScrollView, StyleSheet, View } from 'react-native'
import { Image } from 'expo-image'
import { Ionicons } from '@expo/vector-icons'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { StatusChip } from '@/components/ui/StatusChip'
import { EmptyState } from '@/components/ui/EmptyState'
import { Skeleton } from '@/components/ui/Skeleton'
import { useAuth } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import { callEdge } from '@/lib/api'
import { colors, radii, spacing } from '@/theme/tokens'
import { formatCoins, formatPKTDateTime } from '@/lib/format'
import { publicStorageUrl } from '@/lib/storage'
import { canRegister, statusMeta } from '@/lib/tournaments'
import { isTeamTournament, teamSizeForMode } from '@/lib/tournamentCategories'
import type { RegistrationsRow, TournamentsRow, WalletAccountsRow } from '@/lib/database.types'

export default function TournamentDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { profile } = useAuth()

  const [tournament, setTournament] = useState<TournamentsRow | null>(null)
  const [registration, setRegistration] = useState<RegistrationsRow | null>(null)
  const [rosterName, setRosterName] = useState<string | null>(null)
  const [wallet, setWallet] = useState<WalletAccountsRow | null>(null)
  const [notFound, setNotFound] = useState(false)

  const [joinOpen, setJoinOpen] = useState(false)
  const [policyChecked, setPolicyChecked] = useState(false)
  const [joining, setJoining] = useState(false)
  const [joinError, setJoinError] = useState<string | null>(null)
  const [joined, setJoined] = useState(false)

  const load = useCallback(async () => {
    if (!id) return
    const res = await supabase.from('tournaments').select('*').eq('id', id).maybeSingle()
    if (!res.data) {
      setNotFound(true)
      return
    }
    setTournament(res.data as TournamentsRow)
    if (profile?.id) {
      const [regRes, walletRes] = await Promise.all([
        supabase.from('registrations').select('*').eq('tournament_id', id).eq('profile_id', profile.id).maybeSingle(),
        supabase.from('wallet_accounts').select('*').eq('profile_id', profile.id).maybeSingle(),
      ])
      const reg = (regRes.data as RegistrationsRow | null) ?? null
      setRegistration(reg)
      setWallet((walletRes.data as WalletAccountsRow | null) ?? null)
      if (reg?.roster_id) {
        const rosterRes = await supabase.from('rosters').select('label').eq('id', reg.roster_id).maybeSingle()
        setRosterName((rosterRes.data as { label?: string } | null)?.label ?? null)
      } else {
        setRosterName(null)
      }
    }
  }, [id, profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  const onJoin = async () => {
    if (!tournament || !policyChecked) return
    setJoining(true)
    setJoinError(null)
    const res = await callEdge<{ registration_id?: string }>('tournaments-register', {
      tournament_id: tournament.id,
    })
    setJoining(false)
    if (res.error) {
      setJoinError(res.error.message)
      return
    }
    setJoined(true)
    setJoinOpen(false)
    await load()
  }

  if (notFound) {
    return (
      <Screen edges={['top']}>
        <EmptyState title="Tournament not found" actionLabel="Go back" onAction={() => router.back()} />
      </Screen>
    )
  }

  const meta = tournament ? statusMeta(tournament.status) : null
  const cover = tournament ? publicStorageUrl('tournament-thumbnails', tournament.cover_path) : null
  const available = wallet?.available_balance ?? 0
  const canJoin = tournament ? canRegister(tournament.status) && !registration && !joined : false
  const afterBalance = tournament ? available - tournament.entry_fee : 0
  const teamSize = tournament ? teamSizeForMode(tournament.mode) : 1
  const teamMode = tournament ? isTeamTournament(tournament.mode) : false

  return (
    <Screen edges={['top']} padded={false}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <Pressable style={styles.back} onPress={() => router.back()} hitSlop={8}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </Pressable>

        {tournament ? (
          <>
            {cover ? (
              <Image source={{ uri: cover }} style={styles.cover} contentFit="cover" transition={200} />
            ) : (
              <View style={[styles.cover, styles.coverFallback]}>
                <Text variant="display" color={colors.textDisabled}>
                  RZ
                </Text>
              </View>
            )}

            <View style={styles.body}>
              {meta ? <StatusChip tone={meta.tone} label={meta.label} /> : null}
              <Text variant="display">{tournament.title}</Text>
              <Text variant="body" color={colors.textSecondary}>
                {[tournament.mode, tournament.map, `${tournament.rounds} round(s)`].filter(Boolean).join(' · ')}
              </Text>

              <View style={styles.facts}>
                <Fact label="Match starts" value={tournament.match_start_at ? formatPKTDateTime(tournament.match_start_at) : 'TBA'} />
                <Fact label="Registration closes" value={tournament.reg_close_at ? formatPKTDateTime(tournament.reg_close_at) : '—'} />
                <Fact label="Entry fee" value={tournament.entry_fee > 0 ? `${formatCoins(tournament.entry_fee)} coins (PKR ${formatCoins(tournament.entry_fee)})` : 'Free entry'} />
                <Fact label="Prize pool" value={`${formatCoins(tournament.prize_pool)} coins`} />
                <Fact label="Capacity" value={`${tournament.capacity} seats`} />
                {teamMode ? <Fact label="Team size" value={`${teamSize} players`} /> : null}
              </View>

              {tournament.prize_distribution && hasContent(tournament.prize_distribution) ? (
                <Section title="Prize distribution">
                  <JsonLines value={tournament.prize_distribution} />
                </Section>
              ) : null}

              {tournament.score_rules && hasContent(tournament.score_rules) ? (
                <Section title="Score rules">
                  <JsonLines value={tournament.score_rules} />
                </Section>
              ) : null}

              {tournament.rules_text ? (
                <Section title="Rules & cancellations">
                  <Text variant="body" color={colors.textSecondary}>
                    {tournament.rules_text}
                  </Text>
                </Section>
              ) : null}

              <Card style={styles.individual}>
                <Ionicons name={teamMode ? 'people-outline' : 'person-outline'} size={20} color={colors.textSecondary} />
                <Text variant="caption" color={colors.textSecondary} style={{ flex: 1 }}>
                  {teamMode
                    ? `Team entry — one leader registers the whole team (${teamSize} players). The team leader pays the entry fees and receives the prize.`
                    : 'Individual entry — one account per event. Room details are delivered after release.'}
                </Text>
              </Card>

              {registration ? (
                <Card>
                  <StatusChip tone="success" label={rosterName ? 'Team registered' : 'Registered'} />
                  <Text variant="caption" color={colors.textSecondary} style={styles.registered}>
                    {rosterName ? `Team “${rosterName}” · ` : ''}Slot #{registration.slot_number ?? '—'} · Room details appear here once released.
                  </Text>
                </Card>
              ) : null}

              {joined ? (
                <Card>
                  <StatusChip tone="success" label="Registration complete" />
                  <Text variant="caption" color={colors.textSecondary} style={styles.registered}>
                    You&apos;re in. Check My Tournaments for updates.
                  </Text>
                </Card>
              ) : null}

              {canJoin ? (
                teamMode ? (
                  <Button
                    label={`Register team · ${tournament.entry_fee > 0 ? `${formatCoins(tournament.entry_fee)} coins / player` : 'Free'}`}
                    onPress={() => router.push(`/tournament/${tournament.id}/register-team`)}
                    size="lg"
                  />
                ) : (
                  <Button label={`Join · ${tournament.entry_fee > 0 ? `${formatCoins(tournament.entry_fee)} coins` : 'Free'}`} onPress={() => setJoinOpen(true)} size="lg" />
                )
              ) : registration || joined ? null : (
                <Button label="Unavailable" variant="secondary" disabled />
              )}
            </View>
          </>
        ) : (
          <>
            <Skeleton height={220} radius={0} />
            <View style={styles.body}>
              <Skeleton height={32} width="70%" />
              <Skeleton height={18} width="80%" />
              <View style={styles.facts}>
                {[0, 1, 2, 3, 4].map((i) => (
                  <Skeleton key={i} height={64} radius={radii.input} style={styles.fact} />
                ))}
              </View>
            </View>
          </>
        )}
      </ScrollView>

      {/* Join confirmation modal */}
      <Modal visible={joinOpen} transparent animationType="fade" onRequestClose={() => setJoinOpen(false)}>
        <View style={styles.modalBackdrop}>
          <View style={styles.sheet}>
            <Text variant="heading">Confirm entry</Text>
            {tournament ? (
              <>
                <View style={styles.costRows}>
                  <CostRow label="Current balance" value={`${formatCoins(available)} coins`} />
                  <CostRow label="Entry fee" value={`- ${formatCoins(tournament.entry_fee)} coins`} />
                  <CostRow label="Balance after" value={`${formatCoins(afterBalance)} coins`} />
                </View>
                {afterBalance < 0 ? (
                  <Text variant="caption" color={colors.textSecondary}>
                    ⚠ You do not have enough coins. Top up your wallet first.
                  </Text>
                ) : null}

                <Pressable style={styles.policyRow} onPress={() => setPolicyChecked((c) => !c)}>
                  <View style={[styles.check, policyChecked ? styles.checkOn : null]}>
                    {policyChecked ? <Text variant="title">✓</Text> : null}
                  </View>
                  <Text variant="caption" color={colors.textSecondary} style={{ flex: 1 }}>
                    I agree to the tournament rules and cancellation policy.
                  </Text>
                </Pressable>

                {joinError ? (
                  <Text variant="caption" color={colors.textSecondary}>
                    ⚠ {joinError}
                  </Text>
                ) : null}

                <Button
                  label="Confirm entry"
                  onPress={onJoin}
                  loading={joining}
                  disabled={!policyChecked || afterBalance < 0}
                />
                <Button label="Cancel" variant="ghost" onPress={() => setJoinOpen(false)} />
              </>
            ) : null}
          </View>
        </View>
      </Modal>
    </Screen>
  )
}

function hasContent(v: unknown): boolean {
  if (Array.isArray(v)) return v.length > 0
  if (v && typeof v === 'object') return Object.keys(v).length > 0
  return Boolean(v)
}

function JsonLines({ value }: { value: unknown }) {
  if (Array.isArray(value)) {
    return (
      <View style={styles.jsonList}>
        {value.map((item, i) => (
          <Text key={i} variant="body" color={colors.textSecondary}>
            {typeof item === 'object' ? JSON.stringify(item) : String(item)}
          </Text>
        ))}
      </View>
    )
  }
  if (value && typeof value === 'object') {
    return (
      <View style={styles.jsonList}>
        {Object.entries(value as Record<string, unknown>).map(([k, v]) => (
          <Text key={k} variant="body" color={colors.textSecondary}>
            {k}: {typeof v === 'object' ? JSON.stringify(v) : String(v)}
          </Text>
        ))}
      </View>
    )
  }
  return <Text variant="body" color={colors.textSecondary}>{String(value)}</Text>
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.fact}>
      <Text variant="caption" color={colors.textDisabled}>
        {label}
      </Text>
      <Text variant="body">{value}</Text>
    </View>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text variant="heading">{title}</Text>
      {children}
    </View>
  )
}

function CostRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.costRow}>
      <Text variant="body" color={colors.textSecondary}>
        {label}
      </Text>
      <Text variant="money" color={colors.text}>
        {value}
      </Text>
    </View>
  )
}

const styles = StyleSheet.create({
  scroll: { paddingBottom: spacing.xxxl },
  back: {
    position: 'absolute',
    top: spacing.md,
    left: spacing.md,
    zIndex: 10,
    width: 44,
    height: 44,
    borderRadius: radii.badge,
    backgroundColor: colors.scrim,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cover: { width: '100%', height: 220 },
  coverFallback: { backgroundColor: colors.inset, alignItems: 'center', justifyContent: 'center' },
  body: { padding: spacing.lg, gap: spacing.md },
  facts: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  fact: {
    flexGrow: 1,
    flexBasis: '45%',
    backgroundColor: colors.inset,
    borderRadius: radii.input,
    padding: spacing.md,
    gap: spacing.xs,
  },
  section: { gap: spacing.sm, marginTop: spacing.lg },
  jsonList: { gap: spacing.xs, marginTop: spacing.xs },
  individual: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginTop: spacing.lg },
  registered: { marginTop: spacing.sm },
  modalBackdrop: {
    flex: 1,
    backgroundColor: colors.scrim,
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: colors.surfaceRaised,
    borderTopLeftRadius: radii.card,
    borderTopRightRadius: radii.card,
    borderWidth: 1,
    borderColor: colors.stroke,
    padding: spacing.xl,
    gap: spacing.lg,
  },
  costRows: {
    backgroundColor: colors.inset,
    borderRadius: radii.input,
    padding: spacing.md,
    gap: spacing.md,
  },
  costRow: { flexDirection: 'row', justifyContent: 'space-between' },
  policyRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  check: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: colors.strokeStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkOn: { backgroundColor: colors.action, borderColor: colors.action },
})
