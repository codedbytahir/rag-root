import { useCallback, useEffect, useState } from 'react'
import { Pressable, ScrollView, StyleSheet, View } from 'react-native'
import { useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { StatusChip } from '@/components/ui/StatusChip'
import { Skeleton } from '@/components/ui/Skeleton'
import { useAuth } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import { callEdge } from '@/lib/api'
import { colors, radii, spacing } from '@/theme/tokens'
import { formatCoins, formatPKTDateTime } from '@/lib/format'
import type { TopupRequestsRow } from '@/lib/database.types'

const METHODS = ['easypaisa', 'jazzcash'] as const
const METHOD_LABEL: Record<string, string> = { easypaisa: 'Easypaisa', jazzcash: 'JazzCash' }
const STATUS_TONE: Record<string, 'success' | 'danger' | 'neutral' | 'info'> = {
  pending: 'info',
  approved: 'success',
  rejected: 'danger',
  expired: 'neutral',
}

export default function TopupScreen() {
  const router = useRouter()
  const { profile } = useAuth()
  const [method, setMethod] = useState<(typeof METHODS)[number]>('easypaisa')
  const [amount, setAmount] = useState('')
  const [reference, setReference] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [requests, setRequests] = useState<TopupRequestsRow[] | null>(null)
  const [initialLoading, setInitialLoading] = useState(true)

  const load = useCallback(async () => {
    if (!profile?.id) return
    const res = await supabase
      .from('topup_requests')
      .select('*')
      .eq('profile_id', profile.id)
      .order('created_at', { ascending: false })
      .limit(10)
    setRequests((res.data as TopupRequestsRow[] | null) ?? [])
    setInitialLoading(false)
  }, [profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  const submit = async () => {
    setError(null)
    const coins = Number(amount)
    if (!Number.isInteger(coins) || coins <= 0) {
      setError('Enter a valid whole number of coins.')
      return
    }
    if (!reference.trim() || reference.trim().length < 4) {
      setError('Enter the payment transaction ID / reference.')
      return
    }
    setLoading(true)
    const res = await callEdge('wallet-topup-create', {
      method,
      amount_coins: coins,
      reference: reference.trim(),
    })
    setLoading(false)
    if (res.error) {
      setError(res.error.message)
      return
    }
    setSubmitted(true)
    setAmount('')
    setReference('')
    await load()
  }

  return (
    <Screen scroll edges={['top', 'bottom']}>
      <View style={styles.head}>
        <ScreenHeader title="Buy coins" />
      </View>
      <Text variant="body" color={colors.textSecondary} style={styles.sub}>
        Pay outside the app, then enter your payment details. Coins are credited after staff
        approve the request.
      </Text>

      <Card style={styles.card}>
        <Text variant="label" color={colors.textSecondary}>
          Payment method
        </Text>
        <View style={styles.methods}>
          {METHODS.map((m) => {
            const active = m === method
            return (
              <Pressable
                key={m}
                onPress={() => setMethod(m)}
                style={[styles.method, active ? styles.methodActive : null]}
              >
                <Text variant="label" color={active ? colors.onAction : colors.textSecondary}>
                  {METHOD_LABEL[m]}
                </Text>
              </Pressable>
            )
          })}
        </View>

        <Input
          label="Amount (Rush Coins)"
          value={amount}
          onChangeText={(v) => setAmount(v.replace(/\D/g, ''))}
          keyboardType="number-pad"
          placeholder="500"
          containerStyle={styles.field}
        />
        <Input
          label="Payment transaction ID / reference"
          value={reference}
          onChangeText={setReference}
          placeholder="e.g. TID 8472910"
          autoCapitalize="none"
          autoCorrect={false}
          containerStyle={styles.field}
          helper="No screenshot needed — just the payment ID."
        />

        {error ? (
          <Text variant="caption" color={colors.textSecondary} style={styles.error}>
            ⚠ {error}
          </Text>
        ) : null}
        {submitted ? (
          <Text variant="caption" color={colors.textSecondary} style={styles.error}>
            ✓ Request submitted for review. You'll be notified on approval.
          </Text>
        ) : null}

        <Button label={`Submit ${amount ? formatCoins(Number(amount)) : ''} coin request`} onPress={submit} loading={loading} />
      </Card>

      {initialLoading ? (
        <View style={styles.history}>
          <Skeleton height={24} width="50%" />
          <Skeleton height={96} radius={radii.card} />
          <Skeleton height={96} radius={radii.card} />
        </View>
      ) : requests && requests.length > 0 ? (
        <View style={styles.history}>
          <Text variant="heading">Recent requests</Text>
          {requests.map((r) => (
            <Card key={r.id} style={styles.historyCard}>
              <View style={styles.historyHead}>
                <Text variant="body" style={{ flex: 1 }}>
                  {METHOD_LABEL[r.method] ?? r.method} · {formatCoins(r.amount_coins)} coins
                </Text>
                <StatusChip tone={STATUS_TONE[r.status] ?? 'neutral'} label={r.status.replace('_', ' ')} />
              </View>
              <Text variant="caption" color={colors.textDisabled}>
                {formatPKTDateTime(r.created_at)}
                {r.reject_reason ? ` · ${r.reject_reason}` : ''}
              </Text>
            </Card>
          ))}
        </View>
      ) : null}
    </Screen>
  )
}

const styles = StyleSheet.create({
  head: { marginBottom: spacing.lg },
  sub: { marginTop: spacing.xs },
  card: { marginTop: spacing.lg, gap: spacing.md },
  methods: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.xs },
  method: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radii.button,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
  },
  methodActive: { backgroundColor: colors.action, borderColor: colors.action },
  field: { marginTop: spacing.md },
  error: { marginTop: spacing.xs },
  history: { marginTop: spacing.xxl, gap: spacing.md },
  historyCard: { gap: spacing.xs },
  historyHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: spacing.sm },
})
