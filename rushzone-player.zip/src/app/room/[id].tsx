import { useCallback, useEffect, useState } from 'react'
import { Pressable, ScrollView, StyleSheet, View } from 'react-native'
import * as Clipboard from 'expo-clipboard'
import { Ionicons } from '@expo/vector-icons'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { callEdge } from '@/lib/api'
import { colors, radii, spacing, touchTarget } from '@/theme/tokens'
import { formatPKTDateTime } from '@/lib/format'

interface RoomPayload {
  room_id?: string
  room_password?: string
  server_region?: string | null
  instructions?: string | null
  released_at?: string | null
}

export default function RoomScreen() {
  const { id } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const [room, setRoom] = useState<RoomPayload | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState<string | null>(null)

  const load = useCallback(async () => {
    if (!id) return
    setError(null)
    setRoom(null)
    const res = await callEdge<RoomPayload>('tournaments-room', { tournament_id: id })
    if (res.error) {
      setError(res.error.message)
      return
    }
    setRoom(res.data)
  }, [id])

  useEffect(() => {
    void load()
  }, [load])

  const copy = async (key: string, value: string) => {
    await Clipboard.setStringAsync(value)
    setCopied(key)
    setTimeout(() => setCopied(null), 1600)
  }

  if (error) {
    return (
      <Screen edges={['top']}>
        <EmptyState
          icon="lock-closed"
          title="Room not available"
          body={error}
          actionLabel="Go back"
          onAction={() => router.back()}
        />
      </Screen>
    )
  }

  return (
    <Screen edges={['top']} padded={false}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.head}>
          <ScreenHeader title="Room details" />
        </View>
        <Text variant="caption" color={colors.textSecondary} style={styles.sub}>
          {room?.released_at ? `Released ${formatPKTDateTime(room.released_at)}` : 'Loading…'}
        </Text>

        {room ? (
          <>
            <Card style={styles.creds}>
              <CopyRow
                label="Room ID"
                value={room.room_id ?? '—'}
                copied={copied === 'room'}
                onCopy={() => room.room_id && copy('room', room.room_id)}
              />
              <View style={styles.divider} />
              <CopyRow
                label="Room password"
                value={room.room_password ?? '—'}
                copied={copied === 'password'}
                onCopy={() => room.room_password && copy('password', room.room_password)}
              />
              {room.server_region ? (
                <>
                  <View style={styles.divider} />
                  <Row label="Server / region" value={room.server_region} />
                </>
              ) : null}
            </Card>

            {room.instructions ? (
              <Card style={styles.card}>
                <Text variant="title">Match instructions</Text>
                <Text variant="body" color={colors.textSecondary} style={styles.body}>
                  {room.instructions}
                </Text>
              </Card>
            ) : null}

            <Card style={[styles.card, styles.warning]}>
              <View style={styles.warningRow}>
                <Ionicons name="shield-outline" size={20} color={colors.text} />
                <Text variant="body" color={colors.text} style={{ flex: 1 }}>
                  Never share this room ID or password. Anyone with these details can join your
                  room.
                </Text>
              </View>
            </Card>
          </>
        ) : null}
      </ScrollView>
    </Screen>
  )
}

function CopyRow({ label, value, copied, onCopy }: { label: string; value: string; copied: boolean; onCopy: () => void }) {
  return (
    <View style={styles.row}>
      <View style={{ flex: 1 }}>
        <Text variant="caption" color={colors.textDisabled}>
          {label}
        </Text>
        <Text variant="money" style={styles.credValue}>
          {value}
        </Text>
      </View>
      <Pressable
        onPress={onCopy}
        hitSlop={8}
        accessibilityLabel={`Copy ${label}`}
        style={[styles.copyBtn, copied ? styles.copyBtnActive : null]}
      >
        <Ionicons name={copied ? 'checkmark' : 'copy-outline'} size={18} color={copied ? colors.onAction : colors.text} />
      </Pressable>
    </View>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text variant="caption" color={colors.textDisabled}>
        {label}
      </Text>
      <Text variant="body" style={{ flex: 1, textAlign: 'right' }}>
        {value}
      </Text>
    </View>
  )
}

const styles = StyleSheet.create({
  scroll: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  head: { marginBottom: spacing.md },
  sub: { marginTop: spacing.xs, marginBottom: spacing.lg },
  creds: { gap: spacing.md },
  divider: { height: 1, backgroundColor: colors.divider },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: spacing.md },
  credValue: { fontSize: 20, marginTop: spacing.xs, letterSpacing: 2 },
  copyBtn: {
    width: 40,
    height: 40,
    borderRadius: radii.button,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
    justifyContent: 'center',
  },
  copyBtnActive: { backgroundColor: colors.action, borderColor: colors.action },
  card: { marginTop: spacing.lg },
  body: { marginTop: spacing.sm },
  warning: { borderColor: colors.strokeStrong },
  warningRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
})
