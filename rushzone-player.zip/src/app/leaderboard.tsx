import { useCallback, useEffect, useState } from 'react'
import { FlatList, RefreshControl, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Skeleton } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing } from '@/theme/tokens'
import { formatCoins } from '@/lib/format'
import type { LeaderboardRow } from '@/lib/database.types'

export default function LeaderboardScreen() {
  const [rows, setRows] = useState<LeaderboardRow[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [refreshing, setRefreshing] = useState(false)

  const load = useCallback(async () => {
    setError(null)
    const res = await supabase.from('leaderboard').select('*').limit(10)
    if (res.error) {
      setRows([])
      setError(res.error.message)
      return
    }
    setRows((res.data as LeaderboardRow[] | null) ?? [])
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const onRefresh = useCallback(async () => {
    setRefreshing(true)
    await load()
    setRefreshing(false)
  }, [load])

  return (
    <Screen edges={['top']} padded={false}>
      <FlatList
        data={rows ?? []}
        keyExtractor={(r) => r.profile_id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.text} />}
        contentContainerStyle={styles.list}
        ListHeaderComponent={
          <View style={styles.head}>
            <ScreenHeader title="Leaderboard" />
            <Text variant="body" color={colors.textSecondary}>
              Top 10 players this season — ranked by wins.
            </Text>
          </View>
        }
        renderItem={({ item, index }) => (
          <Card style={styles.row}>
            <View style={[styles.rank, index < 3 ? styles.rankTop : null]}>
              <Text variant="title" color={index < 3 ? colors.onAction : colors.textSecondary}>
                {index + 1}
              </Text>
            </View>
            <View style={styles.body}>
              <View style={styles.nameRow}>
                <Text variant="title" numberOfLines={1} style={{ flex: 1 }}>
                  {item.display_name}
                </Text>
                {index === 0 ? <Ionicons name="trophy" size={16} color={colors.accent} /> : null}
              </View>
              <Text variant="caption" color={colors.textDisabled}>
                {item.in_game_name} · FF UID {item.ff_uid}
              </Text>
            </View>
            <View style={styles.stats}>
              <Text variant="money" color={colors.emphasis}>
                {item.wins} <Text variant="micro" color={colors.textSecondary}>wins</Text>
              </Text>
              <Text variant="caption" color={colors.textDisabled}>
                {item.total_kills} kills · {formatCoins(item.total_prize_coins)} prize
              </Text>
            </View>
          </Card>
        )}
        ListEmptyComponent={
          !rows ? (
            <View style={styles.skeletonWrap}>
              {[0, 1, 2, 3, 4].map((i) => (
                <Skeleton key={i} height={72} radius={radii.card} style={styles.skeleton} />
              ))}
            </View>
          ) : error ? (
            <EmptyState
              title="Leaderboard unavailable"
              body="Couldn't load the standings right now. Pull to refresh and try again."
              icon="⚠"
              actionLabel="Retry"
              onAction={() => void load()}
            />
          ) : (
            <EmptyState title="No standings yet" body="Results appear here once players finish matches." />
          )
        }
      />
    </Screen>
  )
}

const styles = StyleSheet.create({
  list: { padding: spacing.lg, paddingBottom: spacing.xxxl, flexGrow: 1 },
  head: { gap: spacing.xs, marginBottom: spacing.lg },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  rank: {
    width: 40,
    height: 40,
    borderRadius: radii.badge,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankTop: { backgroundColor: colors.action, borderColor: colors.action },
  body: { flex: 1, gap: 2 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  stats: { alignItems: 'flex-end', gap: 2 },
  skeletonWrap: { paddingHorizontal: spacing.lg, gap: spacing.md },
  skeleton: { marginBottom: spacing.sm },
})
