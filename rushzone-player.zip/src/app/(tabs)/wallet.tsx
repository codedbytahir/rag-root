import { useCallback, useEffect, useRef, useState } from 'react'
import {
  Animated,
  Easing,
  FlatList,
  Linking,
  Pressable,
  RefreshControl,
  StyleSheet,
  View,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { supportChatUrl } from '@/components/FloatingSupportButton'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { StatusChip } from '@/components/ui/StatusChip'
import { LottieIcon } from '@/components/ui/LottieIcon'
import { useAuth } from '@/stores/auth'
import { useCashOperationsEnabled, useConfig } from '@/stores/config'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing } from '@/theme/tokens'
import { formatCoins, formatPKTDateTime } from '@/lib/format'
import type { WalletAccountsRow, WalletLedgerRow } from '@/lib/database.types'

const LEDGER_LABELS: Record<string, string> = {
  topup_request: 'Top-up request',
  topup_approved: 'Top-up approved',
  topup_code: 'Code redemption',
  tournament_entry: 'Tournament entry',
  tournament_refund: 'Tournament refund',
  slot_refund: 'Free-slot refund',
  prize_award: 'Prize',
  reward_cost: 'Spin cost',
  reward_award: 'Spin reward',
  streak_reward: 'Streak reward',
  withdrawal_requested: 'Withdrawal',
  withdrawal_paid: 'Withdrawal paid',
  withdrawal_returned: 'Withdrawal returned',
  admin_correction: 'Adjustment',
  referral_reward: 'Referral reward',
  coin_transfer: 'Coin transfer',
}

const EASE_OUT = Easing.out(Easing.cubic)

export default function WalletScreen() {
  const router = useRouter()
  const { profile } = useAuth()
  const cashEnabled = useCashOperationsEnabled()
  const { config } = useConfig()

  const buyUrl = supportChatUrl(
    config?.whatsapp_support_url as string | undefined,
    config?.support_phone as string | undefined,
    'Hi! I would like to buy Rush Coins.',
  )
  const [wallet, setWallet] = useState<WalletAccountsRow | null>(null)
  const [ledger, setLedger] = useState<WalletLedgerRow[] | null>(null)
  const [refreshing, setRefreshing] = useState(false)
  const [shownAvailable, setShownAvailable] = useState(0)

  // Animations: actions slide in on mount, the balance card fades/scales in
  // once data arrives, the balance number counts up, and ledger rows cascade.
  const actionsIn = useRef(new Animated.Value(0)).current
  const cardIn = useRef(new Animated.Value(0)).current
  const countUp = useRef(new Animated.Value(0)).current

  useEffect(() => {
    Animated.timing(actionsIn, {
      toValue: 1,
      duration: 300,
      easing: EASE_OUT,
      useNativeDriver: true,
    }).start()
  }, [actionsIn])

  useEffect(() => {
    if (!wallet) return
    Animated.timing(cardIn, {
      toValue: 1,
      duration: 360,
      easing: EASE_OUT,
      useNativeDriver: true,
    }).start()
  }, [wallet, cardIn])

  // The count-up value drives the displayed balance via a JS listener, so the
  // animation must run on the JS driver (not native).
  useEffect(() => {
    const id = countUp.addListener(({ value }) => setShownAvailable(Math.round(value)))
    return () => countUp.removeListener(id)
  }, [countUp])

  const load = useCallback(async () => {
    const uid = profile?.id
    if (!uid) return
    const [w, l] = await Promise.all([
      supabase.from('wallet_accounts').select('*').eq('profile_id', uid).maybeSingle(),
      supabase.from('wallet_ledger').select('*').eq('profile_id', uid).order('created_at', { ascending: false }).limit(50),
    ])
    const nextWallet = (w.data as WalletAccountsRow | null) ?? null
    setWallet(nextWallet)
    setLedger((l.data as WalletLedgerRow[] | null) ?? [])
    // Count up from wherever the number currently sits (continuous on refresh).
    countUp.stopAnimation()
    Animated.timing(countUp, {
      toValue: nextWallet?.available_balance ?? 0,
      duration: 700,
      easing: EASE_OUT,
      useNativeDriver: false,
    }).start()
  }, [profile?.id, countUp])

  useEffect(() => {
    void load()
  }, [load])

  const onRefresh = useCallback(async () => {
    setRefreshing(true)
    await load()
    setRefreshing(false)
  }, [load])

  const available = wallet?.available_balance ?? 0
  const held = wallet?.held_balance ?? 0

  return (
    <Screen edges={['top']} padded={false}>
      <FlatList
        data={ledger ?? []}
        keyExtractor={(e) => e.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.text} />}
        contentContainerStyle={styles.list}
        ListHeaderComponent={
          <View style={styles.head}>
            <Text variant="display">Wallet</Text>

            {wallet ? (
              <Animated.View
                style={{
                  opacity: cardIn,
                  transform: [
                    { translateY: cardIn.interpolate({ inputRange: [0, 1], outputRange: [16, 0] }) },
                    { scale: cardIn.interpolate({ inputRange: [0, 1], outputRange: [0.98, 1] }) },
                  ],
                }}
              >
                <Card style={styles.balanceCard}>
                  <View style={styles.balanceHead}>
                    <Text variant="label" color={colors.textSecondary}>
                      Available
                    </Text>
                    <LottieIcon name="coin" size={30} />
                  </View>
                  <Text variant="display" color={colors.emphasis}>
                    {formatCoins(shownAvailable)}
                  </Text>
                  <Text variant="caption" color={colors.textDisabled}>
                    1 Rush Coin = PKR 1
                  </Text>
                  <View style={styles.balances}>
                    <BalanceRow label="Held" value={formatCoins(held)} />
                    <BalanceRow label="Total" value={formatCoins(available + held)} />
                  </View>
                  {!cashEnabled ? (
                    <View style={styles.note}>
                      <Ionicons name="information-circle-outline" size={16} color={colors.textSecondary} />
                      <Text variant="caption" color={colors.textSecondary} style={{ flex: 1 }}>
                        Real-money operations are disabled — you&apos;re using test coins.
                      </Text>
                    </View>
                  ) : null}
                </Card>
              </Animated.View>
            ) : (
              <Skeleton height={180} radius={radii.card} />
            )}

            <Animated.View
              style={{
                opacity: actionsIn,
                transform: [
                  { translateY: actionsIn.interpolate({ inputRange: [0, 1], outputRange: [12, 0] }) },
                ],
              }}
            >
              <View style={styles.actions}>
                <Button
                  label="Send coins"
                  size="sm"
                  icon={<LottieIcon name="sparkle" size={16} />}
                  onPress={() => router.push('/wallet-send')}
                  style={styles.actionBtn}
                />
                <Button
                  label="Buy on WhatsApp"
                  size="sm"
                  variant="secondary"
                  onPress={() => buyUrl && void Linking.openURL(buyUrl)}
                  style={styles.actionBtn}
                />
                <Button
                  label="Redeem code"
                  size="sm"
                  variant="secondary"
                  onPress={() => router.push('/wallet-redeem')}
                  style={styles.actionBtn}
                />
                <Button
                  label="Withdraw"
                  size="sm"
                  variant="secondary"
                  onPress={() => router.push('/wallet-withdraw')}
                  style={styles.actionBtn}
                />
              </View>
              <Pressable onPress={() => router.push('/wallet-topup')} accessibilityRole="button">
                <Text variant="caption" color={colors.textSecondary} style={styles.paidLink}>
                  Already paid? Submit payment details
                </Text>
              </Pressable>
            </Animated.View>

            <Text variant="heading" style={styles.historyTitle}>
              History
            </Text>
          </View>
        }
        renderItem={({ item, index }) => <LedgerRow item={item} index={index} />}
        ListEmptyComponent={
          ledger ? (
            <EmptyState title="No transactions yet" body="Your coin movements will appear here." />
          ) : null
        }
      />
    </Screen>
  )
}

/** Ledger entry that fades/slides in, cascading down the list. */
function LedgerRow({ item, index }: { item: WalletLedgerRow; index: number }) {
  const anim = useRef(new Animated.Value(0)).current

  useEffect(() => {
    Animated.timing(anim, {
      toValue: 1,
      duration: 320,
      delay: Math.min(index, 6) * 60,
      easing: EASE_OUT,
      useNativeDriver: true,
    }).start()
  }, [anim, index])

  return (
    <Animated.View
      style={{
        opacity: anim,
        transform: [{ translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }],
      }}
    >
      <Card padded style={styles.ledgerRow}>
        <View style={{ flex: 1 }}>
          <Text variant="body">{LEDGER_LABELS[item.type] ?? item.type}</Text>
          <Text variant="caption" color={colors.textDisabled}>
            {formatPKTDateTime(item.created_at)}
            {item.note ? ` · ${item.note}` : ''}
          </Text>
        </View>
        <View style={styles.amountCol}>
          <Text
            variant="money"
            color={item.direction === 'credit' ? colors.emphasis : colors.textSecondary}
          >
            {item.direction === 'credit' ? '+' : item.direction === 'debit' ? '−' : ''}
            {formatCoins(item.amount)}
          </Text>
          {item.direction === 'hold' || item.direction === 'release' ? (
            <StatusChip tone="neutral" label={item.direction} />
          ) : null}
        </View>
      </Card>
    </Animated.View>
  )
}

function BalanceRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.balanceRow}>
      <Text variant="caption" color={colors.textSecondary}>
        {label}
      </Text>
      <Text variant="money" color={colors.text}>
        {value}
      </Text>
    </View>
  )
}

const styles = StyleSheet.create({
  list: { padding: spacing.lg, paddingBottom: spacing.xxxl, flexGrow: 1 },
  head: { gap: spacing.lg },
  balanceCard: { marginTop: spacing.sm },
  balanceHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  balances: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.md,
  },
  balanceRow: {
    flex: 1,
    backgroundColor: colors.inset,
    borderRadius: radii.input,
    padding: spacing.md,
    gap: spacing.xs,
  },
  actions: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.lg },
  actionBtn: { flexBasis: '47%', flexGrow: 1 },
  note: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, marginTop: spacing.md },
  paidLink: { textAlign: 'center', marginTop: spacing.xs },
  historyTitle: { marginTop: spacing.lg },
  ledgerRow: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm },
  amountCol: { alignItems: 'flex-end', gap: spacing.xs },
})
