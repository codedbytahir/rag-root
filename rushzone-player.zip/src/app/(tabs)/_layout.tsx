import { Tabs } from 'expo-router'
import { Ionicons } from '@expo/vector-icons'
import { colors } from '@/theme/tokens'
import { RushTabBar } from '@/components/tabs/TabBar'

type IconName = keyof typeof Ionicons.glyphMap

const ICONS: Record<string, [IconName, IconName]> = {
  index: ['home', 'home-outline'],
  tournaments: ['trophy', 'trophy-outline'],
  rewards: ['gift', 'gift-outline'],
  wallet: ['wallet', 'wallet-outline'],
  refer: ['people', 'people-outline'],
  profile: ['person', 'person-outline'],
}

export default function TabsLayout() {
  return (
    <Tabs
      tabBar={(props) => <RushTabBar {...props} />}
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.text,
        tabBarInactiveTintColor: colors.textDisabled,
        tabBarStyle: { backgroundColor: colors.surfaceRaised, borderTopWidth: 0 },
        tabBarLabelStyle: { fontSize: 10, fontWeight: '600' },
        tabBarIcon: ({ color, size, focused }) => {
          const [active, inactive] = ICONS[route.name] ?? (['ellipse', 'ellipse-outline'] as [IconName, IconName])
          return <Ionicons name={focused ? active : inactive} size={size} color={color} />
        },
      })}
    >
      <Tabs.Screen name="index" options={{ title: 'Home' }} />
      <Tabs.Screen name="tournaments" options={{ title: 'Tournaments' }} />
      <Tabs.Screen name="rewards" options={{ title: 'Rewards' }} />
      <Tabs.Screen name="wallet" options={{ title: 'Wallet' }} />
      <Tabs.Screen name="refer" options={{ title: 'Refer' }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile' }} />
    </Tabs>
  )
}
