import { useCallback, useEffect, useState } from 'react'
import { Pressable, RefreshControl, ScrollView, StyleSheet, View } from 'react-native'
import { Image } from 'expo-image'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { Linking } from 'react-native'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Skeleton } from '@/components/ui/Skeleton'
import { BannerSlider } from '@/components/home/BannerSlider'
import { CategoryCards } from '@/components/home/CategoryCards'
import { TournamentCard } from '@/components/tournaments/TournamentCard'
import { useAuth } from '@/stores/auth'
import { useConfig } from '@/stores/config'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing, touchTarget } from '@/theme/tokens'
import { formatCoins } from '@/lib/format'
import { publicStorageUrl } from '@/lib/storage'
import { BROWSEABLE_STATUSES, groupTournamentSections } from '@/lib/tournaments'
import type { BannersRow, TournamentsRow, WalletAccountsRow } from '@/lib/database.types'

interface HomeData {
  banners: BannersRow[]
  wallet: WalletAccountsRow | null
  tournaments: TournamentsRow[]
}

export default function HomeScreen() {
  const router = useRouter()
  const { profile } = useAuth()
  const { config } = useConfig()
  const [data, setData] = useState<HomeData | null>(null)
  const [refreshing, setRefreshing] = useState(false)

  const load = useCallback(async () => {
    const uid = profile?.id
    const [bannersRes, tournamentsRes] = await Promise.all([
      supabase.from('banners').select('*').eq('active', true).order('sort_order'),
      supabase.from('tournaments').select('*').in('status', BROWSEABLE_STATUSES).order('match_start_at').limit(20),
    ])
    let wallet: WalletAccountsRow | null = null
    if (uid) {
      const walletRes = await supabase.from('wallet_accounts').select('*').eq('profile_id', uid).maybeSingle()
      wallet = walletRes.data ?? null
    }
    setData({
      banners: (bannersRes.data as BannersRow[] | null) ?? [],
      tournaments: (tournamentsRes.data as TournamentsRow[] | null) ?? [],
      wallet,
    })
  }, [profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  const onRefresh = useCallback(async () => {
    setRefreshing(true)
    await load()
    setRefreshing(false)
  }, [load])

  const avatarUrl = publicStorageUrl('avatars', profile?.avatar_path ?? null)
  const featured = data?.tournaments.find((t) => t.id === config?.featured_tournament_id)
  const sections = data ? groupTournamentSections(data.tournaments) : null

  return (
    <Screen edges={['top']} padded={false}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.text} />}
      >
        {/* Header */}
        <View style={styles.header}>
          <Pressable style={styles.greeting} onPress={() => router.push('/profile')}>
            <View style={styles.avatar}>
              {avatarUrl ? (
                <Image source={{ uri: avatarUrl }} style={styles.avatarImg} contentFit="cover" />
              ) : (
                <Text variant="title" color={colors.textDisabled}>
                  {profile?.display_name?.charAt(0)?.toUpperCase() ?? 'R'}
                </Text>
              )}
            </View>
            <View>
              <Text variant="caption" color={colors.textSecondary}>
                Welcome back
              </Text>
              <Text variant="title">{profile?.display_name ?? 'Player'}</Text>
            </View>
          </Pressable>
          <Pressable
            style={styles.bell}
            onPress={() => router.push('/notifications')}
            accessibilityLabel="Notifications"
            hitSlop={8}
          >
            <Ionicons name="notifications-outline" size={22} color={colors.text} />
          </Pressable>
        </View>

        {data ? <BannerSlider banners={data.banners} /> : <Skeleton height={160} radius={radii.card} />}

        {/* Category cards (filters) */}
        {data ? (
          <View style={styles.section}>
            <SectionHeader title="Categories" />
            <CategoryCards tournaments={data.tournaments} />
          </View>
        ) : null}

        {/* Wallet summary */}
        <View style={styles.section}>
          {data ? (
            <Card>
              <Text variant="label" color={colors.textSecondary}>
                Wallet
              </Text>
              <View style={styles.walletRow}>
                <View>
                  <Text variant="display" color={colors.emphasis}>
                    {formatCoins(data.wallet?.available_balance ?? 0)}
                  </Text>
                  <Text variant="caption" color={colors.textDisabled}>
                    Rush Coins available
                  </Text>
                </View>
                {data.wallet && data.wallet.held_balance > 0 ? (
                  <Text variant="caption" color={colors.textSecondary}>
                    {formatCoins(data.wallet.held_balance)} held
                  </Text>
                ) : null}
              </View>
              <View style={styles.quickRow}>
                <QuickAction icon="add-circle-outline" label="Buy" onPress={() => router.push('/wallet')} />
                <QuickAction icon="arrow-down-outline" label="Withdraw" onPress={() => router.push('/wallet')} />
                <QuickAction icon="gift-outline" label="Rewards" onPress={() => router.push('/rewards')} />
              </View>
            </Card>
          ) : (
            <Skeleton height={140} radius={radii.card} />
          )}
        </View>

        {/* Streak widget */}
        <View style={styles.section}>
          <Card onPress={() => router.push('/streak')}>
            <View style={styles.streakRow}>
              <Ionicons name="flame" size={28} color={colors.accent} />
              <View style={{ flex: 1 }}>
                <Text variant="title">Daily streak</Text>
                <Text variant="caption" color={colors.textSecondary}>
                  Play tournaments daily to build your streak and earn coins.
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textDisabled} />
            </View>
          </Card>
        </View>

        {/* Featured tournament */}
        {featured ? (
          <View style={styles.section}>
            <SectionHeader title="Featured" onSeeAll={() => router.push('/tournaments')} />
            <TournamentCard tournament={featured} onPress={() => router.push(`/tournament/${featured.id}`)} />
          </View>
        ) : null}

        {/* My tournaments shortcut */}
        <View style={styles.section}>
          <Card onPress={() => router.push('/my-tournaments')}>
            <View style={styles.streakRow}>
              <Ionicons name="albums-outline" size={24} color={colors.text} />
              <View style={{ flex: 1 }}>
                <Text variant="title">My tournaments</Text>
                <Text variant="caption" color={colors.textSecondary}>
                  Rooms, live matches, and official results.
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textDisabled} />
            </View>
          </Card>
        </View>

        {/* Leaderboard shortcut */}
        <View style={styles.section}>
          <Card onPress={() => router.push('/leaderboard')}>
            <View style={styles.streakRow}>
              <Ionicons name="trophy-outline" size={24} color={colors.text} />
              <View style={{ flex: 1 }}>
                <Text variant="title">Leaderboard</Text>
                <Text variant="caption" color={colors.textSecondary}>
                  Top 10 players — ranked by wins.
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textDisabled} />
            </View>
          </Card>
        </View>

        {/* Ongoing / Upcoming / Completed sections */}
        {data && sections && sections.length > 0 ? (
          <View style={styles.section}>
            <SectionHeader title="Matches" onSeeAll={() => router.push('/tournaments')} />
            {sections.map((section) => (
              <View key={section.key} style={styles.section}>
                <SectionHeader title={section.title} />
                {section.tournaments.map((t) => (
                  <TournamentCard key={t.id} tournament={t} onPress={() => router.push(`/tournament/${t.id}`)} />
                ))}
              </View>
            ))}
          </View>
        ) : data ? (
          <View style={styles.section}>
            <SectionHeader title="Matches" />
            <Text variant="body" color={colors.textDisabled} style={{ padding: spacing.md }}>
              No matches right now — check back soon.
            </Text>
          </View>
        ) : null}

        {config?.announcement?.active && config.announcement.text ? (
          <View style={styles.section}>
            <Card onPress={config.announcement.link ? () => Linking.openURL(config.announcement!.link!) : undefined}>
              <Text variant="label" color={colors.textSecondary}>
                Announcement
              </Text>
              <Text variant="body">{config.announcement.text}</Text>
              {config.announcement.link ? (
                <Text variant="label" color={colors.emphasis} style={{ marginTop: spacing.sm }}>
                  Learn more
                </Text>
              ) : null}
            </Card>
          </View>
        ) : null}
      </ScrollView>
    </Screen>
  )
}

function QuickAction({
  icon,
  label,
  onPress,
}: {
  icon: keyof typeof Ionicons.glyphMap
  label: string
  onPress: () => void
}) {
  return (
    <Pressable style={styles.quick} onPress={onPress}>
      <Ionicons name={icon} size={20} color={colors.text} />
      <Text variant="caption" color={colors.textSecondary}>
        {label}
      </Text>
    </Pressable>
  )
}

function SectionHeader({ title, onSeeAll }: { title: string; onSeeAll?: () => void }) {
  return (
    <View style={styles.sectionHeader}>
      <Text variant="heading">{title}</Text>
      {onSeeAll ? (
        <Pressable onPress={onSeeAll} hitSlop={8}>
          <Text variant="label" color={colors.textSecondary}>
            See all
          </Text>
        </Pressable>
      ) : null}
    </View>
  )
}

const styles = StyleSheet.create({
  scroll: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.lg,
  },
  greeting: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: radii.badge,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarImg: { width: '100%', height: '100%' },
  bell: {
    width: touchTarget,
    height: touchTarget,
    alignItems: 'center',
    justifyContent: 'center',
  },
  section: { marginTop: spacing.xxl },
  walletRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: spacing.sm },
  quickRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.lg },
  quick: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.md,
    borderRadius: radii.button,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
  },
  streakRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },
})
