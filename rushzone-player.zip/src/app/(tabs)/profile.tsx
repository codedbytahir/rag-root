import { useEffect, useState } from 'react'
import { Linking, Pressable, StyleSheet, View } from 'react-native'
import { Image } from 'expo-image'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/stores/auth'
import { useConfig } from '@/stores/config'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing, touchTarget } from '@/theme/tokens'
import { Skeleton } from '@/components/ui/Skeleton'
import { maskEmail } from '@/lib/format'
import { publicStorageUrl } from '@/lib/storage'
import { pickAndResizeAvatar } from '@/lib/avatar'
import type { ProfileStatsRow } from '@/lib/database.types'

export default function ProfileScreen() {
  const router = useRouter()
  const { profile, signOut, updateAvatar } = useAuth()
  const { config } = useConfig()
  const [stats, setStats] = useState<ProfileStatsRow | null>(null)
  const [statsLoading, setStatsLoading] = useState(true)
  const [picking, setPicking] = useState(false)
  const [photoError, setPhotoError] = useState<string | null>(null)

  useEffect(() => {
    if (!profile?.id) return
    setStatsLoading(true)
    void supabase
      .from('profile_stats')
      .select('*')
      .eq('profile_id', profile.id)
      .maybeSingle()
      .then(({ data }) => {
        setStats((data as ProfileStatsRow | null) ?? null)
        setStatsLoading(false)
      })
  }, [profile?.id])

  const avatarUrl = publicStorageUrl('avatars', profile?.avatar_path ?? null)

  const onChangePhoto = async () => {
    setPhotoError(null)
    setPicking(true)
    const uri = await pickAndResizeAvatar()
    setPicking(false)
    if (!uri) return
    const ok = await updateAvatar(uri)
    if (!ok) setPhotoError('Photo upload failed. Check your connection and try again.')
  }

  return (
    <Screen scroll edges={['top']}>
      <View style={styles.header}>
        <View style={styles.avatar}>
          {avatarUrl ? (
            <Image source={{ uri: avatarUrl }} style={styles.avatarImg} contentFit="cover" />
          ) : (
            <Text variant="display" color={colors.textDisabled}>
              {profile?.display_name?.charAt(0)?.toUpperCase() ?? 'R'}
            </Text>
          )}
        </View>
        <Pressable onPress={() => void onChangePhoto()} disabled={picking} hitSlop={8}>
          <Text variant="label" color={colors.textSecondary}>
            {picking ? 'Opening library…' : profile?.avatar_path ? 'Change photo' : 'Add photo'}
          </Text>
        </Pressable>
        {photoError ? (
          <Text variant="caption" color={colors.textSecondary}>
            ⚠ {photoError}
          </Text>
        ) : null}
        <Text variant="heading">{profile?.display_name}</Text>
        <Text variant="caption" color={colors.textSecondary}>
          UID {profile?.app_uid ?? '—'} · {maskEmail(profile?.email ?? '')}
        </Text>
      </View>

      {statsLoading ? (
        <Skeleton height={92} radius={radii.card} style={styles.statsSkeleton} />
      ) : stats ? (
        <View style={styles.statsRow}>
          <Stat value={stats.wins} label="Wins" />
          <Stat value={stats.tournaments_joined} label="Joined" />
          <Stat value={stats.total_kills} label="Kills" />
          <Stat value={stats.total_prize_coins} label="Prize coins" />
        </View>
      ) : null}

      <Card style={styles.card}>
        <FieldRow label="Free Fire UID" value={profile?.ff_uid} />
        <Divider />
        <FieldRow label="In-game name" value={profile?.in_game_name} />
        <Divider />
        <FieldRow label="WhatsApp" value={profile?.whatsapp_phone} />
      </Card>

      <View style={styles.links}>
        <LinkRow icon="albums-outline" label="My tournaments" onPress={() => router.push('/my-tournaments')} />
        <LinkRow icon="notifications-outline" label="Notifications" onPress={() => router.push('/notifications')} />
        <LinkRow
          icon="share-social-outline"
          label="Share profile card"
          onPress={() => router.push({ pathname: '/share', params: { type: 'profile' } })}
        />
        <LinkRow
          icon="people-outline"
          label="Share invite card"
          onPress={() => router.push({ pathname: '/share', params: { type: 'referral' } })}
        />
        <LinkRow
          icon="document-text-outline"
          label="Policies"
          onPress={() => {
            const url = (config?.policy_links as { url?: string }[] | undefined)?.[0]?.url
            if (url) void Linking.openURL(url)
          }}
        />
        {config?.whatsapp_support_url ? (
          <LinkRow
            icon="logo-whatsapp"
            label="WhatsApp support"
            onPress={() => void Linking.openURL(config.whatsapp_support_url as string)}
          />
        ) : null}
      </View>

      <Button label="Log out" variant="danger" onPress={() => void signOut()} style={styles.logout} />
    </Screen>
  )
}

function Stat({ value, label }: { value: number | string; label: string }) {
  return (
    <View style={styles.stat}>
      <Text variant="title" color={colors.emphasis}>
        {String(value)}
      </Text>
      <Text variant="caption" color={colors.textDisabled}>
        {label}
      </Text>
    </View>
  )
}

function FieldRow({ label, value }: { label: string; value?: string }) {
  return (
    <View style={styles.field}>
      <Text variant="caption" color={colors.textDisabled}>
        {label}
      </Text>
      <Text variant="body">{value || '—'}</Text>
    </View>
  )
}

function Divider() {
  return <View style={styles.divider} />
}

function LinkRow({
  icon,
  label,
  onPress,
}: {
  icon: keyof typeof Ionicons.glyphMap
  label: string
  onPress: () => void
}) {
  return (
    <Pressable style={styles.link} onPress={onPress}>
      <Ionicons name={icon} size={20} color={colors.textSecondary} />
      <Text variant="body" style={{ flex: 1 }}>
        {label}
      </Text>
      <Ionicons name="chevron-forward" size={18} color={colors.textDisabled} />
    </Pressable>
  )
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', gap: spacing.sm, marginTop: spacing.lg },
  avatar: {
    width: 88,
    height: 88,
    borderRadius: radii.badge,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    marginBottom: spacing.sm,
  },
  avatarImg: { width: '100%', height: '100%' },
  statsSkeleton: { marginTop: spacing.xl },
  statsRow: {
    flexDirection: 'row',
    marginTop: spacing.xl,
    backgroundColor: colors.inset,
    borderRadius: radii.card,
    borderWidth: 1,
    borderColor: colors.stroke,
    padding: spacing.lg,
    justifyContent: 'space-between',
  },
  stat: { alignItems: 'center', gap: spacing.xs },
  card: { marginTop: spacing.lg },
  field: { gap: spacing.xs, paddingVertical: spacing.xs },
  divider: { height: 1, backgroundColor: colors.divider, marginVertical: spacing.sm },
  links: {
    marginTop: spacing.lg,
    backgroundColor: colors.surface,
    borderRadius: radii.card,
    borderWidth: 1,
    borderColor: colors.stroke,
    overflow: 'hidden',
  },
  link: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    minHeight: touchTarget + 8,
  },
  logout: { marginTop: spacing.xl },
})
