import { useCallback, useEffect, useMemo, useState } from 'react'
import { FlatList, Pressable, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Skeleton } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { FolderRow } from '@/components/tournaments/FolderRow'
import { buildCategoryFolders } from '@/lib/tournamentCategories'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing } from '@/theme/tokens'
import { BROWSEABLE_STATUSES } from '@/lib/tournaments'
import type { TournamentsRow } from '@/lib/database.types'

export default function TournamentsScreen() {
  const router = useRouter()
  const [all, setAll] = useState<TournamentsRow[] | null>(null)

  const load = useCallback(async () => {
    const res = await supabase
      .from('tournaments')
      .select('*')
      .in('status', BROWSEABLE_STATUSES)
      .order('match_start_at')
      .limit(100)
    setAll((res.data as TournamentsRow[] | null) ?? [])
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const folders = useMemo(() => {
    if (!all) return null
    return buildCategoryFolders(all)
  }, [all])

  return (
    <Screen edges={['top']} padded={false}>
      <View style={styles.head}>
        <View style={styles.headRow}>
          <Text variant="display">Tournaments</Text>
          <Pressable style={styles.myBtn} onPress={() => router.push('/my-tournaments')} hitSlop={8}>
            <Ionicons name="albums-outline" size={16} color={colors.textSecondary} />
            <Text variant="label" color={colors.textSecondary}>
              My
            </Text>
          </Pressable>
        </View>
        <Text variant="body" color={colors.textSecondary}>
          Browse by category — open a folder to find your match. Entry is one account per event.
        </Text>
      </View>

      {!folders ? (
        <View style={styles.skeletonWrap}>
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} height={72} radius={radii.card} style={styles.skeleton} />
          ))}
        </View>
      ) : (
        <FlatList
          data={[
            { key: '__all', label: 'All Tournaments', icon: 'trophy-outline' as const, count: all?.length ?? 0 },
            ...folders,
          ]}
          keyExtractor={(f) => f.key}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <FolderRow
              icon={item.icon}
              title={item.label}
              subtitle={`${item.count} ${item.count === 1 ? 'tournament' : 'tournaments'}`}
              count={item.count}
              onPress={() => router.push(`/tournament/browse/${encodeURIComponent(item.key)}`)}
            />
          )}
          ListEmptyComponent={
            <EmptyState title="No tournaments yet" body="Check back soon — matches get posted here." />
          }
        />
      )}
    </Screen>
  )
}

const styles = StyleSheet.create({
  head: { paddingHorizontal: spacing.lg, paddingTop: spacing.lg, gap: spacing.xs },
  headRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  myBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 8,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
  },
  list: { padding: spacing.lg, paddingBottom: spacing.xxxl, flexGrow: 1 },
  skeletonWrap: { padding: spacing.lg, gap: spacing.lg },
  skeleton: { marginBottom: spacing.sm },
})
