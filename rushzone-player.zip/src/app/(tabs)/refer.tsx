import { StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/stores/auth'
import { colors, spacing } from '@/theme/tokens'

export default function ReferScreen() {
  const router = useRouter()
  const { profile } = useAuth()

  return (
    <Screen scroll edges={['top']}>
      <Text variant="display">Refer friends</Text>
      <Text variant="body" color={colors.textSecondary} style={styles.sub}>
        Invite friends to Rush Zone and earn coins when they qualify.
      </Text>

      <Card style={styles.codeCard}>
        <Text variant="label" color={colors.textSecondary}>
          Your referral code
        </Text>
        <Text variant="display" color={colors.emphasis} style={styles.code}>
          {profile?.referral_code ?? '—'}
        </Text>
        <Text variant="body" color={colors.textSecondary} align="center" style={styles.hint}>
          A friend enters this code at sign-up. Once they complete their first qualifying
          action, both of you earn coins automatically.
        </Text>
        <Button
          label="Share invite card"
          icon={<Ionicons name="share-outline" size={18} color={colors.onAction} />}
          onPress={() => router.push({ pathname: '/share', params: { type: 'referral' } })}
          style={styles.shareBtn}
        />
      </Card>

      <Card style={styles.card}>
        <Text variant="title">How referrals work</Text>
        <Text variant="body" color={colors.textSecondary} style={styles.body}>
          Rewards are granted by the server once qualification is confirmed. Self-referrals and
          same-device abuse are blocked automatically.
        </Text>
      </Card>
    </Screen>
  )
}

const styles = StyleSheet.create({
  sub: { marginTop: spacing.xs },
  codeCard: { marginTop: spacing.xl, alignItems: 'center', gap: spacing.sm },
  code: { letterSpacing: 8, fontSize: 40 },
  hint: { marginTop: spacing.sm },
  shareBtn: { marginTop: spacing.md, alignSelf: 'stretch' },
  card: { marginTop: spacing.lg },
  body: { marginTop: spacing.sm },
})
