import { Pressable, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { colors, radii, spacing } from '@/theme/tokens'

export default function RewardsScreen() {
  const router = useRouter()

  return (
    <Screen scroll edges={['top']}>
      <Text variant="display">Rewards</Text>
      <Text variant="body" color={colors.textSecondary} style={styles.sub}>
        Spin the wheel to win Rush Coins.
      </Text>

      <Card style={styles.wheelCard}>
        <View style={styles.wheel}>
          <Ionicons name="gift" size={64} color={colors.text} />
        </View>
        <Text variant="title" align="center">
          Spin Wheel
        </Text>
        <Text variant="body" color={colors.textSecondary} align="center">
          A paid spin costs 5 coins and always awards a prize. Rewarded-ad spins arrive with the
          ad SDK.
        </Text>
        <View style={styles.actions}>
          <Button label="Open the wheel" onPress={() => router.push('/spin')} />
          <Pressable onPress={() => router.push('/reward-history')} hitSlop={8}>
            <Text variant="label" color={colors.textSecondary} style={styles.history}>
              Reward history →
            </Text>
          </Pressable>
        </View>
      </Card>

      <Card style={styles.card}>
        <Text variant="title">How it works</Text>
        <Text variant="body" color={colors.textSecondary} style={styles.body}>
          Every result is decided and recorded by the server — never by your device. Ad spins
          only pay out after the ad network verifies completion.
        </Text>
      </Card>
    </Screen>
  )
}

const styles = StyleSheet.create({
  sub: { marginTop: spacing.xs },
  wheelCard: { marginTop: spacing.xl, alignItems: 'center', gap: spacing.md },
  wheel: {
    width: 140,
    height: 140,
    borderRadius: radii.badge,
    borderWidth: 1,
    borderColor: colors.strokeStrong,
    backgroundColor: colors.inset,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: spacing.md,
  },
  actions: { gap: spacing.sm, alignSelf: 'stretch' },
  history: { textAlign: 'center', marginTop: spacing.xs },
  card: { marginTop: spacing.lg },
  body: { marginTop: spacing.sm },
})
