import { useCallback, useEffect, useState } from 'react'
import { FlatList, Pressable, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/EmptyState'
import { Skeleton } from '@/components/ui/Skeleton'
import { useAuth } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing } from '@/theme/tokens'
import { formatPKTDateTime } from '@/lib/format'
import type { NotificationsRow } from '@/lib/database.types'

export default function NotificationsScreen() {
  const router = useRouter()
  const { profile } = useAuth()
  const [items, setItems] = useState<NotificationsRow[] | null>(null)

  const load = useCallback(async () => {
    if (!profile?.id) return
    const res = await supabase
      .from('notifications')
      .select('*')
      .eq('profile_id', profile.id)
      .order('created_at', { ascending: false })
      .limit(50)
    setItems((res.data as NotificationsRow[] | null) ?? [])
  }, [profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  const markRead = async (n: NotificationsRow) => {
    if (n.read_at) return
    await supabase.from('notifications').update({ read_at: new Date().toISOString() }).eq('id', n.id)
    setItems((prev) => prev?.map((x) => (x.id === n.id ? { ...x, read_at: new Date().toISOString() } : x)) ?? null)
  }

  return (
    <Screen edges={['top']} padded={false}>
      <View style={styles.head}>
        <ScreenHeader title="Notifications" />
      </View>

      {!items ? (
        <View style={styles.skeletonWrap}>
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} height={104} radius={radii.card} style={styles.skeletonCard} />
          ))}
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(n) => n.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <Pressable onPress={() => void markRead(item)}>
              <Card padded style={[styles.card, !item.read_at && styles.unread]}>
                <View style={styles.cardHead}>
                  <Text variant="title" style={{ flex: 1 }}>
                    {item.title}
                  </Text>
                  {!item.read_at ? <View style={styles.dot} /> : null}
                </View>
                <Text variant="body" color={colors.textSecondary}>
                  {item.body}
                </Text>
                <Text variant="caption" color={colors.textDisabled}>
                  {formatPKTDateTime(item.created_at)}
                </Text>
              </Card>
            </Pressable>
          )}
          ListEmptyComponent={<EmptyState title="No notifications" body="Updates will appear here." />}
        />
      )}
    </Screen>
  )
}

const styles = StyleSheet.create({
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.lg,
    paddingBottom: spacing.sm,
  },
  list: { padding: spacing.lg, paddingBottom: spacing.xxxl, flexGrow: 1 },
  skeletonWrap: { padding: spacing.lg, gap: spacing.md },
  skeletonCard: { marginBottom: spacing.xs },
  card: { marginBottom: spacing.md },
  unread: { borderColor: colors.strokeStrong },
  cardHead: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.xs },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.text },
})
