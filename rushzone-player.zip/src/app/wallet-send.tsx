import { useCallback, useEffect, useState } from 'react'
import { StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Skeleton } from '@/components/ui/Skeleton'
import { LottieIcon } from '@/components/ui/LottieIcon'
import { useAuth } from '@/stores/auth'
import { useCashOperationsEnabled } from '@/stores/config'
import { supabase } from '@/lib/supabase'
import { callEdge } from '@/lib/api'
import { colors, radii, spacing } from '@/theme/tokens'
import { formatCoins, normalizeWhatsappPhone } from '@/lib/format'
import type { WalletAccountsRow } from '@/lib/database.types'

interface TransferResult {
  amount_coins?: number
  recipient?: { id: string; display_name: string | null }
}

export default function SendScreen() {
  const router = useRouter()
  const { profile } = useAuth()
  const cashEnabled = useCashOperationsEnabled()
  const [wallet, setWallet] = useState<WalletAccountsRow | null>(null)
  const [phone, setPhone] = useState('')
  const [amount, setAmount] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<TransferResult | null>(null)

  const load = useCallback(async () => {
    if (!profile?.id) return
    const w = await supabase
      .from('wallet_accounts')
      .select('*')
      .eq('profile_id', profile.id)
      .maybeSingle()
    setWallet((w.data as WalletAccountsRow | null) ?? null)
  }, [profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  const submit = async () => {
    setError(null)
    setResult(null)
    const account = normalizeWhatsappPhone(phone)
    if (!account) {
      setError('Enter a valid Pakistan mobile number (+92…).')
      return
    }
    const coins = Number(amount)
    if (!Number.isInteger(coins) || coins <= 0) {
      setError('Enter a valid whole number of coins.')
      return
    }
    if (wallet && coins > wallet.available_balance) {
      setError('You do not have enough available coins.')
      return
    }
    setLoading(true)
    const res = await callEdge<TransferResult>('wallet-transfer', {
      recipient_phone: account,
      amount_coins: coins,
    })
    setLoading(false)
    if (res.error) {
      setError(res.error.message)
      return
    }
    setResult(res.data ?? {})
    setPhone('')
    setAmount('')
    await load()
  }

  const available = wallet?.available_balance ?? 0

  return (
    <Screen scroll edges={['top', 'bottom']}>
      <View style={styles.head}>
        <ScreenHeader title="Send coins" />
      </View>
      <View style={styles.hero}>
        <LottieIcon name="sendMoney" size={150} />
      </View>
      <Text variant="body" color={colors.textSecondary} style={styles.sub}>
        Send coins instantly to a friend using their WhatsApp number. The amount leaves your
        available balance and is credited to their wallet right away.
      </Text>

      <Card style={styles.card}>
        {wallet ? (
          <View style={styles.balanceRow}>
            <Text variant="caption" color={colors.textSecondary}>
              Available
            </Text>
            <Text variant="money" color={colors.emphasis}>
              {formatCoins(available)}
            </Text>
          </View>
        ) : (
          <Skeleton height={40} radius={radii.input} />
        )}
        {!cashEnabled ? (
          <Text variant="caption" color={colors.textSecondary}>
            Test coins only — real-money operations are disabled.
          </Text>
        ) : null}

        <Input
          label="Friend's WhatsApp number"
          value={phone}
          onChangeText={setPhone}
          keyboardType="phone-pad"
          placeholder="+923001234567"
          containerStyle={styles.field}
          helper="They must have a Rush Zone profile on this number."
        />
        <Input
          label="Amount (Rush Coins)"
          value={amount}
          onChangeText={(v) => setAmount(v.replace(/\D/g, ''))}
          keyboardType="number-pad"
          placeholder={`Up to ${formatCoins(available)}`}
          containerStyle={styles.field}
        />

        {error ? (
          <Text variant="caption" color={colors.textSecondary} style={styles.error}>
            ⚠ {error}
          </Text>
        ) : null}

        <Button
          label={`Send ${amount ? formatCoins(Number(amount)) : ''} coins`}
          onPress={submit}
          loading={loading}
        />
      </Card>

      {result ? (
        <Card style={styles.success}>
          <Ionicons name="checkmark-circle" size={36} color={colors.text} />
          <Text variant="display" color={colors.emphasis}>
            −{formatCoins(result.amount_coins ?? 0)} coins
          </Text>
          <Text variant="body" color={colors.textSecondary} style={styles.successText}>
            Sent to {result.recipient?.display_name ?? 'your friend'}. New balance:{' '}
            {formatCoins(available)} coins.
          </Text>
          <Button label="Done" variant="secondary" onPress={() => router.back()} />
        </Card>
      ) : null}
    </Screen>
  )
}

const styles = StyleSheet.create({
  head: { marginBottom: spacing.lg },
  hero: { alignItems: 'center', marginTop: spacing.lg, height: 130 },
  sub: { marginTop: spacing.xs },
  card: { marginTop: spacing.lg, gap: spacing.md },
  balanceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.inset,
    borderRadius: radii.input,
    padding: spacing.md,
  },
  field: { marginTop: spacing.md },
  error: { marginTop: spacing.xs },
  success: { marginTop: spacing.xl, alignItems: 'center', gap: spacing.sm, borderColor: colors.strokeStrong },
  successText: { textAlign: 'center' },
})
