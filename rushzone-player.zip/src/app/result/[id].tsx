import { useCallback, useEffect, useState } from 'react'
import { ScrollView, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { StatusChip } from '@/components/ui/StatusChip'
import { EmptyState } from '@/components/ui/EmptyState'
import { useAuth } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing } from '@/theme/tokens'
import { formatCoins, formatPKTDateTime } from '@/lib/format'
import type { MatchResultsRow, TournamentsRow } from '@/lib/database.types'

export default function ResultScreen() {
  const { id } = useLocalSearchParams<{ id: string }>()
  const router = useRouter()
  const { profile } = useAuth()

  const [tournament, setTournament] = useState<TournamentsRow | null>(null)
  const [result, setResult] = useState<MatchResultsRow | null>(null)
  const [pending, setPending] = useState(false)

  const load = useCallback(async () => {
    if (!id || !profile?.id) return
    const [t, r] = await Promise.all([
      supabase.from('tournaments').select('*').eq('id', id).maybeSingle(),
      supabase
        .from('match_results')
        .select('*')
        .eq('tournament_id', id)
        .eq('profile_id', profile.id)
        .maybeSingle(),
    ])
    setTournament((t.data as TournamentsRow | null) ?? null)
    const resultRow = (r.data as MatchResultsRow | null) ?? null
    setResult(resultRow && (resultRow.status === 'published' || resultRow.status === 'corrected') ? resultRow : null)
    setPending(Boolean(t.data && (t.data as TournamentsRow).status === 'results_pending' && !resultRow))
  }, [id, profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  const canShare = Boolean(result && result.placement)

  return (
    <Screen edges={['top']} padded={false}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.head}>
          <ScreenHeader title={tournament?.title ?? 'Result'} />
        </View>

        {tournament ? (
          <>
            <View style={styles.chipRow}>
              {result ? (
                <StatusChip tone="success" label="Official result" />
              ) : pending ? (
                <StatusChip tone="info" label="Results pending" />
              ) : null}
            </View>

            {!result && pending ? (
              <Card style={styles.card}>
                <Ionicons name="hourglass-outline" size={32} color={colors.textSecondary} />
                <Text variant="title" style={{ marginTop: spacing.sm }}>
                  Results are on the way
                </Text>
                <Text variant="body" color={colors.textSecondary} style={{ marginTop: spacing.xs }}>
                  Staff are verifying the match. Your official placement, kills, and prize will
                  appear here once published.
                </Text>
              </Card>
            ) : null}

            {result ? (
              <>
                <View style={styles.placeRow}>
                  <View style={styles.placeBox}>
                    <Text variant="caption" color={colors.textDisabled}>
                      Placement
                    </Text>
                    <Text variant="display" color={colors.emphasis}>
                      #{result.placement ?? '—'}
                    </Text>
                  </View>
                  <View style={styles.placeBox}>
                    <Text variant="caption" color={colors.textDisabled}>
                      Kills
                    </Text>
                    <Text variant="display">{result.kills}</Text>
                  </View>
                  <View style={styles.placeBox}>
                    <Text variant="caption" color={colors.textDisabled}>
                      Points
                    </Text>
                    <Text variant="display">{result.points}</Text>
                  </View>
                </View>

                {result.prize_coins > 0 ? (
                  <Card style={styles.prizeCard}>
                    <Text variant="label" color={colors.textSecondary}>
                      Prize
                    </Text>
                    <Text variant="display" color={colors.emphasis}>
                      +{formatCoins(result.prize_coins)} coins
                    </Text>
                    <Text variant="caption" color={colors.textDisabled}>
                      Credited to your wallet · see History
                    </Text>
                  </Card>
                ) : null}

                {result.is_dq ? (
                  <Card style={[styles.card, styles.dq]}>
                    <Text variant="title">Disqualified</Text>
                    <Text variant="body" color={colors.textSecondary} style={{ marginTop: spacing.xs }}>
                      This match was marked as a disqualification. Contact support if you believe
                      this is wrong.
                    </Text>
                  </Card>
                ) : null}

                {result.published_at ? (
                  <Text variant="caption" color={colors.textDisabled} style={styles.published}>
                    Published {formatPKTDateTime(result.published_at)}
                  </Text>
                ) : null}

                {canShare ? (
                  <Button
                    label="Share result"
                    icon={<Ionicons name="share-outline" size={18} color={colors.onAction} />}
                    onPress={() =>
                      router.push({ pathname: '/share', params: { type: 'result', tournamentId: id } })
                    }
                    style={styles.shareBtn}
                  />
                ) : null}
              </>
            ) : null}

            {!result && !pending ? (
              <EmptyState
                icon="document-outline"
                title="No result yet"
                body="Results appear here once staff publish them."
                actionLabel="Go back"
                onAction={() => router.back()}
              />
            ) : null}
          </>
        ) : null}
      </ScrollView>
    </Screen>
  )
}

const styles = StyleSheet.create({
  scroll: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  head: { marginBottom: spacing.md },
  chipRow: { marginBottom: spacing.lg },
  card: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
    borderRadius: radii.card,
    marginBottom: spacing.lg,
  },
  placeRow: { flexDirection: 'row', gap: spacing.md },
  placeBox: {
    flex: 1,
    backgroundColor: colors.inset,
    borderRadius: radii.input,
    borderWidth: 1,
    borderColor: colors.stroke,
    padding: spacing.lg,
    alignItems: 'center',
    gap: spacing.xs,
  },
  prizeCard: { marginTop: spacing.lg, alignItems: 'center', gap: spacing.xs, borderColor: colors.strokeStrong },
  dq: { borderColor: colors.strokeStrong, alignItems: 'flex-start', paddingVertical: spacing.lg },
  published: { textAlign: 'center', marginTop: spacing.lg },
  shareBtn: { marginTop: spacing.lg },
})
