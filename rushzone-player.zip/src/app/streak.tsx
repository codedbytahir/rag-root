import { useCallback, useEffect, useMemo, useState } from 'react'
import { ScrollView, StyleSheet, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { Screen } from '@/components/ui/Screen'
import { ScreenHeader } from '@/components/ui/ScreenHeader'
import { Text } from '@/components/ui/Text'
import { Card } from '@/components/ui/Card'
import { Skeleton } from '@/components/ui/Skeleton'
import { useAuth } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import { colors, radii, spacing } from '@/theme/tokens'
import {
  buildHeatmap,
  computeStreaks,
  DEFAULT_STREAK_TIERS,
  pktToday,
  type HeatWeek,
  type StreakStats,
} from '@/lib/streaks'
import type { StreakDaysRow, StreakFreezesRow, StreakMilestonesRow } from '@/lib/database.types'

const WEEKS = 17
const WEEKDAY_LABELS = ['S', 'M', 'T', 'W', 'T', 'F', 'S']
const CELL = 13
const CELL_GAP = 3

export default function StreakScreen() {
  const router = useRouter()
  const { profile } = useAuth()
  const [days, setDays] = useState<StreakDaysRow[] | null>(null)
  const [milestones, setMilestones] = useState<StreakMilestonesRow[]>([])
  const [freezes, setFreezes] = useState(0)

  const load = useCallback(async () => {
    if (!profile?.id) return
    const [d, m, f] = await Promise.all([
      supabase.from('streak_days').select('*').eq('profile_id', profile.id),
      supabase.from('streak_milestones').select('*').eq('profile_id', profile.id),
      supabase.from('streak_freezes').select('*').eq('profile_id', profile.id).maybeSingle(),
    ])
    setDays((d.data as StreakDaysRow[] | null) ?? [])
    setMilestones((m.data as StreakMilestonesRow[] | null) ?? [])
    if (!f.error && f.data) setFreezes((f.data as StreakFreezesRow).balance ?? 0)
  }, [profile?.id])

  useEffect(() => {
    void load()
  }, [load])

  const stats: StreakStats | null = useMemo(
    () => (days ? computeStreaks(days, pktToday()) : null),
    [days],
  )
  const heatmap: HeatWeek[] | null = useMemo(
    () => (days ? buildHeatmap(days, pktToday(), WEEKS) : null),
    [days],
  )
  const claimed = useMemo(() => new Set(milestones.map((m) => m.day_count)), [milestones])

  return (
    <Screen edges={['top']} padded={false}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.head}>
          <ScreenHeader title="Daily streak" />
        </View>

        {!stats || !heatmap ? (
          <View style={styles.skeletonWrap}>
            <Skeleton height={100} radius={radii.card} />
            <Skeleton height={220} radius={radii.card} />
          </View>
        ) : (
          <>
            <Card style={styles.hero}>
              <View style={styles.heroRow}>
                <Ionicons name="flame" size={44} color={colors.accent} />
                <View>
                  <Text variant="display" color={colors.emphasis}>
                    {stats.current}
                  </Text>
                  <Text variant="label" color={colors.textSecondary}>
                    day{stats.current === 1 ? '' : 's'} streak
                  </Text>
                </View>
              </View>
              <View style={styles.statRow}>
                <Stat label="Longest" value={stats.longest} />
                <Stat label="Total days" value={stats.total} />
                <Stat label="This month" value={stats.thisMonth} />
                <Stat label="Freezes" value={freezes} />
              </View>
            </Card>

            <Card style={styles.card}>
              <Text variant="title" style={styles.cardTitle}>
                Streak calendar
              </Text>
              <Heatmap heatmap={heatmap} />
              <Text variant="caption" color={colors.textDisabled} style={styles.legend}>
                A day counts when you complete a qualifying action — a spin, a tournament entry,
                or a published result. Server-computed in PKT.
              </Text>
            </Card>

            <Card style={styles.card}>
              <Text variant="title" style={styles.cardTitle}>
                Milestones
              </Text>
              {DEFAULT_STREAK_TIERS.map((tier) => {
                const isClaimed = claimed.has(tier.day)
                const reached = stats.current >= tier.day
                const progress = Math.min(1, stats.current / tier.day)
                return (
                  <View key={tier.day} style={styles.tier}>
                    <View style={styles.tierHead}>
                      <View style={styles.tierBadge}>
                        <Ionicons
                          name={isClaimed ? 'checkmark' : 'flame'}
                          size={14}
                          color={isClaimed ? colors.onAction : colors.text}
                        />
                        <Text variant="label" color={isClaimed ? colors.onAction : colors.text}>
                          {tier.day}
                        </Text>
                      </View>
                      <Text variant="body" style={{ flex: 1 }}>
                        {tier.coins} coins
                      </Text>
                      {reached && !isClaimed ? (
                        <Text variant="caption" color={colors.textSecondary}>
                          Reached
                        </Text>
                      ) : null}
                    </View>
                    <View style={styles.progressTrack}>
                      <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
                    </View>
                  </View>
                )
              })}
              <Text variant="caption" color={colors.textDisabled} style={styles.legend}>
                Milestone coins are granted by the server and can never be re-claimed.
              </Text>
            </Card>
          </>
        )}
      </ScrollView>
    </Screen>
  )
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <View style={styles.stat}>
      <Text variant="title" color={colors.emphasis}>
        {value}
      </Text>
      <Text variant="caption" color={colors.textDisabled}>
        {label}
      </Text>
    </View>
  )
}

function Heatmap({ heatmap }: { heatmap: HeatWeek[] }) {
  return (
    <View>
      <View style={styles.heatRow}>
        <View style={styles.weekdayCol}>
          {WEEKDAY_LABELS.map((l, i) => (
            <Text key={i} variant="micro" color={colors.textDisabled} style={styles.weekday}>
              {l}
            </Text>
          ))}
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={styles.heatCols}>
            {heatmap.map((week, wi) => (
              <View key={wi} style={styles.weekCol}>
                <Text variant="micro" color={colors.textDisabled} style={styles.month}>
                  {week.monthLabel}
                </Text>
                {week.days.map((cell, di) => (
                  <View
                    key={di}
                    style={[
                      styles.cell,
                      { backgroundColor: cellColor(cell.intensity) },
                      cell.isFuture && styles.cellFuture,
                      cell.isToday && styles.cellToday,
                    ]}
                  />
                ))}
              </View>
            ))}
          </View>
        </ScrollView>
      </View>
    </View>
  )
}

function cellColor(intensity: number): string {
  switch (intensity) {
    case 0:
      return colors.inset
    case 1:
      return '#2E2E2E'
    case 2:
      return '#4A4A4A'
    case 3:
      return '#8A8A8A'
    default:
      return colors.text
  }
}

const styles = StyleSheet.create({
  scroll: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  head: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.lg },
  skeletonWrap: { gap: spacing.lg },
  hero: { gap: spacing.lg },
  heroRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg },
  statRow: { flexDirection: 'row', justifyContent: 'space-between' },
  stat: { alignItems: 'center', gap: spacing.xs },
  card: { marginTop: spacing.lg },
  cardTitle: { marginBottom: spacing.md },
  heatRow: { flexDirection: 'row', gap: spacing.sm },
  weekdayCol: { gap: CELL_GAP },
  weekday: { height: CELL, textAlign: 'center', lineHeight: CELL + 2, width: 12 },
  heatCols: { flexDirection: 'row', gap: CELL_GAP },
  weekCol: { gap: CELL_GAP },
  month: { height: CELL, lineHeight: CELL + 2, textAlign: 'center' },
  cell: {
    width: CELL,
    height: CELL,
    borderRadius: 3,
    borderWidth: 1,
    borderColor: colors.stroke,
  },
  cellFuture: { opacity: 0.35 },
  cellToday: { borderColor: colors.text, borderWidth: 2 },
  legend: { marginTop: spacing.md },
  tier: { gap: spacing.xs, marginBottom: spacing.md },
  tierHead: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  tierBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.inset,
    borderRadius: radii.badge,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderWidth: 1,
    borderColor: colors.strokeStrong,
  },
  progressTrack: {
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.inset,
    borderWidth: 1,
    borderColor: colors.stroke,
    overflow: 'hidden',
  },
  progressFill: { height: '100%', backgroundColor: colors.text },
})
