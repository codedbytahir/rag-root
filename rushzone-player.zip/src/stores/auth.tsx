import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase'
import type { ProfilesRow } from '@/lib/database.types'
import { hasAcceptedConsent, recordConsent } from '@/lib/consent'
import { normalizeWhatsappPhone } from '@/lib/format'
import { registerPushToken } from '@/lib/notifications'
import { uploadAvatar } from '@/lib/avatar'

export type AuthPhase = 'loading' | 'signedOut' | 'needsConsent' | 'needsProfile' | 'ready'

export interface ProfileInput {
  displayName: string
  ffUid: string
  inGameName: string
  whatsappPhone: string
  avatarUri?: string | null
  referralCode?: string | null
}

interface AuthContextValue {
  phase: AuthPhase
  session: Session | null
  profile: ProfilesRow | null
  signInWithPassword: (email: string, password: string) => Promise<string | null>
  acceptConsent: () => void
  completeProfile: (input: ProfileInput) => Promise<string | null>
  refreshProfile: () => Promise<void>
  /** Upload a new avatar for the signed-in user; resolves true when saved. */
  updateAvatar: (localUri: string) => Promise<boolean>
  /** Progress 0–100 of the in-flight avatar upload, or null when idle. */
  avatarUploadProgress: number | null
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | null>(null)

const GENERIC_AUTH_ERROR = 'Unable to sign in. Check your details and try again.'

/**
 * Upper bound for a sign-in/sign-up round trip; prevents a stalled request
 * from freezing the UI forever. Generous enough to cover a slow-but-working
 * connection (two sequential auth requests plus a profile read).
 */
const SIGN_IN_TIMEOUT_MS = 45000

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('The request timed out. Please try again.')), ms),
    ),
  ])
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<ProfilesRow | null>(null)
  const [phase, setPhase] = useState<AuthPhase>('loading')
  const [avatarUploadProgress, setAvatarUploadProgress] = useState<number | null>(null)
  const avatarTicker = useRef<ReturnType<typeof setInterval> | null>(null)
  const avatarDismissTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Clear any in-flight progress timers when the provider unmounts.
  useEffect(
    () => () => {
      if (avatarTicker.current) clearInterval(avatarTicker.current)
      if (avatarDismissTimer.current) clearTimeout(avatarDismissTimer.current)
    },
    [],
  )

  const loadProfile = useCallback(async (uid: string) => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', uid)
      .maybeSingle()
    if (error) {
      // profile read is best-effort; treat errors as "no profile yet"
      return null
    }
    return (data as ProfilesRow | null) ?? null
  }, [])

  const derivePhase = useCallback(async (sess: Session | null) => {
    try {
      if (!sess) {
        setProfile(null)
        setPhase('signedOut')
        return
      }
      const uid = sess.user.id
      const prof = await loadProfile(uid)
      setProfile(prof)
      if (prof) {
        setPhase('ready')
        return
      }
      const consent = await hasAcceptedConsent()
      setPhase(consent ? 'needsProfile' : 'needsConsent')
    } catch {
      // Never let a phase-derivation failure strand the user mid-auth: fall back
      // to the most conservative phase for the session state so the router always
      // lands somewhere sane (login / onboarding). A later session event re-derives.
      setProfile(null)
      setPhase(sess ? 'needsConsent' : 'signedOut')
    }
  }, [loadProfile])

  useEffect(() => {
    let active = true
    void (async () => {
      const {
        data: { session: sess },
      } = await supabase.auth.getSession()
      if (!active) return
      setSession(sess)
      await derivePhase(sess)
    })()

    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess)
      // Fire-and-forget: auth-js awaits subscriber callbacks, and derivePhase
      // performs its own network read. Awaiting it here would hold up the auth
      // call (and the login button's spinner) for a full extra round-trip.
      void derivePhase(sess)
    })

    return () => {
      active = false
      sub.subscription.unsubscribe()
    }
  }, [derivePhase])

  // Simple email + password login, no OTP. Tries to sign in first; if that
  // fails, the account probably doesn't exist yet, so it creates one with the
  // entered password (autoconfirm is enabled on the project, so signup returns
  // a session immediately — no email confirmation needed). If the account
  // already exists, the real sign-in error is surfaced (e.g. wrong password).
  //
  // Hardened so this can never hang the UI: the whole operation is wrapped in
  // try/catch (auth-js rethrows non-auth errors) and raced against a timeout
  // (a stalled network request would otherwise leave the button spinning).
  const signInWithPassword = useCallback(async (email: string, password: string) => {
    const normalized = email.trim().toLowerCase()
    try {
      return await withTimeout(
        (async () => {
          const { error } = await supabase.auth.signInWithPassword({ email: normalized, password })
          if (!error) return null

          // Sign-in failed — the account probably doesn't exist yet. Create it.
          const { data, error: signUpError } = await supabase.auth.signUp({ email: normalized, password })
          if (signUpError) {
            // Account already exists — surface the real sign-in error (e.g.
            // "Invalid login credentials") so the user knows to fix the password.
            return error.message || GENERIC_AUTH_ERROR
          }
          if (!data.session) {
            // Signup succeeded but no session came back (e.g. the project requires
            // email confirmation). Don't claim success — the user would be stuck
            // on this screen with no feedback and no navigation.
            return 'Account created. Check your email to confirm it, then sign in again.'
          }
          // Session established — onAuthStateChange re-derives the phase.
          return null
        })(),
        SIGN_IN_TIMEOUT_MS,
      )
    } catch {
      // Includes the timeout rejection — never throw out of here.
      return 'Unable to sign in. Check your connection and try again.'
    }
  }, [])

  const acceptConsent = useCallback(async () => {
    await recordConsent()
    setPhase('needsProfile')
  }, [])

  const refreshProfile = useCallback(async () => {
    const uid = session?.user.id
    if (!uid) return
    const prof = await loadProfile(uid)
    setProfile(prof)
    if (prof) setPhase('ready')
  }, [session, loadProfile])

  // Avatar is optional and best-effort: upload it in the background after the
  // profile row exists, then persist the storage path to the DB. A slow upload
  // never blocks onboarding, and no orphan files are left if profile creation fails.
  //
  // The storage SDK exposes no real byte progress for this small payload, so we
  // animate a believable reading that eases toward ~90% while the request is in
  // flight and jumps to 100% on success — like a system file-transfer dialog.
  const updateAvatar = useCallback(
    async (localUri: string): Promise<boolean> => {
      const uid = session?.user.id
      if (!uid) return false

      setAvatarUploadProgress(6)
      avatarTicker.current = setInterval(() => {
        setAvatarUploadProgress((prev) => {
          if (prev == null) return prev
          const step = Math.max(0.5, (90 - prev) * 0.16)
          return Math.min(90, Math.round(prev + step))
        })
      }, 120)

      let ok = false
      try {
        const path = await uploadAvatar(uid, localUri)
        if (!path) return false
        const { error } = await supabase.from('profiles').update({ avatar_path: path }).eq('id', uid)
        if (error) return false
        await refreshProfile()
        ok = true
        return true
      } finally {
        if (avatarTicker.current) {
          clearInterval(avatarTicker.current)
          avatarTicker.current = null
        }
        if (ok) {
          setAvatarUploadProgress(100)
          avatarDismissTimer.current = setTimeout(() => setAvatarUploadProgress(null), 600)
        } else {
          setAvatarUploadProgress(null)
        }
      }
    },
    [session, refreshProfile],
  )

  const completeProfile = useCallback(
    async (input: ProfileInput) => {
      const uid = session?.user.id
      if (!uid) return 'Please sign in again.'
      const normalizedPhone = normalizeWhatsappPhone(input.whatsappPhone)
      if (!normalizedPhone) return 'Enter a valid Pakistan mobile number (+92…).'
      const { error } = await supabase.rpc('complete_profile', {
        p_user_id: uid,
        p_display_name: input.displayName.trim(),
        p_ff_uid: input.ffUid.trim(),
        p_in_game_name: input.inGameName.trim(),
        p_whatsapp_phone: normalizedPhone,
        p_avatar_path: null,
        p_referral_code_input: input.referralCode?.trim() || null,
      })
      if (error) return 'Unable to save your profile. Check your details and try again.'
      await refreshProfile()
      registerPushToken()
      if (input.avatarUri) {
        void updateAvatar(input.avatarUri)
      }
      return null
    },
    [session, refreshProfile, updateAvatar],
  )

  const signOut = useCallback(async () => {
    await supabase.auth.signOut()
    setProfile(null)
    setSession(null)
    setPhase('signedOut')
  }, [])

  return (
    <AuthContext.Provider
      value={{
        phase,
        session,
        profile,
        signInWithPassword,
        acceptConsent,
        completeProfile,
        refreshProfile,
        updateAvatar,
        avatarUploadProgress,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
