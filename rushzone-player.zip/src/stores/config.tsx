import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import {
  evaluateGate,
  fetchAppConfig,
  fetchAppVersion,
  type AppConfig,
  type GateState,
  type VersionGate,
} from '@/lib/config'

interface ConfigContextValue {
  gate: GateState
  config: AppConfig | null
  version: VersionGate | null
  refresh: () => Promise<void>
}

const ConfigContext = createContext<ConfigContextValue>({
  gate: { status: 'loading' },
  config: null,
  version: null,
  refresh: async () => {},
})

export function ConfigProvider({ children }: { children: ReactNode }) {
  const [gate, setGate] = useState<GateState>({ status: 'loading' })
  const [config, setConfig] = useState<AppConfig | null>(null)
  const [version, setVersion] = useState<VersionGate | null>(null)

  const refresh = useCallback(async () => {
    const [cfg, ver] = await Promise.all([fetchAppConfig(), fetchAppVersion()])
    setConfig(cfg)
    setVersion(ver)
    setGate(evaluateGate(cfg, ver))
  }, [])

  useEffect(() => {
    void refresh()
  }, [refresh])

  return (
    <ConfigContext.Provider value={{ gate, config, version, refresh }}>
      {children}
    </ConfigContext.Provider>
  )
}

export function useConfig(): ConfigContextValue {
  return useContext(ConfigContext)
}

/** True when real-money operations are disabled (simulated/test coins only). */
export function useCashOperationsEnabled(): boolean {
  const { config, version } = useConfig()
  return Boolean(version?.cash_operations_enabled ?? config?.cash_operations_enabled ?? false)
}
