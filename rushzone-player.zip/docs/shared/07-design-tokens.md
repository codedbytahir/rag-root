# 07 — Design Tokens (Shared Language)

Both apps share one brand language. The Player App uses a **black & white, dark-mode-only** treatment with a soft "clay" tactile depth; Rush Zone Control uses a warm light/cream version for long operational/finance sessions. They feel like one product but are tuned for their audience.

> **Player App theme status:** monochrome (black & white), dark only — **no light mode toggle**. The earlier espresso/orange/gold palette is retired for the Player App.

---

## 1. Shared constants

- Cards 12px radius; buttons/inputs 8px radius; small badges may be pills.
- Minimum touch target 44×44px.
- Display: editorial serif (PP Editorial Old → Georgia/Times fallback).
- UI: Inter → system sans-serif.
- Status is never color-only; always pair with icon/label.
- Brand stripe above every bottom nav: player = monochrome hairline (white → grey → black); admin = cream fade.
- Motion is **purposeful and consistent** — see §4. Same durations/easings across both apps.

## 2. Player App — Monochrome (black & white, dark only)

The Player App reads as a premium **gaming** product: near-black layered surfaces, high-contrast white type, and a single white primary action. Depth comes from **strokes (outlines) and soft clay-style shadow layering**, not from color.

### 2.1 Palette

| Token | Value | Use |
|---|---|---|
| Canvas | `#0A0A0A` | Base background, screen canvas |
| Deep | `#000000` | Deepest shadows, scrim anchor, wheel/void areas |
| Surface | `#161616` | Cards, sheets |
| Surface raised | `#1E1E1E` | Nav bar, modals, bottom sheets, menus |
| Inset | `#101010` | Inputs, troughs, code fields, wells |
| Primary text | `#FFFFFF` | Headings, values, primary content |
| Secondary text | `#A6A6A6` | Metadata, captions, secondary labels |
| Disabled | `#565656` | Inactive/disabled states |
| Primary action | `#FFFFFF` | The single primary CTA (white fill, black text) |
| Primary pressed | `#E2E2E2` | Pressed/active primary |
| Emphasis / highlight | `#FFFFFF` | Coins, streak count, selected/active values (value emphasis, not buttons) |
| Stroke | `#2C2C2C` | Card/button outline (the "stroke" that gives the clay/edged feel) |
| Stroke strong | `#4A4A4A` | Focus, selected ring, input focus |
| Divider | `#1C1C1C` | Hairline separators |
| Clay highlight | `rgba(255,255,255,0.07)` | Inner top light on surfaces/buttons (clay depth) |
| Clay shade | `rgba(0,0,0,0.55)` | Inner bottom shade + outer drop shadow |
| Scrim | `rgba(0,0,0,0.72)` | Modal backdrop |

### 2.2 Color usage rules

- **White is the only accent.** It is reserved for (a) the single primary action per screen and (b) value/emphasis (coins, streak, active selection). Do not paint whole cards white.
- Everything else is a neutral grey step. Build hierarchy with **tone, stroke weight, and shadow depth**, not hue.
- **Strokes on cards and buttons** are required for the tactile/edged look: a 1px `Stroke` outline plus a subtle inner `Clay highlight` along the top and `Clay shade` along the bottom.
- Never use pure `#000000` as a large flat surface — it is reserved for deepest shadows/voids; the canvas is `#0A0A0A` so strokes and shadows remain visible.
- **Status (success/danger) is monochrome + iconography.** In a B&W system color alone cannot carry meaning, so every status pairs an icon + label with a fill/stroke inversion:
  - *Positive/success:* filled white chip with a black ✓ glyph (or outline chip with a ✓ + label).
  - *Negative/danger:* inverted chip (white text on black) with an ⚠ glyph + label.
  - If a future revision re-adds a single semantic accent, it must never be the only indicator.

### 2.3 Clay texture ("claymorphism") depth system

The tactile, slightly 3D "clay" look is built from layered shadows — **not** gradients of color and **not** bigger radii (keep the shared 12px/8px radii):

- **Outer drop shadow:** soft, low-opacity black (`Clay shade`) blurred ~16–24px, offset ~4px down.
- **Inner top highlight:** a 1px `Clay highlight` line near the top edge, simulating light catching a raised clay edge.
- **Inner bottom shade:** a soft `Clay shade` toward the bottom edge.
- **Stroke:** a crisp 1px `Stroke` outline on the card/button perimeter (the "edge").

Combined recipe for a card:

```text
fill: Surface
stroke: 1px Stroke
shadow-outer: 0 6px 20px rgba(0,0,0,0.55)
shadow-inner-top: inset 0 1px 0 rgba(255,255,255,0.07)
shadow-inner-bottom: inset 0 -1px 0 rgba(0,0,0,0.55)
```

Buttons:

- **Primary (filled):** white fill, black text, 1px `Stroke strong` outline, subtle inner-top highlight; on press the fill darkens to `Primary pressed` and the shadow flattens (button sinks).
- **Secondary (outlined):** transparent fill, `#161616`-over-canvas, 1px `Stroke` outline, clay shadow; on press the stroke brightens to `Stroke strong`.
- **Ghost/tertiary:** no fill, no stroke; underline or icon only.

### 2.4 Typography

- Large display headings use the editorial serif in **white**, tight leading, strong whitespace.
- Interface labels, body, forms, buttons, lists, and numeric detail use Inter/system sans.
- Body 14–16px. Numeric/coin values use tabular/monospaced figures for alignment.
- Uppercase micro-labels only for metadata/status, never for long content.
- High contrast for financial values and room information: white primary text; emphasis (white, possibly bolder) only for the celebratory numeric value.
- Body text must meet WCAG AA on `#0A0A0A`; secondary text stays `#A6A6A6` or lighter for anything important.

---

## 3. Admin App — warm cream (operational clarity)

| Token | Value |
|---|---|
| Canvas | `#FFFDF6` |
| Surface / card | `#FFFFFF` with warm shadow |
| Cream panel | `#FFF0C3` |
| Ink / primary text | `#172016` |
| Secondary text | `#5B4E3C` |
| Primary action | `#ED5A1F` |
| Primary pressed | `#C24716` |
| Coin/highlight | `#F4B826` |
| Success | `#39754B` |
| Danger | `#B23A2E` |
| Border | `#DED3B9` |

---

## 4. Motion & micro-interactions (both apps)

Motion is **tasteful, purposeful, and never blocks interaction**. It reinforces cause → effect, continuity, and hierarchy. Respect `prefers-reduced-motion`; skip/soften all animation when set.

### 4.1 Duration tokens

| Token | Value | Use |
|---|---|---|
| Instant | `80ms` | Ripple, press feedback, toggle snap |
| Fast | `140ms` | Hover/press states, chip toggles |
| Base | `220ms` | Cards, sheets, screen transitions, nav |
| Slow | `360ms` | Celebration, modals, count-ups, wheel settle |

### 4.2 Easing tokens

| Token | Value | Use |
|---|---|---|
| Standard | `cubic-bezier(0.2, 0, 0, 1)` | Default transitions |
| Emphasize | `cubic-bezier(0.3, 0.7, 0.2, 1)` | Gaming-feel emphasis, entrances |
| Spring (press) | `{ mass: 0.8, stiffness: 260, damping: 22 }` | Button press scale |

### 4.3 Micro-interactions

- **Button press:** scale `1 → 0.97` + shadow flatten (`80–140ms`, spring) then release.
- **Card tap:** lift `-2px` + deepen outer shadow; returns on release.
- **Screen transition:** fade + `8px` slide, `220ms` standard easing.
- **List entrance:** staggered children (`30ms` step) fade/slide-in.
- **Skeleton loader:** white `6%` shimmer sweep across the surface, `1.2s` loop.
- **Numeric count-up:** coins/streak animate `0 → value` over `~400ms` with tabular figures.
- **Nav indicator:** active tab indicator slides between items (`220ms`).
- **Spin wheel:** physics-based deceleration, `1.6–2.4s`, settles exactly on the server-selected result; brief `Emphasize` settle pulse.
- **Win / celebration:** monochrome particle burst (white/grey, matched to the B&W palette), `360ms`, then the result sheet.
- **Streak flame:** gentle `1.2s` breathing pulse (no flashing).
- **Focus ring:** `Stroke strong` outline fade-in on inputs (`140ms`).

### 4.4 Rules

- No animation should prevent a user from acting; timeouts/loops are capped and interruptible.
- One primary motion idea per screen — don't stack multiple entrances.
- Animations on money/result screens must **never** imply a value change before the server confirms it; animate only after the authoritative response arrives.
- Keep durations fast on high-frequency UI (lists, toggles) and reserve slow motion for low-frequency moments (wins, milestones).
