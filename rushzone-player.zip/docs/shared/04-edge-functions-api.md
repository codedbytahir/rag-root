# 04 — Edge Functions / API Surface

This document reflects the **actual deployed backend** (see `rushzone/supabase/functions/`). It is the build contract for the Player App.

Two access layers:

1. **Edge Functions** (`/functions/v1/<name>`) — all privileged writes. They verify the caller's JWT from `Authorization: Bearer <jwt>`, authorize server-side, and act with the **secret key** (`sb_secret_…`, never shipped to the app).
2. **PostgREST + RLS** (publishable key `sb_publishable_…`) — all reads of public/self-owned data, plus a small set of RPCs. RLS policies decide what each caller may read.

Conventions:
- Every money/registration/reward mutation accepts an `Idempotency-Key` header (UUID) so retries cannot double-apply.
- All times in responses are ISO 8601 UTC; clients render PKT (`Asia/Karachi`).
- Errors use a stable shape: `{ error: { code, message, retryable } }` with HTTP status codes.
- Money values are whole integer Rush Coins (`bigint`).

---

## 1. Public endpoints (no auth)

| Function | Method | Purpose |
|---|---|---|
| `app-config` | GET | Single fetch of everything the app shell needs: `policy_links` (editable JSON array) + `policies`, `landing_page_url` / `home_page_url` / `about_app_url` / `about_app`, `support_phone` / `admin_phone` / `whatsapp_support_url` / `support_email`, `announcement`, `featured_tournament_id`, `versions` (`player_min/player_latest/admin_min/admin_latest`, `force_update`), `maintenance`, `cash_operations_enabled`, `social`, `stores` |
| `app-version` | GET | Version gate: `player_min_version`/`player_latest_version`, `admin_min_version`/`admin_latest_version`, `force_update`, `maintenance` (boolean) + `maintenance_message`, `cash_operations_enabled` |

Both are read by the app on launch/resume (splash → maintenance/force-update gate).

## 2. Player endpoints (auth: user JWT)

| Function | Method | Purpose |
|---|---|---|
| `wallet-topup-create` | POST | Create a manual top-up request: `{ method: 'easypaisa'\|'jazzcash', amount_coins, reference }` (payment TX id, **no screenshot**). Pending only; no credit until admin approval. |
| `wallet-withdraw-create` | POST | Create a withdrawal request: `{ method, account_snapshot (phone), amount_coins }`. Backend holds coins atomically (`withdrawal_requested` hold). |
| `wallet-withdraw-cancel` | POST | Cancel own pending/approved withdrawal → held coins released back to available (`withdrawal_returned`). |
| `rewards-attempt-paid` | POST | Paid Spin Wheel attempt: `{ campaign_id }` → atomic `reward_cost` debit + server-selected `reward_award` credit. |
| `rewards-ssv-callback` | POST | Ad-network server-side verification callback (AdMob/Unity, HMAC-signed). **Not called by the app.** Grants `reward_award` only after verification. |
| `tournaments-room` | GET or POST | Room credentials (`room_id`, `room_password`, `server_region`, `instructions`, `released_at`) — `tournament_id` in query string **or** JSON body. Only if the caller is a confirmed registrant **and** the room is released; else 403. Rooms are never readable via RLS. |
| `topup-codes-redeem` | POST | Redeem an admin-issued 6-digit top-up code: `{ code }` → atomic one-time claim (409 if already redeemed/disabled) → `topup_code` ledger credit. |
| `share-event` | POST | Record a marketing-card share: `{ card_type, channel, ref_type?, ref_id? }` into `app.card_share_events`. |
| `push-token-register` | POST | Register/refresh this device's Expo push token: `{ token, platform: 'android'\|'ios'\|'web', device? }` (upsert into `app.push_tokens`). |

> `storage-signed-url` is **admin-only** (requires `reports.view`) — players never call it. See §5.

## 3. Player RPCs (PostgREST, publishable key)

These Postgres functions are callable via `POST /rest/v1/rpc/<fn>` (publishable key + user JWT):

| RPC | Purpose |
|---|---|
| `complete_profile(p_user_id, p_display_name, p_ff_uid, p_in_game_name, p_whatsapp_phone, p_avatar_path, p_referral_code_input)` | One-time profile setup. Creates `profiles` (server-generated `app_uid`, `referral_code`), `wallet_accounts`, `profile_stats`, and the `referrals` row when a referral code is supplied. Idempotent (returns existing profile). ⚠️ It is `SECURITY DEFINER` and takes a client-supplied `p_user_id` — the app must only ever pass its own `auth.uid()` and the backend must enforce that (see §6.1). |
| `register_for_tournament(p_tournament_id, p_profile_id, p_idempotency_key)` | Atomic registration: eligibility + capacity + slot + `tournament_entry` debit. **No sanctioned player-facing path — see §6.1.** ⚠️ The `app.*` RPCs were never revoked from PUBLIC execute (only the Super Key helpers were, in 0020), so they are technically callable via PostgREST with an arbitrary `p_profile_id` — that exposure must be revoked and replaced with a guarded Edge Function. |
| `mark_notification_read(p_notification_id, p_profile_id)` | Mark one notification read (RLS `notifications_self_update` also allows direct PATCH). |
| `get_wallet_me(p_profile_id)` | Balances `(available_balance, held_balance, total_balance)` — or simply `SELECT` from `app.wallet_accounts` (RLS self-read). |

## 4. Player reads via PostgREST + RLS (table → policy)

| Table | What the player can read |
|---|---|
| `app.tournaments` | Public read: all statuses except `draft`/`cancelled`. Includes `prize_distribution`, `score_rules`, `free_slot_*`. |
| `app.banners` | Public read: `active = true` within schedule window. |
| `app.reward_campaigns` / `app.reward_items` | Public read of `active` campaigns (weights visible for odds display). |
| `app.profiles` / `app.profile_stats` | Own row only. |
| `app.wallet_accounts` / `app.wallet_ledger` | Own row / own ledger entries (immutable history). |
| `app.registrations` | Own rows. |
| `app.match_results` / `app.prize_awards` | Own rows, results only when `published`/`corrected`. |
| `app.topup_requests` | Own rows (+ insert of a new `pending` request via RLS `topups_self_insert`). |
| `app.withdrawal_requests` / `app.withdrawal_methods` | Own rows; methods are full CRUD for the owner. |
| `app.reward_attempts` | Own rows. |
| `app.streak_days` / `app.streak_milestones` | Own rows (read-only; engine populates them). |
| `app.referrals` | Rows where the player is referrer **or** referred. |
| `app.card_share_events` | Own rows (+ insert). |
| `app.notifications` | Own inbox (read + mark-read). |
| `app.push_tokens` | Own tokens (full CRUD for the owner). |
| `app.topup_codes` | Only codes the player redeemed (self-read). |
| `app.rooms`, `app.rosters`, `app.settings`, `admin.*`, `audit.*` | **Never** via RLS — Edge Functions only. |

## 5. Admin endpoints (summary — Player App never calls these)

The Control app calls ~50 dash-prefixed functions: `admin-tournaments-create/update/cancel/preset/list/entrants/assign-roster/set-room/release-room`, `admin-results-get/save-draft/preview/publish/correct`, `admin-topups-list/review`, `admin-withdrawals-list/approve/mark-paid/reject`, `admin-wallet-correct`, `admin-rewards-campaigns/dashboard`, `admin-streaks-config/grant-freeze`, `admin-referrals-config/list/review`, `admin-players-search/get/note/restrict`, `admin-content-banners/announcement/featured`, `admin-notifications-send`, `admin-audit-query`, `admin-reports`, `admin-settings`, `admin-reconciliation`, `admin-share-report`, `admin-topup-codes-create/list/disable`, `storage-signed-url` (admin-only, `reports.view`), `owner-admins-*`, `owner-bootstrap`, `admin-request-access`, `admin-permissions-*`, `admin-auth-verify`, `admin-assignments-me`.

## 6. Known backend gaps (must be closed before/with the Player App build)

1. **Registration entry point (+ RPC exposure hardening).** There is no player-facing registration Edge Function, and the `app.*` RPCs (including `register_for_tournament`, `complete_profile`, `wallet_*`, `get_wallet_me`, `create_withdrawal_request`, `reward_paid_attempt`) retain Postgres's **default PUBLIC EXECUTE** — no migration revoked them — so they are callable via PostgREST by any role with an arbitrary `p_profile_id`/`p_user_id`. Fix: `revoke execute` on all `app.*` functions from `anon`/`authenticated`/`public`, then add a `tournaments-register` Edge Function (`requireUser` → eligibility checks → call the RPC with the secret key + `Idempotency-Key`) that enforces `p_profile_id = auth.uid()`.
2. **Streak engine.** Tables (`streak_days/milestones/freezes`) and config exist, but nothing records qualifying days or auto-awards milestone coins, and there is **no self-read RLS policy for `streak_freezes`** (only `streak_days`/`streak_milestones`) — the Streak screen needs freeze count. Fix: server logic (trigger or Edge Function) that appends qualifying events to `streak_days` in PKT, consumes freezes, credits milestone rewards idempotently, and exposes freeze balance (add `streak_freezes_self_read` or a computed endpoint).
3. **Push sender.** `app.push_tokens` is populated but no worker sends to FCM/APNs (Expo Push API). In-app inbox is live; push delivery is not.
4. **Referral auto-qualification.** Referral rows are created on signup with a code but stay `pending` until manual admin review; the spec's automatic "first qualifying action" reward is not yet implemented.
5. **Policy consent storage.** §6.2 of the spec requires recording accepted policy versions/timestamps; no server table exists yet (store locally in MVP or add a table).

## 7. Client integration notes

- Initialize Supabase with `EXPO_PUBLIC_SUPABASE_URL` + `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` and the encrypted `LargeSecureStore` adapter (see [engineering/04-client-and-session.md](engineering/04-client-and-session.md)).
- Use `callEdgeFunction()`-style helper that attaches `Authorization` + `Idempotency-Key` and normalizes `{ error: { code, message, retryable } }`.
- Fetch `app-config` once at startup (cached) for policies/links/maintenance/featured; check `app-version` for the update gate.
