# 06 — Notifications

## 1. Two channels

1. **In-app inbox (source of truth).** Every notification is persisted to `app.notifications` and shown in the app with unread/read state and PKT timestamps. Push delivery is treated as best-effort, not guaranteed.
2. **Push notifications** via **expo-notifications** (FCM/APNs underneath). The app registers its Expo push token with the `push-token-register` Edge Function (stored in `app.push_tokens`). A failed/expired push subscription never blocks the in-app message. *Server-side push delivery (actually sending from `app.push_tokens` to FCM/APNs) is a known backend gap — only the in-app inbox is live today.*

## 2. Required types
Security, registration confirmed, room released, tournament reminder, tournament changed/cancelled/refunded, result published, prize credited, top-up update, withdrawal update, reward result, streak milestone/freeze/at-risk, referral update, maintenance, broadcast.

## 3. Rules
- Deep-link to safe targets only (tournament, wallet request, result, streak, referral, policy).
- Never include room password, OTP, raw payment reference, payout account, Super Key, or wallet balance in push/broadcast text.
- Targeted vs broadcast: broadcasts require permission + confirmation; record sender, segment, template, send time, delivery outcome.
- Templating: admin composes from approved templates; sensitive values are injected only into in-app detail views, not push copy.
- Rate-limit and quiet hours per player preference where configurable.

## 4. Implementation notes
- Each device registers its Expo push token via `push-token-register` (POST `{ token, platform, device? }`), upserted into `app.push_tokens(profile_id, token)` with self-scoped RLS (`push_self_all`). Remove the token on logout.
- **Backend gap:** no sender exists yet — a future worker/Edge Function must read `app.push_tokens` and dispatch via the Expo Push API (or FCM directly) with retry/backoff. Until then the in-app inbox is the only delivery channel.
- Inbox rows are read/marked-read by the client via RLS (`notifications_self_read` / `notifications_self_update`) or the `mark_notification_read` RPC; Realtime can be used for live inbox updates.
