# 04 — Results, Wallet & Rewards

## Official results
After staff publish, the player sees: official placement/rank, official kills, points/score table (if configured), standings (where designed), prize amount, prize wallet transaction link/status, publication time, and a **Share result / Share win** action (only for non-void/corrected-current results). Two prize modes are configured per tournament: **placement top-N** (`prize_distribution`) or **reward-per-kill** (`score_rules.kill_reward`) — the result screen renders the prize line accordingly. Players cannot submit or edit kills/placement/points. Results stay draft until published; corrections are auditable and use compensating ledger entries; dispute routes go to WhatsApp support.

## Profile statistics (official, aggregated)
Tournaments joined, completed events, top placements/wins, total official kills, total prize/coin value subject to policy. Never used to calculate financial balance.

## Wallet
- Balances: **available**, **held** (e.g., pending withdrawal), **pending** (top-ups/withdrawals in flight).
- Whole-integer coins; balance derived/verified against the immutable server ledger; client never writes balance.
- Wallet screen shows balances, coin/PKR explanation, Buy/Withdraw/History actions, reverse-chronological ledger (amount, type, status, PKT time, reference, linked event), and policy links.

## Top-up (manual)
1. Choose enabled method (Easypaisa/JazzCash).
2. Read owner-configured official instructions (only when `cash_operations_enabled`; otherwise simulated/test).
3. Pay outside the app and enter the **payment transaction ID/reference** (no screenshot in MVP) and amount; select method.
4. Request is created as **pending**; no immediate credit.
5. Receive Approved/Rejected/Expired status + rejection reason in the app and notification.
- UI explains coins are not credited until authorized approval; idempotency prevents duplicate submissions.

## Top-up code redemption (admin-issued codes)
- Admins (owner/finance) can generate one-time **6-digit numeric top-up codes** for any amount; the player redeems them in the Wallet.
- Flow: Wallet → Redeem Code → enter 6-digit code → `topup-codes-redeem` Edge Function → atomic one-time claim → **instant `topup_code` credit** to available coins.
- A code can be redeemed **exactly once by exactly one player** (409 "already redeemed" if reused; disabled codes rejected). Idempotency prevents double-credit on retry.
- Show the credited amount and the new balance; the credit appears in Transaction History as a `topup_code` entry. Rejection reasons are safe/generic (no fraud details).

## Withdrawal (manual)
1. Choose payout method (Easypaisa/JazzCash).
2. Enter payout phone and amount only.
3. Backend validates balance, limits, verification, and pending rules; moves amount **available → held** atomically.
4. Staff manually pay; status becomes Pending Review → Approved → Paid (or Rejected/Cancelled returns held → available).
- UI shows available, requested, held, and remaining amounts; 24-hour review/payment target; masked payout history; clear return-of-held on rejection; support route.
- Policy decisions (purchased vs prize coin eligibility, min/max, fee, daily/weekly/monthly limits, rails, dispute) are owner-configured and required before enabling withdrawals.

## Rewards — Spin Wheel
- MVP rewards are **Rush Coins only**.
- Entry methods (owner-configured): **validated rewarded ad** or **paid attempt (5 coins)**.
- Show attempt state, method, cooldown, daily limit; choose route; spin animation only after the backend selects/reserves the result; show result and wallet status; show terms/limits.
- Backend uses secure random selection; client only animates. Ad completion requires provider server-side validation (SSV) — never trust a client "ad watched" claim. Paid attempt is an atomic debit + reward with retries safe. Ad failure does not charge coins. Rate-limit/risk-check; persist source, campaign, result, ledger links, risk metadata.

## Ads mediation
- Use **Unity LevelPlay** (or AppLovin MAX) mediation with **Google AdMob + Unity Ads** at launch; add AppLovin/Mintegral after volume.
- Native mediation SDKs require an Expo development build (not Expo Go).
- All rewards are granted only after the network's server-side verification callback hits `rewards/ssv-callback`.
- Ads grant non-redeemable test coins until `cash_operations_enabled` is on.
