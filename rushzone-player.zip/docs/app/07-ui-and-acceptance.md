# 07 — UI, Quality & Acceptance

## UI rules
- Dark espresso theme only; warm layered surfaces; orange for the single primary action per screen; gold only for coins/prizes/streaks; status colors paired with icons/labels.
- Editorial serif display headings; Inter/system sans for UI; 14–16px body; tabular figures for money; WCAG AA contrast on dark surfaces.
- Cards 12px, buttons/inputs 8px, badges may be pills; 44px touch targets; warm hairline borders and soft shadows; no neon glows, no pure-black surfaces.
- Hero/sunset imagery is color-treated to fade into the espresso canvas.
- Every screen includes the sunset stripe above the bottom nav.

## States & reliability
- Intentional loading/skeleton, empty, offline, retry, and error states for every async screen.
- All times UTC-stored, PKT-displayed.
- Idempotency keys for all money/registration/reward actions; atomic DB transactions.
- No wallet/result/balance is trusted from the device; strict server validation of IDs and amounts.
- Rate limiting on OTP, registration, top-up, withdrawal, reward, and support endpoints.

## Security
- HTTPS/TLS only.
- Secure token/session storage (`expo-secure-store`).
- Publishable key (`sb_publishable_…`) only in the app; no secret/legacy keys.
- RLS enforced; privileged actions via Edge Functions.
- No sensitive data in share cards, push, or WhatsApp URLs.

## MVP acceptance criteria
- [ ] Email OTP auth via Supabase Auth (built-in email delivery); required WhatsApp number in profile but not used for login.
- [ ] Policies accepted; Free Fire profile completed (with 4-digit in-app UID).
- [ ] Browse/filter published tournaments in PKT.
- [ ] Enter individually once; multi-tap/duplicate entry prevented.
- [ ] See room credentials only after authorized release.
- [ ] See only staff-published kills/results/prizes.
- [ ] Wallet shows immutable activity, available/held balances.
- [ ] Create manual top-up request; create withdrawal (available → held, returned on reject/cancel).
- [ ] **Redeem an admin-issued 6-digit top-up code for an instant coin credit (one-time use).**
- [ ] Server-controlled spin rewards via validated ad or 5-coin paid attempt (with mediation + SSV).
- [ ] GitHub-style streak heat-map; qualifying actions mark PKT days; milestone coins granted atomically.
- [ ] Generate/share dark-theme marketing cards to WhatsApp (Status/chat) and Instagram Stories/feed without leaking sensitive data.
- [ ] Persistent in-app notifications + push via expo-notifications + `push-token-register` (in-app inbox authoritative) + official WhatsApp support.
- [ ] Dark espresso design system with sunset stripe on every screen.
- [ ] Real-money actions disabled until `cash_operations_enabled` is approved.
