# 00 — Player App: Product & Scope

## Purpose
Rush Zone lets Free Fire players in Pakistan create a verified account, browse tournaments, register individually, receive private room details after authorized release, view official results, manage Rush Coins, submit manual top-up/withdrawal requests, earn rewards (Spin Wheel + daily streaks), refer friends, and contact official WhatsApp support.

> Find a tournament, join with confidence, receive the correct room details, see verified outcomes, and track every coin movement in one trustworthy app.

## MVP model
- Players join **individually**; no player-created teams in MVP (staff may internally group Duo/Squad entrants).
- Staff create/manage tournaments and enter all results. Players cannot create events, enter kills, assign wins, or edit balances.
- Payments and withdrawals are manual-review workflows.
- 1 Rush Coin = PKR 1; integer coins only.
- The player app is separate from **Rush Zone Control** (admin).

## Launch gate
Build and beta-test now with test/non-redeemable coins. The server flag `cash_operations_enabled` stays off until documented approval; when off, real-money purchases, cash-equivalent withdrawals, prize payouts, live Easypaisa/JazzCash payout details, and cash-equivalent rewarded ads are disabled.

## What a player can/cannot do
**Can:** email-OTP sign-in; update profile; browse public tournaments; register individually; view own registrations, released rooms, official outcomes, and official stats; submit top-up/withdrawal requests when enabled; use rewards; read notifications; open WhatsApp support; share marketing cards; refer others.

**Cannot:** create/edit/cancel tournaments; set prices/pools/rules/capacity/maps/rooms; add own kills/placement/points/prize; change balance or history or other players' data; transfer coins to other players in MVP; see admin data, payment proof, payout info, or unreleased rooms.

## Platform
- React Native + Expo, Android-first (SDK 24+), iOS-ready architecture.
- Distributed as a side-loaded APK in MVP (no Play Store).
- 390×844 design target, 44px touch targets, safe-area/keyboard aware, offline/empty/error/retry states, PKT everywhere.

## Theme
**Dark espresso only** (see `../shared/07-design-tokens.md`). No light theme in MVP.
