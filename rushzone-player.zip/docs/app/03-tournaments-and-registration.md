# 03 — Tournaments & Registration

## Discovery
- List supports filters: status (upcoming, registration open, full, room released, live, results pending, completed), mode, map/event type, scheduled date/time, free/paid, entry price range.
- Cards show cover, title, mode/map, PKT time, entry fee, prize summary, entrants/capacity, status.

## Lifecycle shown to players
`Scheduled → Registration Open → Registration Full/Closed → Room Released → Live → Results Pending → Completed` (alternative: Cancelled). Appropriate info only at each state; no room creds before release.

## Detail page
Title, cover, mode, map, rounds, capacity; reg open/close and match start in PKT; entry fee in coins + PKR wording where policy permits; prize pool/distribution and score rules; rules, cancellation/refund policy, support direction; registered count/capacity; individual-entry statement; Join/Unavailable action.

## Registration model
- Every player joins individually. No player-created teams, captains, invitations, or team chat in MVP.
- For Duo/Squad/custom events, staff may internally assign entrants to rosters; players see their result/room but don't manage teams.

## Eligibility (checked before confirm and again atomically)
Authenticated email OTP session; mandatory profile/FF UID/WhatsApp complete; tournament registration open; not suspended/banned; meets eligibility rules; capacity available; no existing active registration in same event; sufficient **available** coins for paid events.

## Join confirmation
Shows exact entry cost, current balance, estimated balance after, event title/date/mode, rules checkbox, and statement that room details are delivered after authorized release.

## Atomic registration (Edge Function)
1. Re-check eligibility/capacity with row lock.
2. Assign a slot number (slot bottom sheet shows seats).
3. Create `registrations` with fee snapshot.
4. Debit entry fee via immutable ledger entry.
5. Return confirmation.
- Idempotency key prevents double-charge on retaps/retry/reinstall.
- Full event / insufficient balance creates no partial debit.
- Cancellations/refunds appear as linked ledger entries.

## Slot system
- Tapping Register opens a Modal Bottom Sheet with available slots/seats (seat count set per tournament by admin).
- When all slots are booked (or match starts), one randomly selected slot is highlighted gold; that player receives a **full registration refund** as a linked `slot_refund` ledger credit and joins free. All other entries remain normal.
- The gold slot is selected server-side; clients only render the result.

## My Tournaments / rooms
- Sections: Upcoming, Room Released, Live/Results Pending, Completed, Cancelled.
- Room content (as configured): Room ID, password, server/region, check-in guidance, match instructions, safety warning not to share credentials.
- Only confirmed eligible registrants can read room credentials, and only after release. Passwords never appear in public cards, push messages, or listings. Release triggers a push + in-app notification.
