# 05 — Streaks, Referrals & Share Cards

## Daily streak system (GitHub-style)

> **Backend status (as of the admin build):** tables (`streak_days/milestones/freezes`), the config endpoint (`admin-streaks-config`) and freeze-granting (`admin-streaks-grant-freeze`) exist, but the **engine that records qualifying days and auto-awards milestones is not implemented yet**. The client should build against the data model below and treat the heat-map/streak values as server-computed; the qualifying-action recorder is a known backend task.

### What counts as an active day (PKT calendar day)
At least one **server-confirmed** qualifying action that PKT day:
- Completes a rewarded-ad spin or a paid spin.
- Confirms a tournament registration.
- Plays in a tournament that goes Live.
- Has an official result published.
- App-open alone does **not** count. Multiple actions in a day raise `intensity` (0–4) but don't add extra days.

### What players see
- Current streak, longest streak, total active days, this-month count.
- **Heat-map calendar** of the last ~17 weeks: 7 columns of day tiles shaded 0–4 in warm gold/amber on the espresso canvas; weekday/month labels; today outlined in cream/gold; future dates disabled.
- Next milestone progress ("3 more days to 7-day reward"); claimed tiers show a check.
- Compact Home widget (flame + count + 7-day row) and a full Streak screen (from Home and Profile).
- "Streak at risk" prompt appears in the evening (PKT) when today has no qualifying action, deep-linking to a qualifying action; dismissible and not anxiety-driven.

### Freezes
A limited number of streak freezes (admin-configured) protect a missed day; consumed automatically at end of day and shown as a frosted tile. Without a freeze, current streak resets (longest/total are preserved).

### Rewards
- Admin-configured milestone tiers (e.g., days 3/7/14/30/60/100) grant Rush Coins via the standard atomic ledger credit; idempotent (reinstall/re-login/clock change can't re-claim).
- When `cash_operations_enabled` is off, rewards are non-redeemable test coins.
- The client never writes streak state; the server computes all values from `streak_days` using PKT day boundaries (device clock is not trusted).

## Referral program
- Each player gets a unique referral code (separate from the 4-digit in-app UID) and shareable link/card.
- On a new player's sign-up + email OTP + profile setup + (configurable) first qualifying action, both referrer and referred player receive server-controlled coin rewards.
- Rewards are admin-configured (amounts, trigger, caps, anti-fraud). Self-referral, same-device abuse (one device = one account), and loop referrals are blocked; suspicious attribution holds the reward pending review.
- Refer screen shows code, share buttons/card, successful/pending/rewarded counts, and terms. Links use opaque codes, not sensitive tokens.

## Shareable marketing cards
- Generate on-brand vertical **9:16 (1080×1920)** and square **1:1 (1080×1080)** cards for:
  1. Tournament result
  2. Win / top placement
  3. Prize credited
  4. Streak milestone (with heat-map motif)
  5. Spin win
  6. Referral/join invite
  7. Profile/flex
- Rendered in the dark espresso + sunset system with the Rush Zone lockup, sunset stripe, mountain silhouette, and editorial serif achievement type.
- Save to cache/share sheet (Expo Sharing + MediaLibrary with runtime permissions). Share to WhatsApp (chat + Status), Instagram Stories/feed via system share intents, and a generic "More" fallback. Image + optional safe caption (tagline; referral code/link only on the referral card).
- **Never include** room ID/password, OTP, phone number, Free Fire UID, wallet balance, transaction IDs, or payout details. The referral card is the only one showing a referral code/link, with an explicit confirm step.
- Cards are generated from **server data only** — the client can't fabricate kills/placement/prize/streak. Voided/corrected results don't offer a share card. Already-shared images can't be recalled, but in-app previews always reflect authoritative data.
- `card_share_events` records type, channel, and linked entity for attribution without storing recipient data.
