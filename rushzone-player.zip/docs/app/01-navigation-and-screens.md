# 01 — Navigation & Screens

## Bottom navigation
`Home · Tournaments · Rewards · Wallet · Refer · Profile`

## Root flow
```
Splash / Maintenance / Force-update
→ Email Login
→ Email OTP Verification
→ Policy Consent (web URL, owner-updatable)
→ Profile Setup (display name, FF UID, in-game name, WhatsApp phone, avatar)
→ Main tabs (Home)
```

## Routes by tab

### Home
- Personalized greeting + avatar shortcut
- Image banner slider (admin-managed; each banner optionally links to a URL)
- Wallet summary (available / held / pending when enabled)
- Quick actions: Buy Coins, Withdraw, Rewards
- **Daily streak widget** (flame + current streak + 7-day mini row → Streak screen)
- Featured tournament hero (cover color-treated for dark canvas)
- Starting Soon / Upcoming list
- Announcement/promotion slot (admin-controlled)
- Browse-all tournaments link

### Tournaments
- Tournament list with filters: status, mode (Solo/Duo/Squad/Custom), map, date, free/paid, price range
- Tournament card: cover, title, mode/map, PKT time, entry fee, prize summary, entrants/capacity, lifecycle badge
- Tournament detail: cover, mode/map/rounds/capacity, reg open/close and match start (PKT), entry fee + PKR wording, prize distribution and score rules, rules/cancellation policy, registered count/capacity, individual-entry statement, Join/Unavailable action
- Join confirmation: exact cost, current balance, estimated balance after, event summary, policy checkbox, note that room details are delivered later
- Slot bottom sheet: available seats; one free-slot winner highlighted (gold) = refunded registration
- My Tournaments: tabs Upcoming / Room Released / Live–Results Pending / Completed / Cancelled
- Room Details (only after release): Room ID, password, server/region, check-in guidance, instructions, safety warning
- Official Result: placement, kills, points, standings (where applicable), prize, prize transaction link, published time, **Share result/win**

### Rewards
- Spin Wheel (available attempts, entry method, cooldown, daily limit; ad or 5-coin paid route when enabled)
- Spin result + wallet link + **Share spin**
- Reward History

### Wallet
- Available / held / pending balances, coin/PKR explanation
- Quick actions: Buy Coins, Withdraw, History
- Transaction history (reverse chron): amount, type, status, PKT time, reference ID, linked event
- Buy Coins / Top-up request: choose method (Easypaisa/JazzCash), enter amount and **payment transaction ID/reference** (no screenshot in MVP), see status Pending/Approved/Rejected/Expired with rejection reason
- **Redeem top-up code**: enter an admin-issued 6-digit code → instant `topup_code` coin credit (idempotent; clear errors for already-redeemed / disabled / invalid codes)
- Withdrawal request: choose method, enter phone (payout account) and amount; see available/held/remaining; 24-hour target wording; masked history; status Pending Review/Approved/Paid/Rejected/Cancelled
- [Phase 2] Send Coins to another player (disabled in MVP)

### Refer
- Referral code + link, shareable invite card, successful/pending/rewarded referral count, reward terms

### Profile
- Avatar, display name, in-app UID, FF UID, in-game name, masked email, masked WhatsApp phone
- Edit profile (email/phone changes require re-verification/re-auth where applicable)
- Statistics (official aggregated values only)
- Streak summary → full Streak screen
- **Share profile / invite card**
- Notifications inbox
- Policies (owner-updatable URL)
- Official WhatsApp Support (floating button across app too)
- Logout

## Global behaviors
- Sunset stripe above the bottom nav on every screen.
- Loading / skeleton, empty, offline, retry, and error states designed intentionally.
- Deep links from notifications land on the relevant safe screen.
- Force-update / maintenance screen from the `app/version` endpoint.
