# 06 — Notifications & Support

## In-app inbox (source of truth)
- Persistent inbox in Profile, with unread/read state and PKT timestamps.
- Types: security, registration confirmed, room released, tournament reminder, tournament changed/cancelled/refunded, result published, prize credited, top-up/withdrawal updates, reward result, streak milestone/freeze/at-risk, referral update, maintenance, broadcast.
- Deep-link to safe screens; never include room passwords, OTPs, raw payment references, payout details, or balances.

## Push
- **expo-notifications** (FCM/APNs underneath); each device registers its Expo push token via the `push-token-register` Edge Function. Best-effort delivery — the in-app inbox is authoritative.
- Note: the server-side push sender (sending from `app.push_tokens` to FCM/APNs) is a known backend gap; in-app inbox works today.
- Tapping a push opens the relevant deep link.
- Device subscription registered per device; failures logged and retried.

## WhatsApp support
- A floating/support button opens an owner-configured official WhatsApp deep link.
- Prefilled text contains only safe context (e.g., player in-app UID / event title when permitted).
- Never include OTPs, room password, wallet balance, transaction screenshots, or payout account in the URL.
- Show support hours/expectations when provided.

## Email
Transactional email (OTP) is delivered by **Supabase Auth's built-in email service** (`signInWithOtp`/`verifyOtp`); the app never sends email itself. No marketing email in MVP.
