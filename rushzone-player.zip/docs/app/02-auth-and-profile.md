# 02 — Auth & Profile

## Email OTP login
- Sign in with a 6-digit **email OTP delivered by Supabase Auth's built-in email service** (`auth.email.otp` enabled in `config.toml`, `enable_confirmations = true`). The client uses `supabase.auth.signInWithOtp({ email })` to request the code and `supabase.auth.verifyOtp({ email, token, type: 'email' })` to verify — no custom OTP Edge Function and no OneSignal.
- 6-digit code, ~10 min expiry, single use. On verification Supabase returns a session (creating the user if new).
- Generic errors; no account-existence disclosure.
- Rate limiting by email, device, and IP; resend cooldown.
- Session persistence uses the encrypted `LargeSecureStore` adapter (AES-256 key in `expo-secure-store`, encrypted session blob in AsyncStorage). A raw/unencrypted session must never be written to plain AsyncStorage.
- One device per account policy for sensitive actions (enforced server-side).

## Supabase client setup in the app
The exact, copy-paste-ready client (with encrypted session storage, URL polyfill, auto-refresh, and process lock) is in **[`../shared/engineering/04-client-and-session.md`](../shared/engineering/04-client-and-session.md)**. Summary of the rules:
- Initialize with `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` (`sb_publishable_…`, never the legacy `anon` JWT).
- Persist the session with a `LargeSecureStore` adapter (a random AES-256 key in `expo-secure-store`, encrypted session in AsyncStorage — SecureStore alone has a 2048-byte limit).
- Include `react-native-url-polyfill`, `lock: processLock`, and the AppState start/stop auto-refresh listener.
- The mobile app contains **only** the publishable key. No `sb_secret_…`, no `service_role`, no legacy `eyJ…` key anywhere in the bundle or repo.
- RLS is the gate for all direct reads; privileged actions call Edge Functions with the user's JWT.

## Policy consent
Player accepts current Terms, Privacy, Tournament Rules, Wallet/Withdrawal policy (when wallet enabled), and Reward Terms (when rewards enabled). Accepted version/timestamp/device metadata stored; material changes require re-consent. The policy text itself is loaded from an owner-configured URL.

## Profile setup (required before registration)
| Field | Rule |
|---|---|
| Display name | 2–30 chars, allowed character set |
| Free Fire UID | Required; format validated; unique across active accounts |
| In-game name | Required |
| Email (login) | Verified by OTP; changes require re-verification |
| WhatsApp phone | Required Pakistan `+92…` E.164; format validated; not a login factor; masked in UI |
| Avatar | Optional; compressed/resized (≤500 KB), uploads to `avatars` bucket |

Server generates a unique 4-digit **in-app UID** (distinct from FF UID and phone).

## Safeguards
- FF UID cannot be linked to multiple active accounts.
- Historical stats/results cannot be edited from the profile.
- Profile changes with tournament/payout impact may require staff review.
- Aggregated stats are derived from official results, not used as financial source of truth.
- WhatsApp phone is stored securely and masked except to finance-authorized admins.
