# Rush Zone — Player Mobile App Requirements

**Document status:** Development-ready MVP specification

**Application:** Rush Zone Player App

**Platform:** React Native + Expo, Android-first, iOS-ready architecture

**Primary market:** Pakistan

**Primary language:** English-first

**Time zone:** Pakistan Standard Time (`Asia/Karachi`, PKT)

**Wallet unit:** 1 Rush Coin = PKR 1

**Authentication:** Email OTP login (free, via **Supabase Auth's built-in email OTP**). A Pakistan WhatsApp mobile number is a **required profile/contact field** used for WhatsApp support identity and Easypaisa/JazzCash payouts, but it is **not** a login or OTP factor in MVP.

**Application audience:** Free Fire players / tournament participants

---

## 1. Product purpose

Rush Zone is a mobile tournament platform for Free Fire players in Pakistan. The Player App lets a player create a verified account, browse tournaments, register individually, receive private room details, view official results entered by staff, manage Rush Coins, submit manual payment/withdrawal requests, earn controlled reward coins, and contact official support.

### Player value proposition

> Find a tournament, join with confidence, receive the correct room details, see verified outcomes, and track every coin movement in one trustworthy app.

### MVP product model

- Players join tournaments **individually**.

- Admin staff create/manage tournaments and enter all official results.

- Players cannot create tournaments, enter official kills, assign winners, or edit a wallet balance.

- Payments and withdrawals are **manual-review workflows** in MVP.

- A Player App is separate from the Owner/Admin mobile app, **Rush Zone Control**.

---

## 2. Launch boundary and release gate

### Build now with test/non-redeemable coins

The app can be developed and closed-beta tested immediately with test coins, simulated top-ups, and simulated withdrawals.

### Do not enable real-money operations until approved

The following functions must be protected by a server feature flag, `cash_operations_enabled`, and remain disabled until the business has documented approval:

- Real money coin purchases.

- Cash-equivalent coin withdrawals.

- Prize payouts.

- Easypaisa/JazzCash/bank collection or payout details.

- Rewarded-ad flows that issue cash-equivalent rewards.

---

## 3. Player roles and permissions

### 3.1 Player

A Player has a normal tournament account.

**Player can:**

- Sign in with email OTP (one-time passcode sent to their email).

- Create and update permitted profile fields, including a required Pakistan WhatsApp phone number for support identity and payout details.

- Browse public tournaments.

- Refer others using their referral code to earn a reward; both the referrer and the referred player receive a reward (see §12C).

- Enter an eligible tournament as an individual.

- View their own registrations, room details after release, and official outcomes.

- View official profile statistics.

- Submit top-up proof and withdrawal requests when enabled.

- Use eligible rewards.

- Read notifications and open official WhatsApp support.

- Each user gets a unique in-app UID (4 digits), used for display and safe sharing (distinct from their Free Fire UID and phone number).

**Player cannot:**

- Create/edit/cancel a tournament.

- Set entry prices, prize pools, rules, capacity, maps, or room credentials.

- Add/edit their own kills, placement, points, winner status, or prize.

- Directly change balance, transaction history, registration state, or other players' data.

- Transfer coins to another player in MVP.

- See admin data, payment-proof files, payout information, security settings, or private room data before eligibility/release.

### 3.2 System-controlled actions

The mobile client must never decide or write sensitive outcomes. The backend is authoritative for:

- Tournament entry eligibility and coin debit.

- Tournament capacity and duplicate-registration prevention.

- Wallet balance, held balance, ledger entries, prizes, refunds, and rewards.

- Official results, kills, standings, and profile statistics.

- Room-detail eligibility and release time.

- Notification history.

- User restriction/ban status.

---

## 4. Visual design system

The Player App uses an editorial **mountain-sunset** visual system adapted for Rush Zone, rendered on a **dark, warm espresso theme**. This is the only theme in MVP (no light-mode toggle). The goal is a premium, non-slop look: deep coffee/charcoal-brown surfaces rather than generic pure-black "AMOLED" or harsh gaming neon, with warm sunset accents providing the only strong color.

### 4.1 Design direction

- **Dark, warm, layered surfaces.** Base canvas is a deep espresso/charcoal brown. Elevated surfaces (cards, sheets, nav bar) step slightly lighter and warmer, never pure grey and never pure `#000000`. The palette reads as roasted coffee / dark walnut, not as flat dark mode.

- **Sunset imagery glows on dark.** Cinematic mountain-sunset artwork is used for high-emotion moments — Welcome/auth, featured tournament, tournament cover, rewards spotlight, and milestone/streak celebrations — and is composited so it naturally fades into the dark espresso canvas.

- **Saturated orange** is reserved for primary actions and active/selected states (Join, Confirm, Buy, Spin).

- **Warm gold** is reserved for coins, prizes, streaks, and celebratory highlights — it must feel metallic/warm against the brown, not neon.

- **Cream text** on dark surfaces for primary content; muted tan/stone for secondary/metadata text. Never use low-contrast grey-on-black.

- **Warm amber-tinted panels** (dark caramel, still dark) hold wallet, form, policy, and feature information instead of the earlier cream panels.

- Cards use a sober **12px radius**. Buttons and inputs use an **8px radius**. Pill shapes are reserved for small status badges only.

- Every mobile screen includes a thin horizontal **sunset stripe** above the bottom navigation:

```text

deep red → saturated orange → warm gold → soft amber fade into espresso

```

- Subtle warm hairline borders and 1–3px soft warm shadows separate layers; avoid harsh 1px white borders or neon glows.

### 4.2 Visual tokens

| Token | Direction |

|---|---|

| Canvas (base) | Deep espresso / charcoal-brown, approximately `#1C140F` |

| Surface (elevated card/sheet) | Slightly lighter coffee brown, approximately `#261B14` |

| Surface raised (nav bar, modal) | Warm dark mocha, approximately `#2F2219` |

| Inset / subtle panel | Dark caramel tint, approximately `#33251A` |

| Primary text (on dark) | Warm cream, approximately `#F6ECDC` |

| Secondary text / metadata | Muted tan/stone, approximately `#B9A488` |

| Disabled text | Muted cocoa, approximately `#7A6853` |

| Primary action | Saturated sunset orange, approximately `#ED5A1F` |

| Primary pressed/emphasis | Deep orange, approximately `#C24716` |

| Coin / streak / highlight | Warm sunset gold, approximately `#F4B826` |

| Reward/celebration glow | Soft amber, approximately `#FFC46B` |

| Success | Muted forest/emerald green, approximately `#4F9A66` |

| Danger / error | Brick red (warm, not neon), approximately `#C8493B` |

| Border / hairline | Warm cocoa hairline, approximately `#4A382A` |

| Divider | Very faint warm line, approximately `#3A2B20` |

| Backdrop scrim | Warm black at ~60–70% opacity over canvas |

| Display typography | Editorial serif style such as PP Editorial Old; fallback Georgia/Times New Roman |

| UI typography | Inter; fallback system sans-serif |

**Color usage rules**

- Orange is for the single primary action on a screen only; do not paint whole cards orange.

- Gold means value/milestone (coins, prizes, streaks) — never use it for ordinary buttons.

- Status colors (success/danger) must always pair with an icon/text label, never color alone.

- Large photographic or illustrated hero art must be color-treated to sit on the espresso canvas (multiply/gradient fade) so it never looks like a pasted-on light rectangle.

### 4.3 Typography rules

- Large display headings use the editorial serif in warm cream, with tight leading and strong whitespace.

- Interface labels, body copy, forms, buttons, lists, and numeric detail use Inter/system sans.

- Use readable 14–16px body text in the actual app. Numeric/coin values may use a tabular/monospaced figure style for alignment.

- Use uppercase micro-labels only for metadata/status, not for long content.

- Use high contrast for financial values and time-sensitive room information (cream primary text; gold only for the numeric value when celebratory).

- Body text must meet WCAG AA contrast on the espresso canvas; secondary text must remain legible (avoid `#7A6853` or lighter for anything important).

---

## 5. Application navigation

### 5.1 Root navigation

Player App bottom navigation:

```text

Home · Tournaments · Rewards · Wallet · Refer · Profile

```

### 5.2 Main routes

```text

Splash / Maintenance

→ Email Login

→ Email OTP Verification

→ Policy Consent -- (It will be webpage given as url -- this url can be updated by the owner)

→ Profile Setup (Display name, Free Fire UID, in-game name, required WhatsApp phone number, optional avatar)

→ Home

Home

--> A slider of images these banner images are clickable if has url [it can be empty] these can be updated edited by the admin

--> Daily streak widget (flame + current streak + 7-day mini row) → Streak screen (heat-map, tiers, freezes)

→ Tournament List

→ Tournament Detail

→ Join Confirmation

→ My Tournaments

→ Room Details

→ Official Result

--> Share Result / Share Win marketing card (WhatsApp Status, Instagram Stories, etc.)

Wallet

→ Transaction History

→ Buy Coins / Top-up Request [User give the payment id that will be verified by admin no screenshot given stuff]

→ Redeem Top-up Code [6-digit admin-issued code → instant coin credit]

→ Withdrawal Request

→ [Phase 2] Send Coins to another player (disabled in MVP; player-to-player coin transfer is out of scope per §18) 

Rewards

→ Spin Wheel

→ Spin Win → Share Spin card

→ Reward History

Profile

→ Profile Edit

→ Statistics

--> Streak summary (opens full Streak screen)

--> Share Profile / Invite card

→ Notifications

→ Policies [(It will be webpage given as url -- this url can be updated by the owner)]

→ Official WhatsApp Support

--> Logout

```

### 5.3 Global mobile requirements

- Design target: 390 × 844 Android viewport; responsive to common Android devices.

- Minimum usable touch target: 44 × 44px.

- Respect Android safe areas, keyboard behavior, offline/retry states, and slow mobile connections.

- Show persistent in-app notification history; push messages are not treated as guaranteed delivery.

- All tournament and wallet times render in PKT.

---

## 6. Authentication, onboarding, and account profile

### 6.1 Email OTP authentication (login)

**Login flow**

1. Player enters their email address.

2. App normalizes/validates the email format.

3. Backend (Supabase Auth, `auth.email.otp`) sends a one-time passcode (OTP) to that email via Supabase's built-in email service.

4. Player enters the 6-digit code.

5. Backend validates the code and either creates an account or signs in to the existing account.

**Requirements**

- OTP is required before paid tournament actions, wallet actions, or sensitive profile changes (re-authenticate when the session is stale).

- Rate-limit OTP send, resend, and verification attempts by email, device, and IP where possible.

- Show generic, helpful errors without exposing account-existence or fraud data.

- Mask/obscure the email address in normal profile views where appropriate (e.g., `a***@gmail.com` in summaries).

- OTP codes are short-lived (e.g., 5–10 minutes) and single-use; the backend enforces expiry and attempt limits.
- OTP delivery is handled by **Supabase Auth's built-in email OTP** (`signInWithOtp` / `verifyOtp` in `config.toml`; `enable_confirmations = true`). There is no custom OTP Edge Function and no OneSignal. Verification happens server-side and returns a Supabase Auth session.

- Account recovery flows through email OTP and, where needed, the approved support process.

- One device can have only one account.

### 6.1A Required WhatsApp phone number (not a login factor)

- A Pakistan WhatsApp mobile number is a **required profile/contact field**. It is used for:
  - Official WhatsApp support identity/context.
  - Easypaisa/JazzCash withdrawal payout details (when withdrawals are enabled).
  - Future WhatsApp OTP as a possible second channel (not in MVP).

- The WhatsApp number is **not** used for login OTP in MVP, and the app does not send a phone OTP.

- The number is normalized to E.164 format (`+92…`) and stored securely; masked in normal profile views.

- The number must be a valid Pakistan mobile number. It is validated for format only in MVP; WhatsApp/SMS OTP verification could be added later via a future OTP channel.

### 6.2 Policy consent

Player must accept current versions of:

- Terms of Use.

- Privacy Policy.

- Tournament Rules.

- Wallet and Withdrawal Policy, when wallet is enabled.

- Reward Terms, when rewards are enabled.

Store accepted version, timestamp, and appropriate session/device metadata. If a material policy changes, require re-consent before relevant actions continue. *(Backend note: no server table records consent yet — store locally in MVP or add a `policy_consents` table; see shared/04 §6.)*

### 6.3 Profile setup

Required before tournament registration:

| Field | Requirement |

|---|---|

| Display name | Required; validated length and allowed characters |

| Free Fire UID | Required; validated format and duplicate-use policy |

| In-game name | Required |

| Email (login) | Verified via email OTP; stored securely; cannot be changed without re-verification |

| WhatsApp phone | Required Pakistan mobile number (`+92…`), E.164 format, stored securely and masked in UI |

| Avatar | Optional image upload; compressed/resized |

### 6.4 Profile data safeguards

- A Free Fire UID cannot be actively linked to multiple accounts.

- Player cannot edit historical result/stat values from their profile.

- Profile changes with tournament or payout impact can require staff review.

- Player can view official profile stats, but aggregated stats are derived from match results, not used as the source of truth.

---

## 7. Home and tournament discovery

### 7.1 Home screen requirements

Home contains:

- Personalized greeting and avatar shortcut.

- Image slider (Banners)

- Wallet balance summary, available/held/pending state where wallet is enabled.

- Quick actions: Buy Coins, Withdraw, Rewards.

- Daily streak widget: flame/current-streak count, a 7-day mini row, and progress to the next milestone; opens the full Streak screen. Shows a gentle "streak at risk" prompt in the evening (PKT) when today has no qualifying action.

- Featured tournament hero card with visual tournament cover, color-treated for the dark espresso canvas.

- Starting Soon / Upcoming tournament list.

- Announcement/promotion slot controlled by admin.

- Clear button/link to browse all tournaments.

### 7.2 Tournament discovery list

The Tournament list supports filtering by:

- Status: upcoming, registration open, full, room released, live, results pending, completed.

- Mode: Solo, Duo, Squad, Custom.

- Map/event type.

- Scheduled date/time.

- Free/paid event.

- Entry price range.

### 7.3 Tournament card minimum information

- Tournament cover thumbnail.

- Name/title.

- Game mode and map.

- Scheduled PKT date/time.

- Entry fee in Rush Coins.

- Prize summary.

- Participant count and capacity.

- Current lifecycle status.

### 7.4 Tournament lifecycle visible to player

```text

Scheduled

→ Registration Open

--> Available slots

→ Registration Full / Registration Closed

→ Room Released

→ Live / In Progress

→ Results Pending

→ Completed

Alternative: Cancelled

```

The Player App shows only appropriate information at each state. For example, room credentials are unavailable before Room Released.

---

## 8. Tournament detail and individual registration

### 8.1 Tournament detail page

Display:

- Title, visual cover, game mode, map, rounds, and player capacity.

- Registration opening/closing time and match start time in PKT.

- Entry price in whole coins and PKR equivalent language where policy permits.

- Prize pool, placements/prize distribution, and score rules where applicable.

- Tournament rules, cancellation/refund policy, and support direction.

- Current registered count/capacity.

- Individual-entry statement.

- Current status and clear Join/Unavailable action.

### 8.2 MVP registration model

- Every player joins individually.

- No player-created teams, captain creation, teammate invitations, team chat, or team discovery in MVP.

- For Duo/Squad/custom event configuration, authorized staff may internally assign individual entrants to a roster/lobby. Player sees their assigned result/room information but does not manage team membership.

### 8.3 Registration eligibility checks

Before confirming entry, backend checks:

- Authenticated email OTP session state.

- Mandatory profile/Free Fire UID complete.

- Tournament is registration-open.

- User is not suspended/banned from entries.

- User meets configured eligibility rules.

- Capacity remains available.

- User has no existing active registration in the same event.

- User has sufficient **available** coins for paid events.

### 8.4 Join confirmation

The player must see before confirmation:

- Exact entry coin cost.

- Current wallet balance.

- Estimated balance after entry.

- Event title/date/mode.

- Rule/policy confirmation checkbox.

- Statement that room details are delivered later after authorized release.

### 8.5 Atomic registration requirements

On confirmation, backend must atomically:

1. Check registration eligibility/capacity again.

2. Create registration.

3. Create immutable entry-fee ledger debit.

4. Save the entry-fee snapshot on registration.

5. Return final confirmation state.

### 8.6 Slot system:

- Tournament has a slot system. When the user taps Register, a Modal Bottom Sheet shows available slots/seats, with the total number of seats configured per tournament by admin.

- When all slots are booked (or when the match starts), one randomly selected slot is highlighted with a distinct color (e.g., gold). The player holding that slot receives a full refund of the registration fee via a linked ledger credit.

- That player effectively joins the tournament for free; everyone else's entry remains as normal.

Requirements:

- Repeated taps, network retry, or app reopen cannot create two registrations or double charge a player.

- Use idempotency keys for money/entry requests.

- Failure due to full event/insufficient balance must create no partial debit.

- Any cancellation/refund appears as linked ledger activity.

---

## 9. My Tournaments and room details

### 9.1 My Tournaments

Show tabs or sections:

| Section | Required content |

|---|---|

| Upcoming | Confirmed entry, schedule, entry paid, event rules |

| Room Released | Private room information and match instructions |

| Live / Results Pending | Event state and expected result notice |

| Completed | Official kills, placement, points, prize, transaction link |

| Cancelled | Clear cancellation/refund/reschedule notice |

### 9.2 Room release

Private room content includes, as configured:

- Room ID.

- Room password.

- Server/region.

- Join time/check-in guidance.

- Match instructions.

- Safety/privacy warning not to share credentials.

**Security requirements**

- Only confirmed eligible registered players can read room credentials.

- Credentials are stored/retrieved through protected backend access.

- Public cards, broad push messages, and public listings never contain room passwords.

- After admin release, send push notification and persist an in-app notification.

---

## 10. Official results, prizes, and statistics

### 10.1 Player result experience

After authorized staff publish a result, player sees:

- Official placement/rank.

- Official kills.

- Points/score table, if configured.

- Winner/standing list where product design permits.

- Prize amount, if awarded.

- Prize wallet transaction link/status.

- Result publication time.

- Tournament history action.

- **Share result / Share win** action that generates an on-brand marketing card (see 12B). Offered only for published, non-corrected/non-voided results.

### 10.2 Rules

- A player cannot submit/edit official kills, placement, points, or winner claim.

- Results stay draft until an authorized admin publishes them.

- Profile stats update from published official result data.

- A correction to a published outcome appears through an auditable correction/refund/adjustment process; it must not silently change a player's money history.

- If a dispute policy exists, show deadline and route the player to official WhatsApp support or approved support workflow.

### 10.3 Profile statistics

Show only official aggregated values, such as:

- Tournaments joined.

- Completed events.

- Top placements/wins.

- Total official kills.

- Total prize/coin value subject to policy.

Do not calculate financial balance from public profile statistics.

---

## 11. Rush Coin wallet

### 11.1 Wallet principles

- `1 Rush Coin = PKR 1` under the proposed model.

- All values are whole integer coins; never use floating-point money values.

- Wallet balance is derived/verified against immutable server-side ledger entries.

- Player client cannot write a balance directly.

- The app distinguishes **available**, **held**, and **pending** states.

### 11.2 Wallet screen

Show:

- Available coin balance.

- Held balance, such as a pending withdrawal.

- Pending top-up/withdrawal state.

- Coin/PKR explanation.

- Clear quick actions: Buy Coins, Withdraw, History.

- Reverse-chronological transaction history with amount, type, status, time in PKT, reference ID, and linked event/request.

- Wallet/refund/withdrawal policy link.

### 11.3 Required ledger activity types

| Activity | Expected effect |

|---|---|

| Top-up request | Pending only; no balance change |

| Top-up approved | Credit available coins |

| Top-up code redeemed | Credit available coins (one-time admin-issued code) |

| Tournament entry | Debit available coins |

| Tournament refund | Credit available coins |

| Prize award | Credit available coins |

| Reward entry cost | Debit available coins if paid method selected |

| Reward coin award | Credit available coins |

| Streak milestone reward | Credit available coins (server-confirmed tier) |

| Withdrawal requested | Move available coins to held coins |

| Withdrawal paid | Finalize held debit |

| Withdrawal rejected/cancelled | Return held coins to available |

| Admin correction | Audited compensating entry only |

### 11.4 Manual top-up request

**Player flow**

1. Player selects official enabled payment method.

2. App displays owner-configured official payment instructions/account details.

3. Player pays outside the app.

4. Player enters requested amount, transaction ID/reference, and required payer information.

5. Player just give the payment ID and select payment method jazz cash or easy paisa

6. App creates a pending request; no coin is credited yet.

7. Player receives approval/rejection status notification after staff review.

**UI/validation requirements**

- Explain that coins are not credited until authorized approval.

- Show request status: Pending, Approved, Rejected, Expired.

- Show rejection reason when appropriate without exposing internal fraud rules. [Also in the notification]

- Prevent accidental duplicate submission with idempotency/reference controls.

### 11.5 Withdrawal request

**Player flow**

1. Player selects an enabled payout method, for example Easypaisa, JazzCash.

2. Player enters/chooses payout account details and amount. [only phone no. and the amount]

3. Backend validates available balance, limits, verification requirements, and pending request rules.

4. Requested amount moves from available to held coins atomically.

5. Authorized staff review and manually send payout.

6. Player receives status: Pending Review, Approved, Paid, Rejected, or Cancelled.

**Player UI requirements**

- Show available amount, request amount, held amount, and remaining available amount.

- Show advertised 24-hour review/payment target with final-policy wording.

- Mask payout account details in history.

- Show latest request state and support route.

- On rejection/cancellation, show clear return-of-held-coins outcome.

### 11.6 Top-up code redemption

Admins (Owner/finance) can generate **one-time 6-digit numeric top-up codes** for any coin amount (e.g., for offline/manual payments) via the Control app; players redeem them in the Wallet.

**Player flow**

1. Wallet → Redeem Code → enter the 6-digit code.
2. App calls `topup-codes-redeem` (with `Idempotency-Key`); the backend atomically claims the code (`active → redeemed`) and credits the wallet with a `topup_code` ledger entry.
3. Player sees the credited amount, updated balance, and the transaction in History.

**Rules**

- A code is single-use and single-player; a second attempt returns a clear "already redeemed" error (and disabled codes are rejected).
- Idempotent — retries/network failures can never double-credit.
- Works exactly like an approved top-up for wallet purposes; when `cash_operations_enabled` is off, redeemed coins are test/non-redeemable.
- The ledger type is `topup_code`; admins see redemption stats in Reports.

### 11.7 Required policy decisions before enabling withdrawal

- Purchased-coin vs prize-coin withdrawal eligibility.

- Minimum/maximum withdrawal amount.

- Fee, if any.

- Daily/weekly/monthly limits.

- Accepted payout rails.

- Cancellation/refund/dispute policy.

---

## 12. Rewards: Spin Wheel:

### 12.1 Scope

MVP rewards issue **Rush Coins only**. No physical prizes, gift cards, or external redemption are required in initial scope.

### 12.2 Eligible entry methods

User may receive a reward attempt through owner-configured options:

1. Validated rewarded advertisement.

2. Paid attempt costing **5 Rush Coins**.

The same configured rule can initially apply to Spin Wheel and later each can have separate cost/limit settings.

### 12.3 Player experience

- Show available attempt state, entry method, cooldown, and daily limit.

- Let player choose ad or paid route where both are enabled.

- Display spin animation only after backend reserves/selects the result.

- Show reward result and wallet transaction status.

- Show reward terms and limits.

### 12.4 Fairness and abuse requirements

- Backend uses secure random result selection; client only visualizes the outcome.

- Ad completion must be validated through provider-supported server validation where available; do not trust client-only "ad watched" claims for valuable rewards.

- Paid attempt creates atomic debit + reward records; retries cannot double-debit/double-award.

- If ad fails/unavailable, do not charge coins; show documented retry/cooldown behavior.

- Rate-limit and risk-check attempts.

- Persist attempt source, campaign, selected reward, timestamp, linked ledger records, and risk metadata.

---

## 12A. Daily streak system

A GitHub-contribution-style engagement streak rewards players for returning and acting in the app each day. It is a **retention and progression** feature, not a cash-out mechanism in MVP.

### 12A.1 Purpose and tone

- Motivate daily opens and meaningful actions (not mindless tapping).

- Visualize long-term consistency with a recognizable **contribution-graph / heat-map calendar** similar to GitHub's streak tiles.

- Celebrate milestones with shareable moments (see 12B).

- Keep streak rewards modest and server-controlled; never let the client decide streak state or grant coins.

### 12A.2 What counts as a "active day"

A day is marked active when the player completes at least one **server-confirmed qualifying action** that PKT day. Configurable by admin; initial qualifying actions:

- Completes a rewarded-ad spin **or** a paid spin on the Spin Wheel.

- Registers for a tournament (registration confirmed).

- Plays in a tournament that goes Live (check-in / room released event).

- Has an official result published for one of their tournaments.

Rules:

- A calendar day is defined in PKT (`Asia/Karachi`), 00:00–23:59.

- One qualifying action marks the whole day; multiple actions do not stack multiple day cells.

- The backend is the sole authority — it records `streak_days(date, user_id, intensity, source_events[])` and derives all streak numbers from it. The client never writes streak state.

- `intensity` is a 0–4 level (like GitHub's Less → More) used to shade the heat-map cell: 0 = inactive, 1 = one qualifying action, 2 = two, 3 = three, 4 = four or more. Admins can reconfigure thresholds.

### 12A.3 Streak metrics shown to player

- **Current streak** — consecutive active days up to today (or yesterday; see grace below).

- **Longest streak** — personal best.

- **Total active days** — lifetime count.

- **This month** — active-day count and a monthly mini heat-map.

- **Next milestone** — progress to the next reward tier (e.g., "3 more days to 7-day reward").

- **Streak heat-map** — the last ~17 weeks (≈4 months) of 7-column day tiles, shaded by intensity, exactly in the spirit of GitHub's contribution graph, themed in warm gold/amber on the espresso canvas.

- Weekday labels and month labels; today's cell outlined in cream/gold; future dates empty/disabled.

### 12A.4 Streak freeze / grace

- Each player may have a limited number of **streak freezes** (admin-configured, default 0–1 per week) that protect the streak if they miss one day.

- A freeze is consumed automatically at the end of a missed PKT day; the streak continues but the missed day is visually distinct (a small ❄/frosted tile).

- Without a freeze, the current streak resets to 0 on the first missed day. Longest streak and total active days are never lost.

### 12A.5 Streak rewards (milestone tiers)

- Admin-configurable milestone tiers grant **Rush Coins only** in MVP (e.g., day 3, 7, 14, 30, 60, 100).

- Reaching a tier triggers a server-side atomic reward ledger entry (same rules as 12.4) and a celebratory sheet + in-app notification.

- Reward grants must be idempotent; reinstall, re-login, or clock changes cannot re-claim a milestone.

- Show the upcoming reward, its coin amount, and how many days remain. Already-claimed tiers show a claimed check.

- If `cash_operations_enabled` is off, streak rewards are test/non-redeemable coins like all other balances.

### 12A.6 Streak UI placement

- A compact **streak widget on Home** (flame icon + current streak count + mini 7-day row) that opens the full Streak screen.

- Full **Streak screen** (reached from Home widget and Profile): large current-streak number, longest/total stats, the full heat-map calendar, tier progress rail, and freeze count.

- A streak summary appears on the **Profile/Statistics** tab and on shareable cards (12B).

- A "streak at risk" prompt appears on Home when today has no qualifying action after a configurable local-evening hour (PKT); it deep-links to a qualifying action (e.g., Spin or Tournaments). It must be dismissible and never anxiety-driven/deceptive.

### 12A.7 Anti-abuse and integrity

- Qualifying actions must be real server events (validated ad completion, confirmed registration, official result), not client-only "opened app" pings. App-open alone never counts in MVP.

- Backend validates PKT day boundaries server-side; client device clock is never trusted for streak credit.

- Rate-limit and risk-check streak-related endpoints; suspicious patterns (e.g., impossible day sequences) raise a `risk_flag`.

- Milestone rewards are auditable ledger entries linked to the streak record.

### 12A.8 Data

Add records:

| Entity | Purpose |

|---|---|

| `streak_days` | One row per (user, PKT date): intensity level, qualifying event refs, created_at |

| `streak_milestones` | Claimed/rewarded tier state per user, linked ledger entry |

| `streak_freezes` | Available/consumed freeze balance and history |

---

## 12B. Shareable marketing cards

Players can generate polished, on-brand **share cards** (vertical 9:16 / story format and square 1:1) for sharing to WhatsApp Status, Instagram Stories, Snapchat, and similar, plus direct WhatsApp send. These act as organic marketing while showcasing the player's own achievements.

### 12B.1 Card types

Each card is built from official, server-sourced data only:

1. **Tournament result card** — placement, kills, prize, tournament name, match date.
2. **Win / top-placement card** — celebratory card for 1st/top-3 finishes with confetti/sunset art.
3. **Prize credited card** — prize coins earned.
4. **Streak milestone card** — "X-day streak" with the heat-map motif and milestone badge.
5. **Spin win card** — coins won on the wheel.
6. **Referral / join card** — branded invite card containing the player's referral code/link (see referral rules; safe data only).
7. **Profile / flex card** — player display name, in-app UID, tournaments joined, wins, total kills, longest streak.

### 12B.2 Card design requirements

- Render with the dark espresso + sunset design system (Section 4); never a light/cheap-looking template.

- 9:16 (1080×1920) for stories/status and 1:1 (1080×1080) for feeds/posts; exported as PNG (or WebP where supported), high enough resolution for social platforms.

- Each card includes:
  - Rush Zone logo/wordmark lockup.
  - A clear, unobtrusive **"Rush Zone"** footer and call to action (e.g., "Join me on Rush Zone" / app handle / install link or referral code).
  - The player's display name and in-app UID (4-digit app UID); avatar only if the player has one and it is marked public.
  - The achievement data in large editorial serif display type.
  - The sunset stripe motif and mountain-sunset silhouette where appropriate.

- **Privacy & safety:** cards must NEVER contain room ID/password, OTP, phone number, Free Fire UID, wallet balance, transaction IDs, payout account details, or referral codes that the player has not explicitly chosen to share. The referral/join card is the only card that carries a referral code/link.

- Player can preview the card before sharing.

- A toggle/confirm flow for the referral card makes it explicit that a referral code/link will be visible.

### 12B.3 Sharing mechanics

- Generated card image is saved to the device cache / share sheet (Expo Sharing + MediaLibrary on Android, with the appropriate runtime permissions).

- Share targets in MVP:
  - **WhatsApp** (direct chat) and **WhatsApp Status** via the system share sheet / WhatsApp-specific intent where available.
  - **Instagram Stories** (via Instagram's story share intent / sticker-style background asset) and **Instagram feed** for the 1:1 card.
  - System "More" fallback for any other app.
- The shared payload is the image plus an optional safe caption (app tagline and, for referral cards only, the referral link/code).
- Deep links back into the app (referral links, tournament links) must use approved universal/app links; do not place sensitive tokens in publicly sharable URLs.

### 12B.4 Share entry points

- Result screen → "Share result" button after official result is published.
- Prize credited notification / wallet transaction → "Share win".
- Streak milestone celebration sheet → "Share streak".
- Spin win dialog → "Share".
- Profile/Statistics → "Share profile" / referral card.
- Refer screen → shareable invite card.

### 12B.5 Integrity and tracking

- Cards are generated from server data; the client cannot fabricate kills, placement, prize, or streak values on a share card.
- If a result is later corrected/voided, already-shared external images cannot be recalled — but in-app share previews must always reflect current authoritative data, and a voided/corrected result must not offer a share card.
- Attribution for referral installs is handled server-side via the referral code/link; the app does not promise rewards it cannot verify.
- Optional analytics: record `card_share_events(card_type, channel, user_id, linked_entity_id)` for funnel insight, without storing personal recipient data.

### 12B.6 Data

Add record:

| Entity | Purpose |

|---|---|

| `card_share_events` | Type of card shared, share channel, linked entity (tournament/result/streak), timestamp for attribution/analytics |

---

## 12C. Referral program

The bottom navigation includes a **Refer** tab. Referral is a basic invite-and-reward mechanic in MVP; richer loyalty/tiers remain Phase 2.

### 12C.1 Mechanics

- Every player receives a unique referral code (distinct from their 4-digit in-app UID) and a shareable referral link/card (see 12B, referral/join card).

- When a new player signs up, completes email OTP verification, profile setup (including WhatsApp phone number), and (where configured) their first qualifying action, both the referrer and the referred player receive a server-controlled reward (Rush Coins in MVP).

- Reward amounts, the qualifying trigger, per-user caps, and anti-fraud rules are admin-configurable.

- Referral attribution and reward grants are server-authoritative and idempotent; the client cannot self-credit a referral.

- The Refer screen shows: the player's code, share buttons (including the shareable card), a count of successful referrals, pending/rewarded state, and the current reward terms.

### 12C.2 Integrity

- Prevent self-referral, same-device referral abuse (one device = one account, per 6.1), and duplicate/loop referrals.

- Suspicious attribution raises a `risk_flag` and holds the reward pending review; held/rejected referral rewards follow the same auditable ledger pattern as other adjustments.

- Referral links must not carry sensitive tokens; use opaque referral codes mapped server-side.

### 12C.3 Data

Add records:

| Entity | Purpose |

|---|---|

| `referrals` | Referrer, referred user, attribution code, qualification state, reward status, linked ledger entries, risk metadata |

---

## 13. Notifications and support

### 13.1 Push and in-app notifications

Required notification types:

- OTP/security notice where appropriate.
- Push delivery via **expo-notifications** (FCM/APNs underneath); each device registers its Expo push token via `push-token-register`. The in-app inbox is authoritative and push is best-effort. *(Server-side push sending from `app.push_tokens` is a known backend gap; inbox works today.)*

- Registration confirmed.

- Room details released.

- Tournament reminder.

- Tournament changed/cancelled/refunded.

- Official result published.

- Prize credited.

- Top-up approved/rejected.

- Withdrawal approved/paid/rejected/cancelled.

- Reward result.

- Streak milestone reached / streak freeze consumed / streak-at-risk reminder.

- Important policy/maintenance announcement.

### 13.2 Notification inbox

- Store a persistent in-app inbox.

- Display unread/read state and timestamp in PKT.

- Deep-link to safe relevant screens: tournament, wallet request, result, or policy.

- Never include room passwords, OTPs, raw payment details, or sensitive payout data in broad notification text.

### 13.3 WhatsApp support

- Player has a floating/support button that opens an owner-configured official WhatsApp deep link.

- Prefilled text must contain only safe context, for example player ID/event title if permitted.

- Do not pass OTPs, private room password, wallet balance, transaction screenshot, or payout account in URL text.

- Show official support hours/expectation when business provides them.

---

## 14. File uploads and privacy

### 14.1 Storage buckets

| Bucket | Visibility | Example |

|---|---|---|

| `tournament-thumbnails` | Public/CDN | Tournament cover art |

| `avatars` | Public or limited | Player profile avatar |

### 14.2 Upload rules

| File | Recommended limit | Handling |

|---|---:|---|

| Tournament thumbnail | 1MB | Resize/compress, WebP preferred | [it will be uploaded by the admin]

| Player avatar | 500KB | Resize/compress |

- Never store image/Base64 blobs in PostgreSQL tables.

- Save object path/metadata in DB; store actual files in object storage.

---

## 15. Data requirements

Player-facing backend records include:

| Entity | Required purpose |

|---|---|

| `users` | Auth identity (email OTP), required WhatsApp contact number, status |

| `player_profiles` | Display name, FF UID, in-game name, avatar, aggregate stats |

| `wallet_accounts` | Available/held state verified against ledger |

| `wallet_ledger_entries` | Immutable transaction history |

| `topup_requests` | Manual payment request/review metadata |

| `topup_codes` | Admin-issued one-time 6-digit codes; atomic claim + wallet credit |

| `withdrawal_methods` | Protected/masked payout method data |

| `withdrawal_requests` | Request amount, state, held ledger link, payout result |

| `tournaments` | Event public metadata/lifecycle |

| `registrations` | Individual entry, fee snapshot, roster assignment state |

| `match_results` | Official per-player kills/placement/points |

| `prize_awards` | Official result award and ledger link |

| `reward_attempts` | Spin source/result/risk/ledger link |

| `streak_days` | Per-user per-PKT-day active marker, intensity level, qualifying event refs |

| `streak_milestones` | Claimed/rewarded streak tiers and linked ledger entries |

| `streak_freezes` | Available/consumed streak freeze balance and history |

| `card_share_events` | Marketing-card share type, channel, and linked entity for attribution |

| `notifications` | In-app inbox/delivery state |

| `referrals` | Referral attribution, qualification state, reward status, linked ledger entries |

| `risk_flags` | Fraud/moderation restriction context |

---

## 16. Security, reliability, and quality requirements

### 16.1 Security

- HTTPS/TLS for all API traffic.

- Secure device token/session storage.

- Server-side authorization for every protected request.

- Rate limiting for OTP, registration, uploads, top-up, withdrawal, reward actions, and support-sensitive endpoints.

- Strict backend validation for all client-provided IDs and amounts.

- No wallet balance, prize, or result is trusted from the device.

### 16.2 Reliability

- Store timestamps in UTC, display in PKT.

- Use idempotency keys for financial/registration operations.

- Use atomic database transactions for entry debit, prize credit, refund, and held withdrawal movement.

- Show intentional loading, retry, empty, offline, and error states.

- Maintain data backups, error monitoring, and reconciliation once wallet operations are enabled.

### 16.3 Accessibility and usability

- Text and color contrast must be readable on the dark espresso surfaces (WCAG AA); never rely on low-contrast grey-on-brown for important content.

- Do not use color as the only status indicator; include text labels/icons.

- Error messages explain safe next action.

- Critical money confirmation screens summarize final amount before submit.

- Never use deceptive prize language, hidden fees, or confusing coin/cash conversion text.

---

## 17. MVP acceptance criteria

The Player App MVP is complete when:

- [ ] Player can authenticate using email OTP (Supabase Auth built-in email delivery). A Pakistan WhatsApp phone number is required in profile setup but is not used as a login factor.

- [ ] Player can accept policies and complete Free Fire profile data.

- [ ] Player can browse/filter published tournaments and read clear details in PKT.

- [ ] Player can enter once individually; duplicate/multi-tap entry is prevented.

- [ ] Player can see room credentials only after authorized release.

- [ ] Player can see only official staff-published kills/results/prizes.

- [ ] Player wallet displays immutable activity, available balance, and held balance.

- [ ] Player can create a manual top-up request.

- [ ] Player can redeem an admin-issued 6-digit top-up code for an instant, one-time coin credit.

- [ ] Player can create withdrawal request; coins move to held state and return on rejection/cancellation.

- [ ] Player can use server-controlled spin rewards by validated ad or paid 5-coin attempt.

- [ ] Player sees a GitHub-style daily streak heat-map; qualifying server actions mark PKT days, milestones grant coins atomically, and the client cannot forge streak state.

- [ ] Player can generate on-brand dark-theme share cards for results/wins/prizes/streaks/spins/profile and share them to WhatsApp (Status/chat) and Instagram Stories/feed without exposing sensitive data.

- [ ] Player receives persistent in-app notifications and can open official WhatsApp support.

- [ ] App uses the supplied **dark espresso** editorial sunset design system (single dark theme), including the closing sunset stripe on each mobile screen.

- [ ] All real-money actions stay disabled until `cash_operations_enabled` is formally enabled.

---

## 18. Out of scope for MVP

- Player-created teams/captains/team invitations.

- Open team recruitment.

- Automated Free Fire result API integration.

- Player-submitted official result verification.

- Automated Easypaisa/JazzCash payout/check-out API.

- Social feed, livestream hosting, user video uploads (sharing marketing cards to external apps is in scope).

- Full Urdu localization.

- [Phase 2] Player-to-player coin transfer.

- Crypto, betting markets, lending, or unrelated financial products.

---

## 19. Phase-2 candidates

- Automated approved payment provider integration.

- Team creation, captain management, and team discovery.

- Full tournament brackets/multi-round standings.

- Urdu language option.

- Advanced loyalty/tiers program beyond the basic referral mechanic.

- Advanced player risk and account security.

- Approved stream links and richer community features.
