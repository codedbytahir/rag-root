/* eslint-env jest */
jest.mock('expo-secure-store', () => ({
  getItemAsync: jest.fn(async () => null),
  setItemAsync: jest.fn(async () => {}),
  deleteItemAsync: jest.fn(async () => {}),
}));

jest.mock('expo-crypto', () => ({
  getRandomBytes: jest.fn((n) => new Uint8Array(n).fill(1)),
  getRandomBytesAsync: jest.fn(async (n) => new Uint8Array(n).fill(1)),
  digestStringAsync: jest.fn(async () => 'abc123'),
}));

jest.mock('react-native-url-polyfill/auto', () => {});
