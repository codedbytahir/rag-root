import {
  BROWSEABLE_STATUSES,
  canRegister,
  prettyMap,
  prettyMode,
  statusMeta,
} from '../src/lib/tournaments'

describe('prettyMode', () => {
  it('title-cases known modes', () => {
    expect(prettyMode('solo')).toBe('Solo')
    expect(prettyMode('duo')).toBe('Duo')
    expect(prettyMode('squad')).toBe('Squad')
    expect(prettyMode('custom')).toBe('Custom')
  })

  it('falls back for empty values', () => {
    expect(prettyMode(null)).toBe('All')
    expect(prettyMode(undefined)).toBe('All')
    expect(prettyMode('')).toBe('All')
  })
})

describe('prettyMap', () => {
  it('title-cases single and multi-word maps', () => {
    expect(prettyMap('erangel')).toBe('Erangel')
    expect(prettyMap('nusa penida')).toBe('Nusa Penida')
    expect(prettyMap('Bermuda')).toBe('Bermuda')
  })

  it('falls back for empty values', () => {
    expect(prettyMap(null)).toBe('—')
    expect(prettyMap(undefined)).toBe('—')
    expect(prettyMap('')).toBe('—')
  })
})

describe('statusMeta', () => {
  it('labels the statuses players can browse', () => {
    expect(statusMeta('registration_open')?.label).toBe('Open')
    expect(statusMeta('scheduled')?.label).toBe('Upcoming')
    expect(statusMeta('completed')?.label).toBe('Completed')
  })

  it('hides draft/cancelled from browsing', () => {
    expect(statusMeta('draft')).toBeNull()
    expect(statusMeta('cancelled')).toBeNull()
    expect(BROWSEABLE_STATUSES).not.toContain('draft')
    expect(BROWSEABLE_STATUSES).not.toContain('cancelled')
  })

  it('only allows registration while open', () => {
    expect(canRegister('registration_open')).toBe(true)
    expect(canRegister('registration_full')).toBe(false)
    expect(canRegister('scheduled')).toBe(false)
  })
})
