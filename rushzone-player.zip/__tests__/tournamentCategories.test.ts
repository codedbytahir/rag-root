import {
  buildCategoryFolders,
  findCategory,
  isTeamTournament,
  labelForMode,
  modeMatchesFilter,
  normalizeModeKey,
  teamSizeForMode,
} from '../src/lib/tournamentCategories'
import type { TournamentsRow } from '../src/lib/database.types'

function row(mode: string): TournamentsRow {
  return {
    id: mode,
    title: mode,
    description: null,
    cover_path: null,
    mode,
    map: null,
    rounds: 1,
    capacity: 48,
    entry_fee: 10,
    prize_pool: 500,
    prize_distribution: [],
    score_rules: {},
    rules_text: null,
    status: 'registration_open',
    reg_open_at: null,
    reg_close_at: null,
    match_start_at: null,
    room_release_at: null,
    result_expected_at: null,
    is_preset: false,
    free_slot_enabled: false,
    free_slot_trigger: null,
    free_slot_number: null,
    free_slot_awarded_at: null,
    published_at: null,
    cancelled_reason: null,
    created_at: '',
    updated_at: '',
  }
}

describe('normalizeModeKey', () => {
  it('strips separators and lowercases', () => {
    expect(normalizeModeKey('Battle Royale Solo')).toBe('battleroyalesolo')
    expect(normalizeModeKey('cs_1v1')).toBe('cs1v1')
    expect(normalizeModeKey('CS 4v6')).toBe('cs4v6')
  })
})

describe('modeMatchesFilter (flexible matching)', () => {
  it('matches aliases against varied spellings', () => {
    expect(modeMatchesFilter('solo', 'br_solo')).toBe(true)
    expect(modeMatchesFilter('battle royale solo', 'br_solo')).toBe(true)
    expect(modeMatchesFilter('brsolo', 'br_solo')).toBe(true)
    expect(modeMatchesFilter('cs 1v1', 'cs_1v1')).toBe(true)
    expect(modeMatchesFilter('cs1v1', 'cs_1v1')).toBe(true)
    expect(modeMatchesFilter('lonewolf', 'lonewolf_1v1')).toBe(true)
    expect(modeMatchesFilter('lw low entry', 'lw_low_entry')).toBe(true)
  })

  it('does not match unrelated modes', () => {
    expect(modeMatchesFilter('squad', 'br_solo')).toBe(false)
    expect(modeMatchesFilter('cs1v1', 'cs_2v2')).toBe(false)
  })
})

describe('labelForMode / findCategory', () => {
  it('returns curated labels for known modes', () => {
    expect(labelForMode('solo')).toBe('Battle Royale Solo')
    expect(labelForMode('brsquad')).toBe('Battle Royale Squad')
    expect(labelForMode('cs 4v6')).toBe('CS 4v6')
    expect(findCategory('lonewolf')?.key).toBe('lonewolf_1v1')
  })

  it('falls back to title-case for unknown modes', () => {
    expect(labelForMode('ranked')).toBe('Ranked')
  })
})

describe('teamSizeForMode / isTeamTournament', () => {
  it('sizes teams per mode', () => {
    expect(teamSizeForMode('solo')).toBe(1)
    expect(teamSizeForMode('cs 1v1')).toBe(1)
    expect(teamSizeForMode('lonewolf_1v1')).toBe(1)
    expect(teamSizeForMode('duo')).toBe(2)
    expect(teamSizeForMode('brsquad')).toBe(4)
    expect(teamSizeForMode('cs4v6')).toBe(4)
    expect(isTeamTournament('duo')).toBe(true)
    expect(isTeamTournament('solo')).toBe(false)
  })
})

describe('buildCategoryFolders', () => {
  it('groups unknown spellings into curated categories', () => {
    const folders = buildCategoryFolders([row('solo'), row('brsolo'), row('duo'), row('ranked')])
    const solo = folders.find((f) => f.key === 'br_solo')
    const duo = folders.find((f) => f.key === 'br_duo')
    const ranked = folders.find((f) => f.key === 'ranked')
    expect(solo?.count).toBe(2)
    expect(solo?.label).toBe('Battle Royale Solo')
    expect(duo?.count).toBe(1)
    expect(ranked?.label).toBe('Ranked')
  })
})
