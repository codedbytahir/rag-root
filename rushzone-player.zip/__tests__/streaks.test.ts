import {
  addDays,
  buildHeatmap,
  computeStreaks,
  monthLabelOf,
} from '../src/lib/streaks'

describe('addDays', () => {
  it('adds calendar days across month boundaries', () => {
    expect(addDays('2026-01-31', 1)).toBe('2026-02-01')
    expect(addDays('2026-03-01', -1)).toBe('2026-02-28')
    expect(addDays('2025-12-31', 1)).toBe('2026-01-01')
  })
})

describe('computeStreaks', () => {
  it('returns zeros for no active days', () => {
    expect(computeStreaks([], '2026-08-14')).toEqual({
      current: 0,
      longest: 0,
      total: 0,
      thisMonth: 0,
      monthKey: '2026-08',
    })
  })

  it('counts a current streak ending today', () => {
    const days = [
      { day: '2026-08-12', intensity: 1 },
      { day: '2026-08-13', intensity: 2 },
      { day: '2026-08-14', intensity: 1 },
    ]
    const stats = computeStreaks(days, '2026-08-14')
    expect(stats.current).toBe(3)
    expect(stats.longest).toBe(3)
    expect(stats.total).toBe(3)
  })

  it('gives one-day grace when today has no qualifying action yet', () => {
    const days = [
      { day: '2026-08-13', intensity: 1 },
      { day: '2026-08-12', intensity: 1 },
    ]
    // Today (14th) is inactive but yesterday was — the streak is preserved.
    expect(computeStreaks(days, '2026-08-14').current).toBe(2)
    // A fully missed day (15th) resets the current streak.
    expect(computeStreaks(days, '2026-08-15').current).toBe(0)
  })

  it('tracks the longest run separately from the current', () => {
    const days = [
      { day: '2026-08-01', intensity: 1 },
      { day: '2026-08-02', intensity: 1 },
      { day: '2026-08-03', intensity: 1 },
      { day: '2026-08-05', intensity: 1 }, // gap on the 4th
      { day: '2026-08-06', intensity: 1 },
    ]
    const stats = computeStreaks(days, '2026-08-06')
    expect(stats.current).toBe(2)
    expect(stats.longest).toBe(3)
  })

  it('counts this-month active days', () => {
    const days = [
      { day: '2026-08-01', intensity: 1 },
      { day: '2026-07-31', intensity: 1 },
    ]
    expect(computeStreaks(days, '2026-08-14').thisMonth).toBe(1)
  })
})

describe('buildHeatmap', () => {
  it('builds the requested number of 7-day weeks ending today', () => {
    const heat = buildHeatmap([], '2026-08-14', 3)
    expect(heat.length).toBe(3)
    for (const week of heat) {
      expect(week.days.length).toBe(7)
    }
    const last = heat[heat.length - 1]!.days[6]!
    expect(last.date).toBe('2026-08-14')
    expect(last.isToday).toBe(true)
  })

  it('shades by intensity and flags future days', () => {
    const heat = buildHeatmap([{ day: '2026-08-10', intensity: 3 }], '2026-08-14', 1)
    const cell = heat[0]!.days.find((c) => c.date === '2026-08-10')
    expect(cell?.intensity).toBe(3)
    expect(heat[0]!.days.some((c) => c.isFuture)).toBe(false)
    // A 1-week grid starting 8 days before today has no future cells.
    const wide = buildHeatmap([], '2026-08-14', 2)
    expect(wide[0]!.days.some((c) => c.isFuture)).toBe(false)
  })

  it('exposes month labels', () => {
    expect(monthLabelOf('2026-08-01')).toBe('Aug')
  })
})
