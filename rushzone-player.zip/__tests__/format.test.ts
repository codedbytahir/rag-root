import {
  formatCoins,
  maskEmail,
  maskPhone,
  normalizeWhatsappPhone,
  isValidWhatsappPhone,
  isValidFFUID,
  isValidDisplayName,
  formatPKTDateTime,
} from '../src/lib/format'

describe('formatCoins', () => {
  it('formats whole integers with grouping', () => {
    expect(formatCoins(1000)).toBe('1,000')
    expect(formatCoins('500')).toBe('500')
    expect(formatCoins(0)).toBe('0')
    expect(formatCoins(null)).toBe('0')
    expect(formatCoins(undefined)).toBe('0')
  })
})

describe('maskEmail', () => {
  it('masks the middle of the local part', () => {
    expect(maskEmail('test@example.com')).toBe('t**t@example.com')
    expect(maskEmail('ab@example.com')).toBe('a*@example.com')
  })
})

describe('maskPhone', () => {
  it('keeps the prefix and last four digits', () => {
    expect(maskPhone('+923001234567')).toBe('+923 •••• 4567')
  })
})

describe('Pakistan phone validation', () => {
  it('normalizes accepted formats to E.164', () => {
    expect(normalizeWhatsappPhone('+923001234567')).toBe('+923001234567')
    expect(normalizeWhatsappPhone('03001234567')).toBe('+923001234567')
    expect(normalizeWhatsappPhone('3001234567')).toBe('+923001234567')
    expect(normalizeWhatsappPhone('923001234567')).toBe('+923001234567')
  })

  it('rejects invalid numbers', () => {
    expect(normalizeWhatsappPhone('123')).toBeNull()
    expect(normalizeWhatsappPhone('+441234567890')).toBeNull()
    expect(isValidWhatsappPhone('03001234567')).toBe(true)
    expect(isValidWhatsappPhone('12345')).toBe(false)
  })
})

describe('profile field validators', () => {
  it('validates Free Fire UIDs', () => {
    expect(isValidFFUID('123456')).toBe(true)
    expect(isValidFFUID('12345')).toBe(false)
    expect(isValidFFUID('abcdef')).toBe(false)
  })

  it('validates display names', () => {
    expect(isValidDisplayName('FalconX')).toBe(true)
    expect(isValidDisplayName('a')).toBe(false)
    expect(isValidDisplayName('x'.repeat(31))).toBe(false)
    expect(isValidDisplayName('ok name_2')).toBe(true)
  })
})

describe('formatPKTDateTime', () => {
  it('renders a PKT timestamp without throwing', () => {
    const out = formatPKTDateTime('2026-08-14T09:00:00Z')
    expect(out).not.toBe('—')
    expect(out).toMatch(/\w{3} \d{1,2}, \d{4}/)
  })
})
