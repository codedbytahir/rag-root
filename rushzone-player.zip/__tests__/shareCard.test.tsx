import React from 'react'
import TestRenderer, { act } from 'react-test-renderer'
import { ShareCard, type ShareCardData } from '@/components/ShareCard'

const base: ShareCardData = {
  type: 'profile',
  displayName: 'Player One',
  appUid: '1234',
}

describe('ShareCard', () => {
  it.each([
    ['profile', { ...base, type: 'profile', stats: { joined: 4, wins: 2, kills: 19 } }],
    ['referral', { ...base, type: 'referral', referralCode: 'ABCD' }],
    ['result', { ...base, type: 'result', tournamentTitle: 'Squad Clash', placement: 2, kills: 7 }],
    ['win', { ...base, type: 'win', tournamentTitle: 'Squad Clash', placement: 1, kills: 9 }],
    ['prize', { ...base, type: 'prize', prizeCoins: 150, tournamentTitle: 'Solo Rush' }],
    ['streak', { ...base, type: 'streak', streakDays: 12 }],
    ['spin', { ...base, type: 'spin', coinsWon: 25 }],
  ] as [string, ShareCardData][])('renders %s card', (_type, data) => {
    let tree: TestRenderer.ReactTestRenderer
    act(() => {
      tree = TestRenderer.create(<ShareCard data={data} width={340} height={604} />)
    })
    expect(tree!.toJSON()).toBeTruthy()
  })

  it('renders profile card in square format', () => {
    let tree: TestRenderer.ReactTestRenderer
    act(() => {
      tree = TestRenderer.create(
        <ShareCard
          data={{ ...base, type: 'profile', stats: { joined: 4, wins: 2, kills: 19 } }}
          width={340}
          height={340}
        />,
      )
    })
    expect(tree!.toJSON()).toBeTruthy()
  })
})
