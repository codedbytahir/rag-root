/**
 * Startup env/config tests. These guard against the silent-launch-crash class
 * of bug: `createClient` throws at module-eval time (before any error handler
 * is installed) when the baked-in Supabase URL/key are empty or malformed.
 */
jest.mock('@react-native-async-storage/async-storage', () =>
  require('@react-native-async-storage/async-storage/jest/async-storage-mock'),
)

import { env } from '@/lib/env'
import { supabase } from '@/lib/supabase'

describe('env.isMisconfigured', () => {
  it('flags a missing URL', () => {
    expect(env.isMisconfigured).toBe(!env.supabaseUrl || !env.supabasePublishableKey)
  })

  it('detects a URL that is not http(s) — the case createClient would throw on', () => {
    // Mirrors the supabase-js validation: "Must be a valid HTTP or HTTPS URL."
    const bad = 'gwtipxyhyalikdaqnvdp.supabase.co' // no protocol
    const good = 'https://gwtipxyhyalikdaqnvdp.supabase.co'
    expect(/^https?:\/\//.test(bad)).toBe(false)
    expect(/^https?:\/\//.test(good)).toBe(true)
  })
})

describe('supabase client construction', () => {
  it('always produces a client without throwing at import time', () => {
    // The exported client must exist (module-eval must not throw) and expose
    // the auth/storage surface the app uses.
    expect(supabase).toBeDefined()
    expect(typeof supabase.auth.getSession).toBe('function')
    expect(typeof supabase.from).toBe('function')
  })
})
